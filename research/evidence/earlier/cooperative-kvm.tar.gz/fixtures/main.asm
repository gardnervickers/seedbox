; Bare real-mode CPL0; no guest Linux, syscalls, IRQ chip, or timers.
; Each of eight finite segments increments its private counter 257 times.
BITS 16
ORG 0x1000
    fninit
    fild word [0x402]          ; private x87 initial value
    xor si, si
    mov cx, 8
round:
    mov bx, 257
compute:
    inc word [0x400]
    dec bx
    jnz compute
    fadd st0, st0
    fst qword [0x410]         ; non-destructive architectural observation
    mov [0x404], si
    mov dx, 0x504
    mov ax, si
    jmp yield
    times 0x80-($-$$) db 0x90
yield:
    out dx, ax               ; fixed RIP 0x1080; next instruction at 0x1081
    inc word [0x406]         ; MUST NOT execute during completion-only reentry
    inc si
    dec cx
    jnz round
    cmp word [0x452], 1       ; only rebooted machine consumes callbacks
    jne terminal
    mov ax, [0x450]
    mov [0x454], ax           ; guest-visible stale callback exclusion oracle
terminal:
    hlt                      ; explicit terminal exit, never idle waiting
