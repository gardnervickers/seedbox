; Direct RNG instructions even when guest CPUID hides both features.
; #UD returns via real-mode IVT6. UD2+NOP is the same 3-byte control length.
BITS 16
ORG 0x1000
    mov eax, 1
    cpuid
    mov [0x430], ecx
    mov eax, 7
    xor ecx, ecx
    cpuid
    mov [0x434], ebx
%ifdef UD_CONTROL
    db 0x0f, 0x0b, 0x90
%else
    rdrand ax
%endif
    mov [0x422], ax
    setc byte [0x424]
    mov bx, [0x420]
    mov [0x42a], bx           ; distinguish per-instruction #UD counts
%ifdef UD_CONTROL
    db 0x0f, 0x0b, 0x90
%else
    rdseed ax
%endif
    mov [0x426], ax
    setc byte [0x428]
    mov dx, 0x504
    mov ax, 0xbabe
    jmp yield
    times 0x80-($-$$) db 0x90
yield:
    out dx, ax
    hlt
    times 0x200-($-$$) db 0x90
ud_handler:
    push bp
    mov bp, sp
    inc word [0x420]
    add word [ss:bp+2], 3
    pop bp
    iret
