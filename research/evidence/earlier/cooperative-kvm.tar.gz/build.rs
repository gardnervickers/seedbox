use std::{env, path::PathBuf, process::Command};
fn main() {
    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    for (name, source, control) in [
        ("main", "fixtures/main.asm", false),
        ("rng", "fixtures/rng.asm", false),
        ("ud-control", "fixtures/rng.asm", true),
    ] {
        println!("cargo:rerun-if-changed={source}");
        let mut cmd = Command::new("nasm");
        cmd.args(["-f", "bin", source, "-o"])
            .arg(out.join(format!("{name}.bin")));
        if control {
            cmd.arg("-DUD_CONTROL=1");
        }
        assert!(
            cmd.status()
                .expect("nasm required in pinned Nix shell")
                .success()
        );
    }
}
