use sha2::{Digest, Sha256};
fn hash(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
mod linux;
fn main() {
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    if let Err(error) = linux::run() {
        eprintln!("HARDWARE_GATE_FAILED: {error}");
        std::process::exit(1);
    }
    #[cfg(not(all(target_os = "linux", target_arch = "x86_64")))]
    {
        eprintln!("UNSUPPORTED_HOST: requires x86_64 Linux /dev/kvm; no emulated admission claim");
        std::process::exit(42);
    }
}
