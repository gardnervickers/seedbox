use crate::hash;
use kvm_bindings::{KVM_MAX_CPUID_ENTRIES, kvm_fpu, kvm_regs, kvm_userspace_memory_region};
use kvm_ioctls::{Cap, Kvm, VcpuExit, VcpuFd, VmFd};
use serde_json::{Value, json};
use std::{
    fmt::Display,
    marker::PhantomData,
    rc::Rc,
    sync::Arc,
    thread::{self, ThreadId},
};

type Result<T> = std::result::Result<T, String>;
const MEMORY_SIZE: usize = 0x4000;
const ENTRY: usize = 0x1000;
const YIELD_NEXT: u64 = 0x1081;
const PORT: u16 = 0x504;
const MAIN: &[u8] = include_bytes!(concat!(env!("OUT_DIR"), "/main.bin"));
const RNG: &[u8] = include_bytes!(concat!(env!("OUT_DIR"), "/rng.bin"));
const UD_CONTROL: &[u8] = include_bytes!(concat!(env!("OUT_DIR"), "/ud-control.bin"));

fn checked<T, E: Display>(r: std::result::Result<T, E>, context: &str) -> Result<T> {
    r.map_err(|e| format!("{context}: {e}"))
}
fn require(condition: bool, context: impl Into<String>) -> Result<()> {
    if condition {
        Ok(())
    } else {
        Err(context.into())
    }
}
#[derive(Clone)]
struct Owner {
    thread: ThreadId,
    tid: libc::pid_t,
    _not_send: PhantomData<Rc<()>>,
}
impl Owner {
    fn new() -> Self {
        Self {
            thread: thread::current().id(),
            tid: unsafe { libc::syscall(libc::SYS_gettid) as libc::pid_t },
            _not_send: PhantomData,
        }
    }
    fn check(&self) {
        assert_eq!(
            self.thread,
            thread::current().id(),
            "simulation crossed host thread"
        );
        assert_eq!(
            self.tid,
            unsafe { libc::syscall(libc::SYS_gettid) as libc::pid_t },
            "simulation crossed host OS thread"
        );
    }
}
struct Mapping {
    ptr: *mut u8,
    owner: Owner,
}
impl Mapping {
    fn new(owner: &Owner) -> Result<Self> {
        owner.check();
        let ptr = unsafe {
            libc::mmap(
                std::ptr::null_mut(),
                MEMORY_SIZE,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_PRIVATE | libc::MAP_ANONYMOUS,
                -1,
                0,
            )
        };
        require(
            ptr != libc::MAP_FAILED,
            format!("mmap: {}", std::io::Error::last_os_error()),
        )?;
        Ok(Self {
            ptr: ptr.cast(),
            owner: owner.clone(),
        })
    }
    fn bytes(&self) -> &[u8] {
        self.owner.check();
        unsafe { std::slice::from_raw_parts(self.ptr, MEMORY_SIZE) }
    }
    fn write(&self, at: usize, data: &[u8]) {
        self.owner.check();
        assert!(at + data.len() <= MEMORY_SIZE);
        // Sole owner thread; guest is never running while host touches memory.
        unsafe { std::ptr::copy_nonoverlapping(data.as_ptr(), self.ptr.add(at), data.len()) };
    }
    fn word(&self, at: usize) -> u16 {
        u16::from_le_bytes(self.bytes()[at..at + 2].try_into().unwrap())
    }
    fn clear(&self) {
        self.owner.check();
        unsafe { std::ptr::write_bytes(self.ptr, 0, MEMORY_SIZE) };
    }
}
impl Drop for Mapping {
    fn drop(&mut self) {
        self.owner.check();
        assert_eq!(unsafe { libc::munmap(self.ptr.cast(), MEMORY_SIZE) }, 0);
    }
}

// Field order intentionally drops vCPU and VM descriptors before guest backing.
struct Machine {
    vcpu: VcpuFd,
    _vm: VmFd,
    memory: Arc<Mapping>,
    owner: Owner,
    id: usize,
    generation: u64,
    initial: u16,
    rounds: u16,
    halted: bool,
    xmm0: [u8; 16],
}
enum Exit {
    Yield(u16),
    Halt,
}
impl Machine {
    fn new(
        kvm: &Kvm,
        owner: &Owner,
        id: usize,
        generation: u64,
        seed: u64,
        code: &[u8],
        alias: Option<Arc<Mapping>>,
        hide_rng: bool,
    ) -> Result<Self> {
        owner.check();
        let memory = match alias {
            Some(m) => m,
            None => Arc::new(Mapping::new(owner)?),
        };
        memory.clear();
        memory.write(ENTRY, code);
        let initial = (seed as u16)
            .wrapping_add((id as u16 + 1) * 997)
            .wrapping_add(generation as u16 * 31);
        memory.write(0x400, &initial.to_le_bytes());
        memory.write(0x402, &(id as u16 + generation as u16 * 10).to_le_bytes());
        if id == 0 && generation == 2 {
            memory.write(0x452, &1u16.to_le_bytes());
        }
        memory.write(6 * 4, &0x1200u16.to_le_bytes()); // real-mode #UD vector CS=0
        let vm = checked(kvm.create_vm(), "create_vm")?;
        // Backing is stable until after all KVM descriptors drop; no irqchip/PIT.
        unsafe {
            checked(
                vm.set_user_memory_region(kvm_userspace_memory_region {
                    slot: 0,
                    flags: 0,
                    guest_phys_addr: 0,
                    memory_size: MEMORY_SIZE as u64,
                    userspace_addr: memory.ptr as u64,
                }),
                "register memory",
            )?;
        }
        let vcpu = checked(vm.create_vcpu(0), "create_vcpu")?;
        let mut cpuid = checked(
            kvm.get_supported_cpuid(KVM_MAX_CPUID_ENTRIES),
            "supported CPUID",
        )?;
        for entry in cpuid.as_mut_slice().iter_mut().filter(|_| hide_rng) {
            if entry.function == 1 {
                entry.ecx &= !(1 << 30);
            } // RDRAND
            if entry.function == 7 && entry.index == 0 {
                entry.ebx &= !(1 << 18);
            } // RDSEED
        }
        checked(vcpu.set_cpuid2(&cpuid), "set CPUID")?;
        let mut s = checked(vcpu.get_sregs(), "get_sregs")?;
        for seg in [
            &mut s.cs, &mut s.ds, &mut s.es, &mut s.ss, &mut s.fs, &mut s.gs,
        ] {
            seg.base = 0;
            seg.selector = 0;
        }
        s.cr0 &= !((1 << 2) | (1 << 3)); // EM=0, TS=0 for x87
        s.cr0 |= 1 << 1;
        checked(vcpu.set_sregs(&s), "set_sregs")?;
        checked(
            vcpu.set_regs(&kvm_regs {
                rip: ENTRY as u64,
                rsp: 0x3800,
                rflags: 2,
                ..Default::default()
            }),
            "set_regs",
        )?;
        let mut fpu = kvm_fpu {
            fcw: 0x37f,
            mxcsr: 0x1f80,
            ..Default::default()
        };
        let mut xmm0 = [0u8; 16];
        xmm0[..8].copy_from_slice(&(seed ^ generation).to_le_bytes());
        xmm0[8..].copy_from_slice(&(id as u64 + 0x51eeb000).to_le_bytes());
        fpu.xmm[0] = xmm0;
        checked(vcpu.set_fpu(&fpu), "set_fpu")?;
        Ok(Self {
            vcpu,
            _vm: vm,
            memory,
            owner: owner.clone(),
            id,
            generation,
            initial,
            rounds: 0,
            halted: false,
            xmm0,
        })
    }
    fn next(&mut self) -> Result<Exit> {
        self.owner.check();
        require(!self.halted, "running halted incarnation")?;
        self.vcpu.set_kvm_immediate_exit(0);
        loop {
            match self.vcpu.run() {
                Ok(VcpuExit::IoOut(port, data)) => {
                    require(
                        port == PORT && data.len() == 2,
                        format!("unexpected PIO port={port:#x} bytes={}", data.len()),
                    )?;
                    let value = u16::from_le_bytes(data.try_into().unwrap());
                    // IO can be incomplete on return. Reentry completes it, but must
                    // not execute the next guest instruction or create a world event.
                    self.vcpu.set_kvm_immediate_exit(1);
                    let completion = self.vcpu.run();
                    require(
                        matches!(&completion, Err(e) if e.errno() == libc::EINTR),
                        format!("completion-only reentry returned {completion:?}"),
                    )?;
                    self.vcpu.set_kvm_immediate_exit(0);
                    let regs = checked(self.vcpu.get_regs(), "completed regs")?;
                    require(
                        regs.rip == YIELD_NEXT,
                        format!("completion RIP {:#x} != {YIELD_NEXT:#x}", regs.rip),
                    )?;
                    return Ok(Exit::Yield(value));
                }
                Ok(VcpuExit::Hlt) => {
                    self.halted = true;
                    return Ok(Exit::Halt);
                }
                Err(e) if e.errno() == libc::EINTR => continue, // transparent host interruption
                other => return Err(format!("unexpected guest exit: {other:?}")),
            }
        }
    }
    fn validate_main_yield(&mut self, value: u16) -> Result<()> {
        self.owner.check();
        require(value == self.rounds, "PIO round tag mismatch")?;
        let expected = self
            .initial
            .wrapping_add(257u16.wrapping_mul(self.rounds + 1));
        require(
            self.memory.word(0x400) == expected,
            format!(
                "isolation_counter machine={} generation={} round={} expected={expected} actual={}",
                self.id,
                self.generation,
                self.rounds,
                self.memory.word(0x400)
            ),
        )?;
        require(
            self.memory.word(0x404) == self.rounds,
            "guest round marker mismatch",
        )?;
        require(
            self.memory.word(0x406) == self.rounds,
            "completion-only reentry executed next guest instruction",
        )?;
        let stored = f64::from_le_bytes(self.memory.bytes()[0x410..0x418].try_into().unwrap());
        let fp_expected = (self.id as f64 + self.generation as f64 * 10.0)
            * 2f64.powi(i32::from(self.rounds) + 1);
        require(
            stored == fp_expected,
            format!("x87 isolation mismatch stored={stored} expected={fp_expected}"),
        )?;
        let fpu = checked(self.vcpu.get_fpu(), "get_fpu")?;
        require(
            fpu.xmm[0] == self.xmm0,
            "XMM0 state leaked across vCPU contexts",
        )?;
        self.rounds += 1;
        Ok(())
    }
    fn snapshot(&self) -> Result<Value> {
        self.owner.check();
        let r = checked(self.vcpu.get_regs(), "snapshot regs")?;
        let regs = [
            r.rax, r.rbx, r.rcx, r.rdx, r.rsi, r.rdi, r.rsp, r.rbp, r.r8, r.r9, r.r10, r.r11,
            r.r12, r.r13, r.r14, r.r15, r.rip, r.rflags,
        ];
        let mut rb = Vec::new();
        for value in regs {
            rb.extend_from_slice(&value.to_le_bytes());
        }
        let f = checked(self.vcpu.get_fpu(), "snapshot fpu")?;
        let mut fb = Vec::new();
        fb.extend_from_slice(&f.fcw.to_le_bytes());
        fb.extend_from_slice(&f.fsw.to_le_bytes());
        fb.push(f.ftwx);
        fb.extend_from_slice(&f.last_opcode.to_le_bytes());
        fb.extend_from_slice(&f.last_ip.to_le_bytes());
        fb.extend_from_slice(&f.last_dp.to_le_bytes());
        fb.extend_from_slice(&f.mxcsr.to_le_bytes());
        // Hash meaningful 80-bit register bytes, not ABI padding.
        for reg in f.fpr {
            fb.extend_from_slice(&reg[..10]);
        }
        for reg in f.xmm {
            fb.extend_from_slice(&reg);
        }
        Ok(
            json!({"id":self.id,"generation":self.generation,"rounds":self.rounds,"rip":r.rip,"regs_sha256":hash(&rb),"memory_sha256":hash(self.memory.bytes()),"legacy_fpu_xmm_sha256":hash(&fb)}),
        )
    }
}
impl Drop for Machine {
    fn drop(&mut self) {
        self.owner.check();
    }
}

fn choice(rng: &mut u64) -> u64 {
    *rng = rng.wrapping_add(0x9e3779b97f4a7c15);
    let mut z = *rng;
    z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
    z ^ (z >> 31)
}
fn world(kvm: &Kvm, owner: &Owner, seed: u64, omit_generation_guard: bool) -> Result<Value> {
    owner.check();
    let mut machines = vec![
        Machine::new(kvm, owner, 0, 1, seed, MAIN, None, true)?,
        Machine::new(kvm, owner, 1, 1, seed, MAIN, None, true)?,
    ];
    let mut rng = seed;
    let mut tick = 0u64;
    let mut events = Vec::new();
    let mut boundaries = Vec::new();
    let mut stale_callbacks = 0;
    let mut pending_callbacks: Vec<(u64, u64, u16)> = Vec::new();
    while machines.iter().any(|m| !m.halted) {
        owner.check();
        require(events.len() < 64, "finite fixture exceeded event budget")?;
        let live: Vec<_> = machines
            .iter()
            .enumerate()
            .filter(|(_, m)| !m.halted)
            .map(|(i, _)| i)
            .collect();
        let id = live[choice(&mut rng) as usize % live.len()];
        match machines[id].next()? {
            Exit::Yield(value) => {
                machines[id].validate_main_yield(value)?;
                tick += 1;
                if id == 0 && machines[id].generation == 1 && machines[id].rounds == 1 {
                    pending_callbacks.push((64, 1, 0xbad));
                }
                boundaries.push(machines[id].snapshot()?);
                events.push(json!({"tick":tick,"kind":"yield","id":id,"generation":machines[id].generation,"value":value}));
                if id == 0 && machines[id].generation == 1 && machines[id].rounds == 3 {
                    let dead = machines.remove(0);
                    drop(dead); // descriptors close before reboot backing
                    let new = Machine::new(kvm, owner, 0, 2, seed, MAIN, None, true)?;
                    machines.insert(0, new);
                    pending_callbacks.push((63, 2, 0xcafe));
                    events.push(json!({"tick":tick,"kind":"reboot","id":0,"generation":2}));
                }
                if id == 0 && machines[id].generation == 2 && machines[id].rounds == 8 {
                    // A current completion arrives first; a retired incarnation's
                    // late completion must not overwrite it before guest consumes it.
                    require(pending_callbacks.len() == 2, "completion tokens missing")?;
                    pending_callbacks.sort_by_key(|(due, _, _)| *due);
                    for (due, generation, payload) in pending_callbacks.drain(..) {
                        owner.check();
                        tick = tick.max(due);
                        if machines[0].generation != generation && !omit_generation_guard {
                            stale_callbacks += 1;
                            events.push(json!({"tick":tick,"kind":"stale_completion_rejected","id":0,"generation":generation}));
                        } else {
                            machines[0].memory.write(0x450, &payload.to_le_bytes());
                            events.push(json!({"tick":tick,"kind":"completion_applied","id":0,"generation":generation}));
                        }
                    }
                }
            }
            Exit::Halt => {
                require(machines[id].rounds == 8, "early HLT")?;
                require(
                    machines[id].memory.word(0x406) == 8,
                    "terminal segment missing",
                )?;
                if id == 0 && machines[id].generation == 2 {
                    require(
                        machines[id].memory.word(0x454) == 0xcafe,
                        format!(
                            "incarnation_callback_corruption guest_consumed={:#x}",
                            machines[id].memory.word(0x454)
                        ),
                    )?;
                }
                tick += 1;
                events.push(
                    json!({"tick":tick,"kind":"halt","id":id,"generation":machines[id].generation}),
                );
                boundaries.push(machines[id].snapshot()?);
            }
        }
    }
    require(
        pending_callbacks.is_empty() && stale_callbacks == 1,
        "incarnation callback dispatch did not finish",
    )?;
    let finals = machines
        .iter()
        .map(Machine::snapshot)
        .collect::<Result<Vec<_>>>()?;
    let event_bytes = checked(serde_json::to_vec(&events), "serialize events")?;
    let boundary_bytes = checked(serde_json::to_vec(&boundaries), "serialize boundaries")?;
    Ok(
        json!({"seed":seed,"events":events,"event_sha256":hash(&event_bytes),"completed_boundaries":boundaries,"boundaries_sha256":hash(&boundary_bytes),"finals":finals,"stale_callbacks_rejected":stale_callbacks}),
    )
}
fn alias_negative(kvm: &Kvm, owner: &Owner, seed: u64) -> Result<()> {
    owner.check();
    let shared = Arc::new(Mapping::new(owner)?);
    let mut writer = Machine::new(kvm, owner, 0, 1, seed, MAIN, Some(shared.clone()), true)?;
    let mut reader = Machine::new(kvm, owner, 1, 1, seed, MAIN, Some(shared), true)?;
    // Both VMs are initialized before this witness. VM0's real guest stores
    // modify VM1's backing; VM1 then runs its normal counter oracle.
    require(
        matches!(writer.next()?, Exit::Yield(0)),
        "alias writer yield missing",
    )?;
    require(
        reader.memory.word(0x400) == reader.initial.wrapping_add(257),
        "alias fixture did not witness guest-store leakage",
    )?;
    let value = match reader.next()? {
        Exit::Yield(value) => value,
        Exit::Halt => return Err("alias reader halted early".into()),
    };
    reader.validate_main_yield(value)
}
fn rng_probe(kvm: &Kvm, owner: &Owner, code: &[u8], hide_rng: bool) -> Result<Value> {
    owner.check();
    let mut machine = Machine::new(kvm, owner, 9, 1, 0, code, None, hide_rng)?;
    require(
        matches!(machine.next()?, Exit::Yield(0xbabe)),
        "RNG probe yield missing",
    )?;
    let mem = machine.memory.bytes();
    let ecx = u32::from_le_bytes(mem[0x430..0x434].try_into().unwrap());
    let ebx = u32::from_le_bytes(mem[0x434..0x438].try_into().unwrap());
    let rdrand_advertised = ecx & (1 << 30) != 0;
    let rdseed_advertised = ebx & (1 << 18) != 0;
    require(
        !hide_rng || (!rdrand_advertised && !rdseed_advertised),
        "guest CPUID mask not applied",
    )?;
    let first_ud = machine.memory.word(0x42a);
    let total_ud = machine.memory.word(0x420);
    let result = json!({"ud_count":total_ud,"rdrand_ud_count":first_ud,"rdseed_ud_count":total_ud-first_ud,
        "rdrand_value":machine.memory.word(0x422),"rdrand_cf":mem[0x424],"rdseed_value":machine.memory.word(0x426),"rdseed_cf":mem[0x428],
        "rdrand_advertised":rdrand_advertised,"rdseed_advertised":rdseed_advertised,"cpuid_mask_requested":hide_rng});
    require(
        matches!(machine.next()?, Exit::Halt),
        "RNG probe terminal HLT missing",
    )?;
    Ok(result)
}
pub fn run() -> Result<()> {
    let owner = Owner::new();
    owner.check();
    let mut seed = 0x51eeb5eedu64;
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--once" => {}
            "--seed" => {
                let val = args.next().ok_or("--seed requires value")?;
                seed = if let Some(hex) = val.strip_prefix("0x") {
                    checked(u64::from_str_radix(hex, 16), "seed")?
                } else {
                    checked(val.parse(), "seed")?
                };
            }
            _ => return Err(format!("unknown argument {arg}")),
        }
    }
    let kvm = checked(Kvm::new(), "open /dev/kvm")?;
    require(
        kvm.check_extension(Cap::ImmediateExit),
        "KVM_CAP_IMMEDIATE_EXIT required",
    )?;
    eprintln!(
        "metadata host_tid={} kvm_api={} arch=x86_64 profile=bare_real_mode_no_irqchip",
        owner.tid,
        kvm.get_api_version()
    );
    let positive = world(&kvm, &owner, seed, false)?;
    match alias_negative(&kvm, &owner, seed) {
        Err(error) if error.contains("isolation_counter") => {
            eprintln!("NEGATIVE_CONTROL_REJECTED shared_memory_alias: {error}")
        }
        other => {
            return Err(format!(
                "shared-memory negative control was not rejected specifically: {other:?}"
            ));
        }
    }
    match world(&kvm, &owner, seed, true) {
        Err(error) if error.contains("incarnation_callback_corruption") => {
            eprintln!("NEGATIVE_CONTROL_REJECTED omitted_generation_guard: {error}")
        }
        other => {
            return Err(format!(
                "generation negative control not rejected specifically: {other:?}"
            ));
        }
    }
    let control = rng_probe(&kvm, &owner, UD_CONTROL, true)?;
    require(
        control["ud_count"] == 2,
        format!("#UD handler control failed: {control}"),
    )?;
    let native = rng_probe(&kvm, &owner, RNG, false)?;
    let raw = rng_probe(&kvm, &owner, RNG, true)?;
    let ud_count = raw["ud_count"].as_u64().ok_or("RNG UD count missing")?;
    let admission = if ud_count == 2 && native["ud_count"] == 0 {
        "direct_rng_faulted_with_hidden_cpuid"
    } else if ud_count < 2 {
        "raw_rng_enforcement_gap"
    } else {
        "raw_rng_absent_or_unavailable_control_inconclusive"
    };
    // Raw entropy observations go to stderr, intentionally outside deterministic
    // world comparison. A gap denies raw-instruction profile admission, not PIO.
    eprintln!("RNG_NATIVE_CONTROL {native}");
    eprintln!("RNG_PROBE {raw}");
    eprintln!("RNG_ADMISSION {admission}; CPL3_TSD_GP=NOT_TESTED; XSAVE_AVX=NOT_TESTED");
    println!(
        "{}",
        json!({"profile":"bounded_cpl0_pio_x87_two_vm","world":positive,"negative_alias_rejected":true,"negative_generation_guard_rejected":true,"ud_handler_control_pass":true,"raw_rng_ud_count":ud_count,"native_rng_ud_count":native["ud_count"],"native_rdrand_advertised":native["rdrand_advertised"],"native_rdseed_advertised":native["rdseed_advertised"],"raw_rng_admission":admission,"inputs":{"main_sha256":hash(MAIN),"rng_sha256":hash(RNG),"ud_control_sha256":hash(UD_CONTROL)},"not_tested":["guest_linux","cpl3_tsd_gp","irq_timer_delivery","avx_xsave","infinite_spin_preemption"]})
    );
    Ok(())
}
