import json
from pathlib import Path
root=Path(__file__).parent
u={'type':'integer','minimum':0,'maximum':18446744073709551615}
m={'type':'integer','minimum':0,'maximum':4294967295}
b={'type':'array','items':{'type':'integer','minimum':0,'maximum':255}}
def obj(props):return {'type':'object','properties':props,'required':list(props),'additionalProperties':False}
def tag(name,payload):return obj({name:payload})
def union(*variants):return {'oneOf':list(variants)}
owner=obj({'machine':m,'incarnation':u,'request':u})
scope=union(tag('Machine',m),tag('Az',m))
endpoint=union({'const':'Controller'},tag('Machine',m))
loss=obj({'from':scope,'to':scope,'bidirectional':{'type':'boolean'},'numerator':u,'denominator':u})
block=union(tag('Read',obj({'offset':u,'len':u})),tag('Write',obj({'offset':u,'data':b})),tag('WriteThrough',obj({'offset':u,'data':b})),{'const':'Flush'})
kind=union({'enum':['Tx','Write','Flush','Dma','Timeout','Obsolete','Slept']},tag('Read',b),tag('Reply',b))
nullable=lambda schema: union(schema,{'type':'null'})
completion=obj({'owner':nullable(owner),'kind':kind})
inspect=union(tag('Frame',obj({'wire_id':u})),tag('Storage',obj({'machine':m,'durable':{'type':'boolean'}})),tag('Memory',obj({'machine':m})),{'const':'StaleCount'},tag('Machine',obj({'machine':m})),{'const':'Time'})
command=union(*[tag(name,obj(props)) for name,props in {
'Sleep':{'after_ticks':u},'ArmSleep':{'after_ticks':u},'Fault':{'rule':loss},'Heal':{'handle':u},'Crash':{'machine':m},'Reboot':{'machine':m},
'Transmit':{'from':m,'to':endpoint,'bytes':b,'wire_delay_ticks':nullable(u)},'Block':{'machine':m,'op':block,'delay_ticks':u},'Dma':{'machine':m,'offset':u,'data':b,'delay_ticks':u},'Await':{'request':u},
'Query':{'destination':m,'frame':b,'correlation_u64_offset':u,'timeout_ticks':u},'Assert':{'label':{'type':'string'},'condition':{'type':'boolean'}},'Note':{'label':{'type':'string'},'detail':{}}
}.items()],tag('Inspect',inspect))
observation=union(*[tag(name,obj(props)) for name,props in {
'SleepArmed':{'request':u},'Slept':{'at_tick':u},'Lifecycle':{'machine':m,'incarnation':u,'alive':{'type':'boolean'}},'Transmitted':{'owner':owner,'wire_id':u},'Assertion':{'label':{'type':'string'},'passed':{'type':'boolean'}}
}.items()],tag('FaultApplied',u),{'const':'Healed'},tag('Submitted',owner),tag('Completion',completion),tag('Inspected',{}),{'const':'Noted'},tag('Error',{'type':'string'}))
identity={'version':{'const':1},'controller':u,'incarnation':u}
message=union(tag('Command',obj(dict(identity,id=u,command=command))),tag('Observation',obj(dict(identity,sequence=u,command=u,observation=observation))),tag('Ack',obj(dict(identity,sequence=u))))
message.update({'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:seedbox:control-message:v1','title':'Seedbox reliable control-device payload v1'})
(root/'control-message.schema.json').write_text(json.dumps(message,indent=2)+'\n')
contract={'execution_policy':'real Linux/KVM selected; preemption primary, cooperation fallback; this fixture executes neither backend mode','caller_ownership':'one caller OS thread for world, machines, devices and scenario actions','wire_version':1,'wire_schema':'control-message.schema.json','framing':'little-endian u32 payload byte length followed by UTF-8 JSON; maximum payload 16777216 bytes',
 'transport':'reserved reliable control device, distinct from opaque Ethernet application frames; observations retained until ordered Ack; duplicate identical commands are idempotent',
 'typed_ids':['MachineId(u32)','RequestId(u64)','ControllerId(u64)','CommandId(u64)','ObservationSequence(u64)','FaultHandle(u64)'],
 'control_ownership':'controller stable ID + controller incarnation + monotonically ordered command ID; workload ownership: machine stable ID + boot incarnation + request ID',
 'state_api':['World::encode_state/decode_state/validate_state','World::snapshot','NativeController: Serialize/Deserialize; issue/observe/validate'],
 'state_coverage':['World command ingress and complete payloads','pending queued/waiting requests','reliable response/observation outbox and ack sequences','event deadlines and registration sequence','volatile/durable block state and pending physical effects','frame bytes, inboxes, drop/delivery records','fault handles and rules','seed streams and counters','machine incarnations and DMA memory','workload and immune scenario-VM stopped-guest counter declarations','native controller program, pc, locals and pending command','scripted service pending flush replies'],
 'observer_history':'World trace is excluded from state; restored future regenerates without a prior execution log',
 'ordering':'one registered event; finish backend I/O/actions; publish observations; resume controller before next event at same tick',
 'clock':'integer branch-count-domain Tick; executed guest delta imported once at a stopped semantic boundary; all-blocked idle event jump is explicit model policy; rational integer ClockPolicy converts ticks into Linux ns and is not measured physical time',
 'stopped_guest_boundary':{'kinds':['CooperativeHook','DeviceExit','PrecisePreemption','Blocked','Halted','Shutdown','Fault','CompletionOnly'],'fields':['owner = Machine(Owner) | ScenarioVm{controller,incarnation}','boundary_sequence','rip','rep{rcx,rsi,rdi}','counter_origin','raw_counter','accumulated_guest_branches','delta_guest_branches','requested_target','actual_target','overshoot','pending_io_completed','tick_before','tick_after'],'policy':'debugger administration is outside semantic numbering; natural PIO/MMIO exits during correction are DeviceExit boundaries; completion-only delta is zero and imports change no canonical world state or numbering; scripted models cannot declare PrecisePreemption'},
 'not_executed':['guest scenario VM/control device','hardware preemption','actual Linux/virtio/TCP/filesystem behavior','snapshot of KVM hidden state'],
 'examples':[{'Command':{'version':1,'controller':1,'incarnation':1,'id':1,'command':{'Sleep':{'after_ticks':5}}}},{'Observation':{'version':1,'controller':1,'incarnation':1,'sequence':1,'command':1,'observation':{'Slept':{'at_tick':5}}}},{'Ack':{'version':1,'controller':1,'incarnation':1,'sequence':1}}]}
(root/'protocol-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
