#!/usr/bin/env bash
set -euo pipefail
task_world="$(cd "$(dirname "$0")" && pwd)"
task_evidence="$task_world/../evidence/w1/protocol-v2"
for task_source in lib protocol client main; do
  if [ "$task_source" = main ]; then task_key=fixture_sha256; else task_key="${task_source}_sha256"; fi
  task_actual="$(sha256sum "$task_world/src/$task_source.rs" | cut -d ' ' -f 1)"
  task_recorded="$(jq -r ".sources.$task_key" "$task_evidence/summary.json")"
  if [ "$task_actual" != "$task_recorded" ]; then echo "Source mismatch: $task_source" >&2; exit 1; fi
done
tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner -C "$task_world" -cf - Cargo.toml Cargo.lock src check.sh verify.sh freeze.sh schema.py control-message.schema.json protocol-contract.json | gzip -n > "$task_evidence/source.tar.gz"
sha256sum "$task_evidence/source.tar.gz" > "$task_evidence/source-tar-sha256.txt"
sha256sum "$task_world/freeze.sh" >> "$task_evidence/inputs-sha256.txt"
task_archive_hash="$(cut -d ' ' -f 1 "$task_evidence/source-tar-sha256.txt")"
jq -n --arg root "$task_evidence" --arg source_archive_sha256 "$task_archive_hash" --arg check_run "$1" --arg fresh_run "$2" --slurpfile summary "$task_evidence/summary.json" '{schema:2,wire_version:1,root:$root,source_archive_sha256:$source_archive_sha256,check_run:$check_run,fresh_run:$fresh_run,accepted:true,scope:"native control protocol and scripted model only; no executed guest control transport or hardware preemption",summary:$summary[0]}' > "$task_evidence/manifest.json"
sha256sum "$task_evidence/manifest.json"
cat "$task_evidence/source-tar-sha256.txt"
