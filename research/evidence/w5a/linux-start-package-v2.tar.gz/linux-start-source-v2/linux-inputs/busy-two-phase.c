#include <sys/io.h>
#include <unistd.h>
int main(void) {
 if(iopl(3))return 1;
 outb(1,0x530);
 unsigned long first,second;
 asm volatile("xor %%rax,%%rax\nmov $1000000,%%rcx\n.global seedbox_busy_first\nseedbox_busy_first:\ninc %%rax\ndec %%rcx\njnz seedbox_busy_first\n":"=a"(first)::"rcx","cc","memory");
 outb(3,0x530);
 asm volatile("xor %%rax,%%rax\nmov $1000000,%%rcx\n.global seedbox_busy_second\nseedbox_busy_second:\ninc %%rax\ndec %%rcx\njnz seedbox_busy_second\n":"=a"(second)::"rcx","cc","memory");
 outb(2,0x530);
 outl(first==1000000&&second==1000000?16:17,0xf4);
 for(;;){}
}
