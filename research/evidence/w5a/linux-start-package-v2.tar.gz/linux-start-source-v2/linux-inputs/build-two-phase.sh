#!/usr/bin/env bash
set -eu
root=/tmp/seedbox-round-1.S74xJ4/amd-counter/linux-inputs
cc="${SEEDBOX_STATIC_CC%/cc}/x86_64-unknown-linux-musl-cc"
mkdir -p "$root/two-phase-root"
"$cc" -O2 -static -fno-pie -no-pie "$root/busy-two-phase.c" -o "$root/two-phase-root/init"
cd "$root/two-phase-root"
find . -print0 |sort -z|cpio --null -o --format=newc > "$root/busy-two-phase-initramfs"
nm -n init |rg 'seedbox_busy_(first|second)'
sha256sum init "$root/busy-two-phase-initramfs"
