#!/usr/bin/env bash
set -eu
uname -a
lscpu
cat /proc/cmdline
cat /proc/sys/kernel/perf_event_paranoid
cat /proc/sys/kernel/nmi_watchdog
cat /sys/module/kvm/parameters/enable_pmu
cat /sys/bus/event_source/devices/cpu/type
cat /sys/bus/event_source/devices/cpu/caps/pmu_name 2>/dev/null || true
id
ls -l /dev/kvm /dev/cpu/0/msr
grep Cap /proc/self/status
rustc -Vv
cargo -V
nasm -v
sha256sum /tmp/seedbox-round-1.S74xJ4/env/flake.nix /tmp/seedbox-round-1.S74xJ4/env/flake.lock
