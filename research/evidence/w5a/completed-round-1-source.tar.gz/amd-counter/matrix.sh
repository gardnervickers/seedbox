#!/usr/bin/env bash
set -euo pipefail
cd /tmp/seedbox-round-1.S74xJ4/amd-counter
load_mode="${1:-idle}"
probe=target/debug/seedbox-amd-counter
pids=()
cleanup() { for pid in "${pids[@]}"; do kill "$pid" 2>/dev/null || true; done; }
trap cleanup EXIT
if [ "$load_mode" = loaded ]; then
 for cpu in 2 18 3 19; do taskset -c "$cpu" yes > /dev/null & pids+=("$!"); done
fi
printf '{"matrix_load":"%s","probe_cpu":2,"load_cpus":[2,18,3,19],"seed":42,"seed_use":"fixed fixtures, no random input"}\n' "$load_mode"
for repeat in $(seq 1 20); do
 for config in 'branch 10000 both 0 209 0' 'branch 10000 both 0 209 1000000' 'branch 10000000 both 0 209 0' 'lock 1000000 both 0 209 0' 'extra 10000 both 0 209 0' 'nonbranch 10000 both 0 209 0' 'branch 10000 user 0 209 0' 'branch 10000 kernel 0 209 0' 'user 10000 both 0 209 0' 'user 10000 user 0 209 0' 'user 10000 kernel 0 209 0' 'lock 10000 both 0 209 0' 'lock 10000 both 0 2085 0' 'branch 10000 both 281474976710156 209 0'; do
  timeout 15 taskset -c 2 "$probe" $config
 done
done
