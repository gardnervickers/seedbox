import json,sys,collections
p=sys.argv[1]
rows=[json.loads(s) for s in open(p) if s.startswith('{')]
groups=collections.defaultdict(list)
for r in rows:
 if 'mode' not in r: continue
 key=(r['mode'],r['cpl_filter'],r['event'],r['initial'],r['host_admin_iterations'],r['iterations'])
 groups[key].append(r)
out=[]
for k,rs in groups.items():
 counts=collections.Counter(r['delta_48'] for r in rs)
 out.append({'mode':k[0],'cpl_filter':k[1],'event':k[2],'initial':k[3],'admin_iterations':k[4],'guest_iterations':k[5],'fresh_runs':len(rs),'count_distribution':dict(counts),'guest_results':sorted(set(r['guest_result'] for r in rs)),'admin_counter_unchanged':all(r['before']==r['after_host_admin'] and r.get('end_after_host_admin',r['end'])==r['end'] for r in rs),'configuration_readback_matches':all(r['control']==r['configured_control'] for r in rs),'native_speclockmap_counts':sorted(set(r['native_speclockmap_probe'].get('count',-1) for r in rs))})
failures=[]
for r in rows:
 if 'mode' not in r or r['event']!=209:continue
 expected=0 if (r['mode']=='nonbranch' or (r['mode']=='user' and r['cpl_filter']=='kernel') or (r['mode']!='user' and r['cpl_filter']=='user')) else r['iterations']*(2 if r['mode']=='extra' else 1)
 guest_expected=350000 if r['mode']=='nonbranch' else (r['iterations'] if r['mode']=='lock' else (7*r['iterations'])&0xffffffff)
 if r['guest_result']!=guest_expected or r['boundary_tag']!=(2 if r['mode']=='user' else 3) or r['delta_48']!=expected or r['before']!=r['after_host_admin'] or r.get('end_after_host_admin',r['end'])!=r['end'] or r['configured_control']!=r['control']:
  failures.append(r)
assert not failures, failures
print(json.dumps({'input_file':p,'rows':len(rows),'groups':out},indent=2))
