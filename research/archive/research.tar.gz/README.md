# Seedbox

A Rust deterministic application sandbox. [DESIGN.md](DESIGN.md) is the single
source for objectives, decisions, architecture, experiment status and next work.
This README only covers running the code.

Dependencies are pinned by Cargo.lock and flake.lock; use nix develop or direnv.

```sh
nix develop --command cargo run -- build-guests
nix develop --command cargo run -- run examples/cluster.json --seed 42 --output artifacts/cluster-42.json
nix develop --command cargo run -- run examples/race.json --seed 42 --output artifacts/race-42.json
nix develop --command cargo run -- run examples/atomic.json --seed 42 --output artifacts/atomic-42.json
```

World manifests are under examples/. Executable paths are relative to the
manifest. Seeds are unsigned 64-bit integers; probabilities are integer parts
per million. Reports contain pinned inputs, virtual-time events, entered-step
digests, guest output and resource state. Add --instruction-trace for detailed
entered steps. CLI exits: 0 successful guests, 1 failed outcome, 2 invalid input.

Build Redis fixtures on an x86-64 Linux Nix host, then copy them to build/redis/
on the host running Seedbox:

```sh
seedbox_redis_fixtures=$(nix build --no-link --print-out-paths .#redis-fixtures)
mkdir -p build/redis
cp "$seedbox_redis_fixtures/bin/redis-server" "$seedbox_redis_fixtures/bin/redis-cli" "$seedbox_redis_fixtures/bin/redis-ttl-client" build/redis/
nix develop --command cargo run --release -- run examples/redis.json --seed 42 --output artifacts/redis-42.json
nix develop --command cargo run --release -- verify-redis --seeds 8
```

Validation and experimental reproduction commands are in DESIGN.md. Individual
experiments retain run/build scripts and raw evidence alongside their source.
