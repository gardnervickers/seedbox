; A raw SysV x86-64 function. The identical bytes can run under Unicorn or Linux.
; rdi -> control containing addresses resolved from io_uring_params offsets.
; SQE size 64, user_data at 32. CQE size 16, res at 8, flags at 12.
; No syscall, helper call, entropy, or time instruction occurs in this function.
BITS 64
push rbp
push rbx
push r12
push r13
push r14
push r15
mov r12, rdi
xor ebp, ebp                     ; submitted
xor ebx, ebx                     ; consumed
xor r15d, r15d                  ; seen completion IDs, total <= 32
mov r13d, [r12 + 80]             ; total count, multiple of two
.round:
mov rdx, [r12 + 72]              ; SQ flags
test dword [rdx], 1              ; IORING_SQ_NEED_WAKEUP
jnz .needs_wakeup
mov r8, [r12 + 8]               ; SQ tail
mov r14d, [r12 + 92]
.space:
mov rdx, [r12]                  ; SQ head, acquire before reusing SQ slots
mov eax, [r8]
sub eax, [rdx]
mov rdx, [r12 + 16]             ; ring capacity = mask + 1
mov esi, [rdx]
inc esi
sub esi, eax
cmp esi, 2
jae .ready
pause
dec r14d
jnz .space
jmp .timeout
.ready:
mov ecx, 2
.submit:
mov r8, [r12 + 8]               ; SQ tail pointer
mov eax, [r8]
mov rdx, [r12 + 16]              ; SQ mask pointer
mov esi, eax
and esi, [rdx]
mov r9, [r12 + 24]              ; SQ index array
mov [r9 + rsi * 4], esi
mov r9, [r12 + 32]              ; SQEs
shl rsi, 6
add r9, rsi
xor edx, edx
mov [r9], rdx                   ; IORING_OP_NOP=0, no flags
mov [r9 + 8], rdx
mov [r9 + 16], rdx
mov [r9 + 24], rdx
mov [r9 + 40], rdx
mov [r9 + 48], rdx
mov [r9 + 56], rdx
mov esi, ebp
mov rdx, 0xabc0000000000000
add rdx, rsi
mov [r9 + 32], rdx
inc eax
mov [r8], eax                   ; x86 store-release publishes the initialized SQE
inc ebp
dec ecx
jnz .submit
mfence                          ; order tail publication before wakeup flag read
mov ecx, 2
.consume:
mov r14d, [r12 + 92]            ; bounded native negative control
.poll:
mov r8, [r12 + 40]              ; CQ head
mov eax, [r8]
mov rdx, [r12 + 48]             ; CQ tail: acquire before reading entry
cmp eax, [rdx]
jne .available
mov rdx, [r12 + 72]
test dword [rdx], 1
jnz .needs_wakeup
pause
dec r14d
jnz .poll
.timeout:
mov dword [r12 + 84], 3         ; no completion within poll bound
jmp .return
.available:
mov rdx, [r12 + 56]             ; CQ mask
mov esi, eax
and esi, [rdx]
shl rsi, 4
mov r9, [r12 + 64]              ; CQEs
add r9, rsi
mov rdx, [r9]                  ; completion order is not an io_uring guarantee
mov rdi, 0xabc0000000000000
sub rdx, rdi
cmp rdx, r13
jae .failure
bts r15d, edx                  ; every submitted ID exactly once
jc .failure
cmp dword [r9 + 8], 0
jne .failure
cmp dword [r9 + 12], 0
jne .failure
inc eax
mov [r8], eax                   ; release CQ slot after consuming it
inc ebx
mov [r12 + 88], ebx
dec ecx
jnz .consume
cmp ebx, r13d
jb .round
mov dword [r12 + 84], 1
jmp .return
.failure:
mov dword [r12 + 84], 2
jmp .return
.needs_wakeup:
mov dword [r12 + 84], 4         ; reference environment stopped SQPOLL
.return:
mov eax, [r12 + 84]
pop r15
pop r14
pop r13
pop r12
pop rbx
pop rbp
ret
