#!/bin/sh
# Warm-start mapped-NOP oracle: exactly one setup-only wakeup enter in SQPOLL mode.
# Dependencies are supplied by the caller's Nix shell.
set -eu
if [ "$#" -ne 2 ]; then
  echo "usage: sh run-warm-start.sh GUEST_ASM_DIR NEW_RESULTS_DIR" >&2
  exit 2
fi
input_dir=$(cd "$1" && pwd)
fixture_dir=$(cd "$(dirname "$0")" && pwd)
mkdir "$2"
result_dir=$(cd "$2" && pwd)
for tool in gcc nasm timeout sha256sum; do
  command -v "$tool" >/dev/null || { echo "missing dependency: $tool" >&2; exit 2; }
done
cd "$fixture_dir"
printf '%s\n' 'ccd5965b7e1cd3fb7b1a91e8a5134b7028eadb5ebbfe0b542f80dc3b6edaae6d  linux-reference-warm-start.c' \
  | sha256sum -c - >"$result_dir/fixture-check.txt"
cd "$input_dir"
printf '%s\n' 'c58eca575c6e5bbaffe4c2466768f497871e90df3a003c6a5a30c467b2f9ec60  guest.asm' \
  | sha256sum -c - >"$result_dir/guest-source-check.txt"
cp "$fixture_dir/linux-reference-warm-start.c" guest.asm "$result_dir/"
cd "$result_dir"
gcc -std=c11 -O2 -Wall -Wextra -Werror linux-reference-warm-start.c -o linux-reference
nasm -f bin guest.asm -o guest.bin
printf '%s\n' '99be37f09e58bd669f4393fdd43203e45dbd9d5fb45c8dc28d327883978f8490  guest.bin' \
  | sha256sum -c - >guest-check.txt
sha256sum linux-reference-warm-start.c guest.asm linux-reference guest.bin >built-sha256.txt
uname -a >host.txt
gcc --version >compiler.txt
nasm -v >assembler.txt
for setting in io_uring_disabled io_uring_group; do
  if [ -r "/proc/sys/kernel/$setting" ]; then
    cat "/proc/sys/kernel/$setting" >"$setting.txt"
  fi
done

overall=0
for mode in sqpoll no-worker; do
  if (ulimit -t 5; timeout --signal=TERM --kill-after=2s 15s ./linux-reference "$mode" guest.bin) \
      >"$mode.stdout" 2>"$mode.stderr"; then
    status=0
  else
    status=$?
  fi
  printf '%s\n' "$status" >"$mode.exit"
  printf 'mode=%s exit=%s\n' "$mode" "$status"
  cat "$mode.stdout" "$mode.stderr"
  case "$status" in
    0) ;;
    77) if [ "$overall" -eq 0 ]; then overall=77; fi ;;
    *) overall=1 ;;
  esac
done

# An extra observational syscall audit, never substituted for the untraced run.
if [ "${TRACE_IO_URING:-0}" = 1 ]; then
  command -v strace >/dev/null || { echo "TRACE_IO_URING=1 requires strace" >&2; exit 2; }
  for mode in sqpoll no-worker; do
    if (ulimit -t 5; timeout --signal=TERM --kill-after=2s 15s \
        strace -f -e trace=io_uring_setup,io_uring_enter,io_uring_register \
        -o "$mode.strace" ./linux-reference "$mode" guest.bin) \
        >"$mode.traced.stdout" 2>"$mode.traced.stderr"; then
      status=0
    else
      status=$?
    fi
    printf '%s\n' "$status" >"$mode.traced.exit"
    awk '/io_uring_setup\(/ {setup++} /io_uring_enter\(/ {enter++} /io_uring_register\(/ {reg++}
      END {printf "setup=%d enter=%d register=%d\n",setup,enter,reg}' "$mode.strace" \
      >"$mode.syscall-counts.txt"
  done
fi
exit "$overall"
