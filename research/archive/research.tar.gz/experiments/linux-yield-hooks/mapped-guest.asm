BITS 64
section .text align=16
global mapped_guest
mapped_guest:
incbin "mapped-guest.bin"
section .note.GNU-stack noalloc noexec nowrite progbits
