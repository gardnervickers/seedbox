#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/io_uring.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

struct control {
    uint64_t sq_head, sq_tail, sq_mask, sq_array, sqes;
    uint64_t cq_head, cq_tail, cq_mask, cqes, sq_flags;
    uint32_t total, status, observed, poll_limit;
};
_Static_assert(sizeof(struct control) == 96, "guest control ABI");
_Static_assert(offsetof(struct control, total) == 80, "guest control offsets");
_Static_assert(sizeof(struct io_uring_sqe) == 64, "SQE64");
_Static_assert(sizeof(struct io_uring_cqe) == 16, "CQE16");
extern int mapped_guest(struct control *);
static volatile sig_atomic_t handled;
static void handler(int signal) { (void)signal; handled++; }
static void marker(unsigned char value) {
    __asm__ __volatile__("outb %b0, %w1" : : "a"(value), "Nd"((uint16_t)0xe9));
}
static _Noreturn void finish(int pass) {
    printf("OBS %s linux-yield-hooks\n", pass ? "PASS" : "FAIL");
    marker(pass ? '+' : '!');
    uint32_t value = pass ? 0x10 : 0x11;
    __asm__ __volatile__("outl %0, %w1" : : "a"(value), "Nd"((uint16_t)0xf4));
    for (;;) pause();
}
static void check(int okay, const char *what) {
    if (!okay) { printf("OBS FAIL check=%s errno=%d\n", what, errno); finish(0); }
}
static void sleep_ms(long ms) {
    struct timespec left = { .tv_sec = ms / 1000, .tv_nsec = (ms % 1000) * 1000000 };
    while (nanosleep(&left, &left) && errno == EINTR) {}
}
static void reap(pid_t child) {
    int status = -1;
    check(waitpid(child, &status, 0) == child, "waitpid");
    check(WIFEXITED(status) && WEXITSTATUS(status) == 0, "child-status");
}
static void pipe_case(void) {
    marker('1');
    int fds[2]; check(pipe(fds) == 0, "pipe");
    uint32_t *shared = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
                           MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    check(shared != MAP_FAILED, "shared-mmap");
    pid_t child = fork(); check(child >= 0, "fork");
    if (!child) {
        close(fds[0]); sleep_ms(20);
        __atomic_store_n(shared, 0x51, __ATOMIC_RELEASE);
        if (write(fds[1], "P", 1) != 1) _exit(1);
        _exit(0);
    }
    close(fds[1]); char byte = 0;
    check(read(fds[0], &byte, 1) == 1 && byte == 'P', "blocked-pipe-result");
    check(__atomic_load_n(shared, __ATOMIC_ACQUIRE) == 0x51, "shared-after-fork");
    reap(child); close(fds[0]); munmap(shared, 4096);
    puts("OBS pipe PASS bytes=1 shared=0x51 child=0");
}
static void signal_case(int restart) {
    marker(restart ? '3' : '2');
    handled = 0;
    struct sigaction act = { .sa_handler = handler, .sa_flags = restart ? SA_RESTART : 0 };
    sigemptyset(&act.sa_mask);
    check(sigaction(SIGUSR1, &act, NULL) == 0, "sigaction");
    int fds[2]; check(pipe(fds) == 0, "signal-pipe");
    pid_t parent = getpid(), child = fork(); check(child >= 0, "signal-fork");
    if (!child) {
        close(fds[0]); sleep_ms(20);
        if (kill(parent, SIGUSR1)) _exit(1);
        sleep_ms(20);
        if (write(fds[1], "S", 1) != 1) _exit(1);
        _exit(0);
    }
    close(fds[1]); char byte = 0; errno = 0;
    ssize_t first = read(fds[0], &byte, 1); int first_errno = errno;
    if (restart) {
        check(first == 1 && byte == 'S' && handled == 1, "SA_RESTART-result");
    } else {
        check(first == -1 && first_errno == EINTR && handled == 1, "EINTR-result");
        check(read(fds[0], &byte, 1) == 1 && byte == 'S', "post-EINTR-read");
    }
    reap(child); close(fds[0]);
    printf("OBS signal restart=%d PASS first=%zd errno=%d handled=%d bytes=1\n",
           restart, first, first_errno, (int)handled);
}
static uint32_t load(uint64_t ptr) {
    return __atomic_load_n((uint32_t *)(uintptr_t)ptr, __ATOMIC_ACQUIRE);
}
static uint64_t at(void *base, uint32_t offset) { return (uintptr_t)base + offset; }
static void *ring_map(int ring, size_t bytes, off_t offset) {
    void *map = mmap(NULL, bytes, PROT_READ | PROT_WRITE, MAP_SHARED, ring, offset);
    check(map != MAP_FAILED, "ring-mmap"); return map;
}
static void ring_case(int worker) {
    marker(worker ? '4' : '5');
    struct io_uring_params p = { .flags = worker ? IORING_SETUP_SQPOLL : 0,
                                .sq_thread_idle = worker ? 60000 : 0 };
    int ring = (int)syscall(SYS_io_uring_setup, 2, &p);
    check(ring >= 0, "io_uring_setup");
    size_t sq_size = p.sq_off.array + p.sq_entries * 4;
    size_t cq_size = p.cq_off.cqes + p.cq_entries * sizeof(struct io_uring_cqe);
    int single = !!(p.features & IORING_FEAT_SINGLE_MMAP);
    if (single && cq_size > sq_size) sq_size = cq_size;
    void *sq = ring_map(ring, sq_size, IORING_OFF_SQ_RING);
    void *cq = single ? sq : ring_map(ring, cq_size, IORING_OFF_CQ_RING);
    size_t sqe_size = p.sq_entries * sizeof(struct io_uring_sqe);
    void *sqes = ring_map(ring, sqe_size, IORING_OFF_SQES);
    struct control c = {
        .sq_head=at(sq,p.sq_off.head), .sq_tail=at(sq,p.sq_off.tail),
        .sq_mask=at(sq,p.sq_off.ring_mask), .sq_array=at(sq,p.sq_off.array), .sqes=(uintptr_t)sqes,
        .cq_head=at(cq,p.cq_off.head), .cq_tail=at(cq,p.cq_off.tail),
        .cq_mask=at(cq,p.cq_off.ring_mask), .cqes=at(cq,p.cq_off.cqes),
        .sq_flags=at(sq,p.sq_off.flags), .total=8, .poll_limit=10000000,
    };
    uint32_t initial_flags = load(c.sq_flags), polls = 0;
    if (worker) {
        /* One empty-ring setup-only wakeup; early-boot jiffies may keep a fresh
         * poller already active. This is not the native host's cold handshake. */
        check(syscall(SYS_io_uring_enter, ring, 0U, 0U, IORING_ENTER_SQ_WAKEUP,
                      NULL, 0UL) == 0, "SQ_WAKEUP-bootstrap");
        while ((load(c.sq_flags) & IORING_SQ_NEED_WAKEUP) && polls < c.poll_limit) {
            __asm__ __volatile__("pause" ::: "memory"); polls++;
        }
        check(!(load(c.sq_flags) & IORING_SQ_NEED_WAKEUP), "SQ_WAKEUP-cleared");
    }
    check(!load(c.sq_head) && !load(c.sq_tail) && !load(c.cq_head) && !load(c.cq_tail), "empty-before-guest");
    int status = mapped_guest(&c);
    if (worker) {
        polls = 0;
        while (load(c.sq_head) != 8 && polls < c.poll_limit) {
            __asm__ __volatile__("pause" ::: "memory"); polls++;
        }
        check(status == 1 && c.observed == 8 && load(c.sq_head) == 8 &&
              load(c.sq_tail) == 8 && load(c.cq_head) == 8 && load(c.cq_tail) == 8, "mapped-NOP-result");
        /* Leave an active empty poller while this task sleeps; actual kernel
         * loop hook coverage cannot be supplied by a userspace syscall hook. */
        sleep_ms(20);
    } else {
        check(status == 3 && !c.observed && !load(c.sq_head) && load(c.sq_tail) == 2 &&
              !load(c.cq_head) && !load(c.cq_tail), "no-worker-control");
    }
    printf("OBS sqpoll worker=%d PASS status=%d consumed=%u startup_flags=0x%x setup_enters=%d per_operation_enters=0\n",
           worker, status, c.observed, initial_flags, worker ? 1 : 0);
    munmap(sqes, sqe_size); if (!single) munmap(cq, cq_size);
    munmap(sq, sq_size); close(ring);
}
int main(void) {
    if (mount("devtmpfs", "/dev", "devtmpfs", 0, NULL) && errno != EBUSY) return 1;
    int console = open("/dev/console", O_RDWR); if (console < 0) return 1;
    for (int fd = 0; fd < 3; fd++) if (dup2(console, fd) < 0) return 1;
    if (console > 2) close(console);
    setvbuf(stdout, NULL, _IONBF, 0);
    check(syscall(SYS_iopl, 3) == 0, "iopl");
    check(syscall(9999) == -1 && errno == ENOSYS, "arm-invalid-syscall-ABI");
    puts("OBS begin linux-yield-hooks");
    pipe_case(); signal_case(0); signal_case(1); ring_case(1); ring_case(0);
    finish(1);
}
