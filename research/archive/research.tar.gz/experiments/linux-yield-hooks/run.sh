#!/bin/sh
set -eu
# Run inside the shared pinned Linux-platform Nix shell on x86-64 Linux.
source_dir=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
positive=$1
negative=$2
guest_build=$3
results=$4
rustc --edition=2024 -O "$source_dir/runner.rs" -o "$source_dir/runner"
qemu=$(command -v qemu-system-x86_64)
"$source_dir/runner" "$qemu" "$positive" "$negative" "$guest_build/initramfs.cpio" "$results"
uname -a >"$results/host.txt"
cat /proc/cpuinfo >"$results/cpu.txt"
rustc --version >"$results/rustc.txt"
qemu-system-x86_64 --version >"$results/qemu.txt"
sha256sum "$source_dir/runner.rs" "$source_dir/runner" "$source_dir/run.sh" "$positive" "$negative" \
  "$guest_build/initramfs.cpio" >"$results/runtime-inputs.sha256"
cp "$guest_build/guest-inputs.sha256" "$guest_build/compiler.txt" "$guest_build/assembler.txt" \
  "$guest_build/libc.txt" "$guest_build/elf-segments.txt" "$results/"
