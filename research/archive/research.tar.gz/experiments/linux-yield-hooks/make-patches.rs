use std::{fs, path::Path, process::Command};

fn once(input: String, from: &str, to: &str) -> String {
    assert_eq!(input.matches(from).count(), 1, "patch anchor absent/ambiguous: {from:?}");
    input.replacen(from, to, 1)
}
fn main() {
    let root = std::env::current_dir().unwrap();
    let source = root.join("source");
    let header = fs::read_to_string(root.join("seedbox_probe.h")).unwrap();
    for (label, sq_loop) in [("positive", true), ("no-sqpoll", false)] {
        let out = root.join("build").join(label);
        fs::create_dir_all(&out).unwrap();
        let mut files = Vec::new();
        for file in ["arch/x86/entry/common.c", "kernel/sched/core.c", "kernel/sched/idle.c", "io_uring/sqpoll.c"] {
            let original = fs::read_to_string(source.join(file)).unwrap();
            let mut text = once(original, "// SPDX-License-Identifier:", "#include <linux/seedbox_probe.h>\n// SPDX-License-Identifier:");
            if file == "arch/x86/entry/common.c" {
                text = once(text, "#ifdef CONFIG_X86_64\n", "bool seedbox_probe_enabled;\nu32 seedbox_probe_counts[8];\n\n#ifdef CONFIG_X86_64\n");
                text = once(text, "\tnr = syscall_enter_from_user_mode(regs, nr);\n\n\tinstrumentation_begin();\n", "\tnr = syscall_enter_from_user_mode(regs, nr);\n\n\tinstrumentation_begin();\n\t/* Reserved invalid syscall arms diagnostics; its ABI remains ENOSYS. */\n\tif (nr == 9999)\n\t\tWRITE_ONCE(seedbox_probe_enabled, true);\n\tseedbox_probe_emit(0); /* A: native syscall entered after entry work */\n");
                text = once(text, "\tinstrumentation_end();\n\tsyscall_exit_to_user_mode(regs);\n\n\t/*\n\t * Check that the register state", "\tseedbox_probe_emit(1); /* B: dispatch finished, not final user result */\n\tinstrumentation_end();\n\tsyscall_exit_to_user_mode(regs);\n\tseedbox_probe_emit(2); /* C: final return prepared; inline noinstr PIO */\n\n\t/*\n\t * Check that the register state");
            } else if file == "kernel/sched/core.c" {
                text = once(text, "\tprev_state = READ_ONCE(prev->__state);\n\tif (sched_mode == SM_IDLE)", "\tprev_state = READ_ONCE(prev->__state);\n\tseedbox_probe_emit(prev_state ? 4 : 3); /* E: nonrunning; D: runnable */\n\tif (sched_mode == SM_IDLE)");
            } else if file == "kernel/sched/idle.c" {
                text = once(text, "\twhile (!need_resched()) {\n", "\twhile (!need_resched()) {\n\t\tseedbox_probe_emit(5); /* F: actual idle loop */\n");
            } else {
                if sq_loop {
                    text = once(text, "\t\tstruct io_sq_time ist = { };\n", "\t\tstruct io_sq_time ist = { };\n\n\t\tseedbox_probe_emit(6); /* G: actual SQPOLL iteration, even empty */\n");
                }
                text = once(text, "\t\t\tint ret = __io_sq_thread(ctx, sqd, cap_entries, &ist);\n", "\t\t\tint ret = __io_sq_thread(ctx, sqd, cap_entries, &ist);\n\t\t\tif (ret > 0)\n\t\t\t\tseedbox_probe_emit(7); /* H: actual submission progress */\n");
            }
            let dest = out.join(file);
            fs::create_dir_all(dest.parent().unwrap()).unwrap();
            fs::write(&dest, text).unwrap();
            files.push((file, source.join(file), dest));
        }
        let dest = out.join("include/linux/seedbox_probe.h");
        fs::create_dir_all(dest.parent().unwrap()).unwrap();
        fs::write(&dest, &header).unwrap();
        files.push(("include/linux/seedbox_probe.h", Path::new("/dev/null").to_owned(), dest));
        let mut patch = Vec::new();
        for (file, original, dest) in files {
            let old_label = if original == Path::new("/dev/null") { "/dev/null".to_string() } else { format!("a/{file}") };
            let result = Command::new("diff").args(["-u", "-L", &old_label, "-L", &format!("b/{file}")]).arg(original).arg(dest).output().unwrap();
            assert_eq!(result.status.code(), Some(1));
            patch.extend(result.stdout);
        }
        fs::write(root.join(format!("hooks-{label}.patch")), patch).unwrap();
    }
}
