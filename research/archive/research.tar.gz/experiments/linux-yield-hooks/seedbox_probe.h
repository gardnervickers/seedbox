/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef _LINUX_SEEDBOX_PROBE_H
#define _LINUX_SEEDBOX_PROBE_H
#include <linux/compiler.h>
#include <linux/types.h>

/* Observation-only experiment. No allocation, calls, IRQ changes or schedule().
 * Every enabled phase still emits the intervention PIO after debug capture caps.
 * Atomic diagnostics tolerate IRQ reentry; UP is the tested configuration.
 */
extern bool seedbox_probe_enabled;
extern u32 seedbox_probe_counts[8];
static __always_inline void seedbox_probe_emit(unsigned int phase)
{
	u32 old = 1;
	u8 tag = 'A' + phase;
	if (!READ_ONCE(seedbox_probe_enabled))
		return;
	asm volatile("outb %b0, %w1" : : "a"(tag), "Nd"((u16)0x510) : "memory");
	asm volatile("lock; xaddl %0, %1"
		: "+r"(old), "+m"(seedbox_probe_counts[phase]) : : "memory", "cc");
	if (old < 128)
		asm volatile("outb %b0, %w1" : : "a"(tag), "Nd"((u16)0xe9) : "memory");
}
#endif
