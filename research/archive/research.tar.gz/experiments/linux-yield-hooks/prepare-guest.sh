#!/bin/sh
set -eu
source_dir=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
guest_input=$1
output=$2
mkdir -p "$output"
output=$(CDPATH= cd -- "$output" && pwd)
cp "$guest_input" "$output/guest.asm"
cd "$output"
printf '%s\n' 'c58eca575c6e5bbaffe4c2466768f497871e90df3a003c6a5a30c467b2f9ec60  guest.asm' | sha256sum -c -
nasm -f bin guest.asm -o mapped-guest.bin
printf '%s\n' '99be37f09e58bd669f4393fdd43203e45dbd9d5fb45c8dc28d327883978f8490  mapped-guest.bin' | sha256sum -c -
nasm -f elf64 "$source_dir/mapped-guest.asm" -o mapped-guest.o
mkdir -p initramfs-root/dev
gcc -static -std=c11 -O2 -Wall -Wextra -Werror -Wl,--build-id=none \
  "$source_dir/init.c" mapped-guest.o -o initramfs-root/init
chmod 0755 initramfs-root/init
TZ=UTC find initramfs-root -exec touch -h -t 197001010000.00 {} +
(cd initramfs-root && find . -print | LC_ALL=C sort | cpio --quiet -o -H newc --reproducible --owner=0:0) >initramfs.cpio
sha256sum "$source_dir/init.c" "$source_dir/mapped-guest.asm" "$source_dir/prepare-guest.sh" \
  guest.asm mapped-guest.bin mapped-guest.o initramfs-root/init initramfs.cpio >guest-inputs.sha256
gcc --version >compiler.txt
nasm -v >assembler.txt
printf 'static_libc=%s\n' "${GUEST_STATIC_LIBC:-unrecorded}" >libc.txt
readelf -l initramfs-root/init >elf-segments.txt
