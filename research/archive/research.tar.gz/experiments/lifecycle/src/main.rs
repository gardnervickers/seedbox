//! Isolated lifecycle mechanism probe; this is not the Seedbox Linux model.
use seedbox::{
    backend::{Process, StopReason, SyscallRequest},
    fixtures,
    random::RandomStream,
    runtime::{canonical, digest},
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    cell::RefCell,
    collections::BTreeMap,
    future::Future,
    pin::Pin,
    rc::Rc,
    task::{Context, Poll, Waker},
    thread::{self, ThreadId},
};

const CRASH_AT: u64 = 200;
const REBOOT_AT: u64 = 220;
const READ_DELAY: u64 = 400;

struct Images {
    old: Vec<u8>,
    spinner: Vec<u8>,
    new: Vec<u8>,
}

fn assemble(body: &str, data: &str, bss: &str) -> Vec<u8> {
    let dir = tempfile::tempdir().unwrap();
    let source = dir.path().join("guest.asm");
    let output = dir.path().join("guest");
    std::fs::write(
        &source,
        format!(
            "bits 64\nglobal _start\nsection .text\n_start:\n{body}\nsection .data\n{data}\nsection .bss\n{bss}\n"
        ),
    )
    .unwrap();
    fixtures::assemble(&source, &output, false).unwrap();
    std::fs::read(output).unwrap()
}

fn images() -> Images {
    Images {
        old: assemble(
            "mov eax,1\nmov edi,3\nlea rsi,[rel committed]\nmov edx,1\nsyscall\nmov eax,74\nmov edi,3\nsyscall\nmov eax,1\nmov edi,3\nlea rsi,[rel volatile]\nmov edx,1\nsyscall\nxor eax,eax\nmov edi,3\nlea rsi,[rel buffer]\nmov edx,1\nsyscall\njmp $",
            "committed: db 'D'\nvolatile: db 'V'",
            "buffer: resb 1",
        ),
        spinner: assemble("inc rbx\njmp _start", "", ""),
        new: assemble(
            "xor eax,eax\nmov edi,3\nlea rsi,[rel buffer]\nmov edx,1\nsyscall\nmov eax,1\nmov edi,1\nlea rsi,[rel buffer]\nmov edx,1\nsyscall\nmov eax,60\nxor edi,edi\nsyscall",
            "",
            "buffer: resb 1",
        ),
    }
}

struct Guest {
    process: Process,
    blocked: bool,
    exited: bool,
}

struct PendingRead {
    request: SyscallRequest,
    // Deliberately reused after reboot. Incarnation must also participate.
    wait_id: u64,
}

enum Event {
    ScenarioWake,
    Read {
        incarnation: u64,
        wait_id: u64,
        byte: u8,
    },
}

struct World {
    owner: ThreadId,
    seed: u64,
    schedule: RandomStream,
    now: u64,
    sequence: u64,
    incarnation: u64,
    main: Option<Guest>,
    spinner: Option<Guest>,
    pending: Option<PendingRead>,
    volatile: u8,
    durable: u8,
    health: Option<u8>,
    queue: BTreeMap<(u64, u64), Event>,
    scenario_ready: bool,
    guard_incarnation: bool,
    stale_rejected: u64,
    guest_steps: u64,
    spinner_steps: u64,
    instruction_hash: Sha256,
    trace: Vec<Value>,
}

impl World {
    fn check_thread(&self) {
        assert_eq!(self.owner, thread::current().id());
    }

    fn emit(&mut self, kind: &str, detail: Value) {
        self.check_thread();
        self.trace
            .push(json!({"time": self.now, "event": kind, "detail": detail}));
    }

    fn schedule(&mut self, at: u64, event: Event) {
        assert!(at >= self.now);
        self.sequence += 1;
        self.queue.insert((at, self.sequence), event);
    }

    fn guest(&self, image: &[u8], name: &str) -> Guest {
        self.check_thread();
        Guest {
            process: Process::new(
                name,
                image,
                &mut RandomStream::new(self.seed, &format!("{name}:{}", self.incarnation)),
                &[name.into()],
                // Main PID/address/wait reuse deliberately stresses stale ownership.
                if name == "spinner" { 2 } else { 1 },
            )
            .unwrap(),
            blocked: false,
            exited: false,
        }
    }

    fn new(images: &Images, seed: u64, guard_incarnation: bool) -> Self {
        let mut world = Self {
            owner: thread::current().id(),
            seed,
            schedule: RandomStream::new(seed, "lifecycle:schedule"),
            now: 0,
            sequence: 0,
            incarnation: 1,
            main: None,
            spinner: None,
            pending: None,
            volatile: b'0',
            durable: b'0',
            health: None,
            queue: BTreeMap::new(),
            scenario_ready: true,
            guard_incarnation,
            stale_rejected: 0,
            guest_steps: 0,
            spinner_steps: 0,
            instruction_hash: Sha256::new(),
            trace: Vec::new(),
        };
        world.main = Some(world.guest(&images.old, "old"));
        world.spinner = Some(world.guest(&images.spinner, "spinner"));
        world.emit("boot", json!({"incarnation": 1}));
        world
    }

    fn crash(&mut self) {
        self.check_thread();
        assert_eq!(self.now, CRASH_AT);
        assert_eq!(self.durable, b'D', "fixture must fsync before crash");
        assert_eq!(self.volatile, b'V');
        assert!(
            self.pending.is_some(),
            "old asynchronous read must be pending"
        );
        assert!(
            self.spinner_steps > 0,
            "syscall-free guest must be exercised"
        );
        self.main = None;
        self.spinner = None;
        self.pending = None;
        self.volatile = self.durable;
        self.emit("crash", json!({"incarnation": self.incarnation}));
    }

    fn reboot(&mut self, image: &[u8]) {
        self.check_thread();
        assert_eq!(self.now, REBOOT_AT);
        assert!(self.main.is_none() && self.spinner.is_none());
        self.incarnation += 1;
        self.main = Some(self.guest(image, "new"));
        self.emit("boot", json!({"incarnation": self.incarnation}));
    }

    fn deliver(&mut self) {
        self.check_thread();
        while self
            .queue
            .first_key_value()
            .is_some_and(|((at, _), _)| *at == self.now)
        {
            let (_, event) = self.queue.pop_first().unwrap();
            match event {
                Event::ScenarioWake => self.scenario_ready = true,
                Event::Read {
                    incarnation,
                    wait_id,
                    byte,
                } => {
                    if self.guard_incarnation && incarnation != self.incarnation {
                        self.stale_rejected += 1;
                        self.emit(
                            "stale_read_rejected",
                            json!({"owner": incarnation, "current": self.incarnation}),
                        );
                        continue;
                    }
                    if !self
                        .pending
                        .as_ref()
                        .is_some_and(|pending| pending.wait_id == wait_id)
                    {
                        self.emit("read_without_waiter", json!({"owner": incarnation}));
                        continue;
                    }
                    let pending = self.pending.take().unwrap();
                    let guest = self.main.as_mut().unwrap();
                    guest
                        .process
                        .write(pending.request.args[1], &[byte])
                        .unwrap();
                    guest.process.complete(1, &pending.request, 1).unwrap();
                    guest.blocked = false;
                    self.emit(
                        "read_completed",
                        json!({"owner": incarnation, "current": self.incarnation, "byte": byte}),
                    );
                }
            }
        }
    }

    fn execute(&mut self) {
        self.check_thread();
        let main_ready = self
            .main
            .as_ref()
            .is_some_and(|guest| !guest.blocked && !guest.exited);
        let spin_ready = self.spinner.is_some();
        if !main_ready && !spin_ready {
            self.now = self
                .queue
                .first_key_value()
                .expect("live scenario needs future work")
                .0
                .0;
            self.emit("advance", json!({}));
            return;
        }
        let spinner = spin_ready && (!main_ready || self.schedule.below(2) == 1);
        let mut budget = 1 + self.schedule.below(7);
        if let Some(((at, _), _)) = self.queue.first_key_value() {
            budget = budget.min(*at - self.now);
        }
        assert!(budget > 0);
        let guest = if spinner {
            self.spinner.as_mut().unwrap()
        } else {
            self.main.as_mut().unwrap()
        };
        let stop = guest
            .process
            .run(if spinner { 2 } else { 1 }, budget)
            .unwrap();
        assert!(stop.steps <= budget && stop.steps > 0);
        assert_eq!(stop.steps as usize, stop.entered.len());
        for instruction in &stop.entered {
            self.instruction_hash.update([u8::from(spinner)]);
            self.instruction_hash.update(self.incarnation.to_le_bytes());
            self.instruction_hash.update(instruction.pc.to_le_bytes());
            self.instruction_hash
                .update((instruction.bytes.len() as u64).to_le_bytes());
            self.instruction_hash.update(&instruction.bytes);
        }
        self.now += stop.steps;
        self.guest_steps += stop.steps;
        if spinner {
            self.spinner_steps += stop.steps;
        }
        self.emit("stop", json!({"spinner": spinner, "incarnation": self.incarnation, "steps": stop.steps, "reason": stop.reason.as_str()}));
        assert!(matches!(
            stop.reason,
            StopReason::Quantum | StopReason::Syscall
        ));
        if let Some(request) = stop.request {
            let guest = self.main.as_mut().unwrap();
            match (request.number, request.args[0]) {
                (1, 3) => {
                    assert_eq!(request.args[2], 1);
                    self.volatile = guest.process.read(request.args[1], 1).unwrap()[0];
                    guest.process.complete(1, &request, 1).unwrap();
                    self.emit("write", json!({"byte": self.volatile}));
                }
                (74, 3) => {
                    self.durable = self.volatile;
                    guest.process.complete(1, &request, 0).unwrap();
                    self.emit("fsync", json!({"byte": self.durable}));
                }
                (0, 3) => {
                    guest.blocked = true;
                    self.pending = Some(PendingRead {
                        request,
                        wait_id: 1,
                    });
                    self.schedule(
                        self.now + READ_DELAY,
                        Event::Read {
                            incarnation: self.incarnation,
                            wait_id: 1,
                            byte: self.volatile,
                        },
                    );
                    self.emit(
                        "read_submitted",
                        json!({"owner": self.incarnation, "byte": self.volatile}),
                    );
                }
                (1, 1) => {
                    self.health = Some(guest.process.read(request.args[1], 1).unwrap()[0]);
                    guest.process.complete(1, &request, 1).unwrap();
                    self.scenario_ready = true;
                    self.emit("health_output", json!({"byte": self.health}));
                }
                (60, 0) => guest.exited = true,
                _ => panic!("unexpected fixture syscall"),
            }
        }
    }

    fn report(&self, healthy: bool) -> Value {
        json!({
            "seed": self.seed,
            "generation_guard": self.guard_incarnation,
            "healthy": healthy,
            "health_byte": self.health,
            "virtual_time": self.now,
            "incarnation": self.incarnation,
            "durable_byte": self.durable,
            "volatile_byte": self.volatile,
            "stale_rejected": self.stale_rejected,
            "guest_steps": self.guest_steps,
            "spinner_steps": self.spinner_steps,
            "instruction_sha256": hex::encode(self.instruction_hash.clone().finalize()),
            "trace_sha256": digest(&canonical(&json!(self.trace))),
            "trace": self.trace,
        })
    }
}

#[derive(Clone)]
struct Handle(Rc<RefCell<World>>);

impl Handle {
    fn sleep(&self, delay: u64) -> Sleep {
        Sleep {
            handle: self.clone(),
            at: self.0.borrow().now + delay,
            registered: false,
        }
    }
    fn health(&self) -> Health {
        Health {
            handle: self.clone(),
            timeout: self.sleep(800),
        }
    }
}

struct Sleep {
    handle: Handle,
    at: u64,
    registered: bool,
}

impl Future for Sleep {
    type Output = ();
    fn poll(mut self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<()> {
        let mut world = self.handle.0.borrow_mut();
        world.check_thread();
        if world.now >= self.at {
            return Poll::Ready(());
        }
        if !self.registered {
            world.schedule(self.at, Event::ScenarioWake);
            drop(world);
            self.registered = true;
        }
        Poll::Pending
    }
}

struct Health {
    handle: Handle,
    timeout: Sleep,
}

impl Future for Health {
    type Output = u8;
    fn poll(mut self: Pin<&mut Self>, context: &mut Context<'_>) -> Poll<u8> {
        if let Some(byte) = self.handle.0.borrow().health {
            return Poll::Ready(byte);
        }
        assert!(
            Pin::new(&mut self.timeout).poll(context).is_pending(),
            "health query deadline elapsed"
        );
        Poll::Pending
    }
}

fn run(images: &Images, seed: u64, guard: bool) -> Value {
    let world = Rc::new(RefCell::new(World::new(images, seed, guard)));
    let handle = Handle(world.clone());
    let mut scenario = std::pin::pin!(async {
        handle.sleep(CRASH_AT).await;
        handle.0.borrow_mut().crash();
        handle.sleep(REBOOT_AT - CRASH_AT).await;
        handle.0.borrow_mut().reboot(&images.new);
        let health = handle.health().await;
        let state = handle.0.borrow();
        health == b'D'
            && state.stale_rejected == 1
            && state.volatile == b'D'
            && state.durable == b'D'
    });
    let mut context = Context::from_waker(Waker::noop());
    loop {
        world.borrow_mut().deliver();
        let poll_scenario = std::mem::take(&mut world.borrow_mut().scenario_ready);
        let scenario_result = poll_scenario.then(|| scenario.as_mut().poll(&mut context));
        if let Some(Poll::Ready(healthy)) = scenario_result {
            return world.borrow().report(healthy);
        }
        assert!(world.borrow().now < 1500, "probe execution bound exceeded");
        world.borrow_mut().execute();
    }
}

fn main() {
    let images = images();
    let args: Vec<_> = std::env::args().collect();
    if args.get(1).is_some_and(|arg| arg == "--one") {
        let seed = args.get(2).unwrap().parse().unwrap();
        let guard = !args
            .get(3)
            .is_some_and(|arg| arg == "--disable-generation-guard");
        let report = run(&images, seed, guard);
        assert_eq!(report["healthy"], guard);
        println!("{}", String::from_utf8(canonical(&report)).unwrap());
        return;
    }
    let mut results = Vec::new();
    for seed in 0..16 {
        let first = run(&images, seed, true);
        assert_eq!(first["healthy"], true);
        assert_eq!(canonical(&first), canonical(&run(&images, seed, true)));
        let mut summary = first;
        summary.as_object_mut().unwrap().remove("trace");
        results.push(summary);
    }
    let negative = run(&images, 42, false);
    assert_eq!(negative["healthy"], false);
    assert_eq!(negative["health_byte"], b'V');
    let executable = std::env::current_exe().unwrap();
    let fresh = |timezone: &str| {
        let output = std::process::Command::new(&executable)
            .args(["--one", "42"])
            .env("TZ", timezone)
            .output()
            .unwrap();
        assert!(output.status.success());
        output.stdout
    };
    let first = fresh("UTC");
    assert_eq!(first, fresh("Pacific/Honolulu"));
    let fresh_report: Value = serde_json::from_slice(&first).unwrap();
    assert_eq!(fresh_report["healthy"], true);
    println!("{}", serde_json::to_string_pretty(&json!({"probe": "lifecycle-mechanism", "profile": "caller-bound delayed reads; synchronous writes to volatile byte; fsync copies to durable; crash restores durable", "single_thread_assertions": true, "runs": results, "fresh_process_check": {"seed": 42, "timezones": ["UTC", "Pacific/Honolulu"], "canonical_equal": true, "trace_sha256": fresh_report["trace_sha256"]}, "negative_control": {"generation_guard": false, "healthy": negative["healthy"], "health_byte": negative["health_byte"], "trace_sha256": negative["trace_sha256"]}})).unwrap());
}
