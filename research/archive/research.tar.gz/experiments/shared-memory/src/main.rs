//! Standalone evidence probe: no production Seedbox code, host threads, or host I/O models.
use std::{
    cell::UnsafeCell,
    error::Error,
    rc::Rc,
    thread::{self, ThreadId},
};
use unicorn_engine::{Arch, Mode, Prot, RegisterX86 as Reg, Unicorn};

const PAGE_SIZE: u64 = 4096;
const CODE: u64 = 0x1000;
const DATA_A: u64 = 0x20_0000;
const DATA_B: u64 = 0x50_0000;
const PRIVATE: u64 = 0x70_0000;
const EXEC_A: u64 = 0x40_0000;
const EXEC_B: u64 = 0x90_0000;
type Result<T> = std::result::Result<T, Box<dyn Error>>;

// Stable, suitably aligned, writable allocation. UnsafeCell permits native guest
// mutation without creating Rust references to the contents. Rc prevents Send/Sync.
#[repr(C, align(4096))]
struct Page {
    bytes: UnsafeCell<[u8; PAGE_SIZE as usize]>,
}
impl Page {
    fn new(initial: &[u8]) -> Rc<Self> {
        let mut bytes = [0; PAGE_SIZE as usize];
        bytes[..initial.len()].copy_from_slice(initial);
        Rc::new(Self {
            bytes: UnsafeCell::new(bytes),
        })
    }
}

struct Space {
    // Fields drop in declaration order: engine is closed before its backing refs.
    cpu: Unicorn<'static, ()>,
    backing: Vec<Rc<Page>>,
    caller: ThreadId,
}
impl Space {
    fn new() -> Result<Self> {
        let mut cpu = Unicorn::new(Arch::X86, Mode::MODE_64)?;
        cpu.mem_map(CODE, PAGE_SIZE, Prot::ALL)?;
        // Distinct locations avoid self-modifying this private instruction page.
        cpu.mem_write(CODE, &[0x48, 0x89, 0x07])?; // mov [rdi], rax
        cpu.mem_write(CODE + 0x10, &[0x48, 0x8b, 0x07])?; // mov rax, [rdi]
        cpu.mem_write(CODE + 0x20, &[0xf0, 0x48, 0xff, 0x07])?; // lock inc qword [rdi]
        cpu.mem_write(CODE + 0x30, &[0x88, 0x07])?; // mov byte [rdi], al
        cpu.mem_map(PRIVATE, PAGE_SIZE, Prot::READ | Prot::WRITE)?;
        Ok(Self {
            cpu,
            backing: vec![],
            caller: thread::current().id(),
        })
    }
    fn map(&mut self, address: u64, page: Rc<Page>, permissions: Prot) -> Result<()> {
        assert_eq!(self.caller, thread::current().id());
        // Safety: the pointer addresses 4096 writable bytes inside this stable Rc
        // allocation. Retain its Rc until after engine close, including unmaps.
        // Engines execute sequentially on this caller. No Rust contents references
        // coexist with guest execution; native aliases are intentional.
        unsafe {
            self.cpu
                .mem_map_ptr(address, PAGE_SIZE, permissions, page.bytes.get().cast())?;
        }
        self.backing.push(page);
        Ok(())
    }
    fn run(&mut self, start: u64) -> Result<()> {
        assert_eq!(self.caller, thread::current().id());
        // No changing exit address: execute exactly one instruction by count.
        self.cpu.emu_start(start, 0, 0, 1)?;
        Ok(())
    }
    fn write(&mut self, address: u64, value: u64) -> Result<()> {
        self.cpu.reg_write(Reg::RDI, address)?;
        self.cpu.reg_write(Reg::RAX, value)?;
        self.run(CODE)
    }
    fn read(&mut self, address: u64) -> Result<u64> {
        self.cpu.reg_write(Reg::RDI, address)?;
        self.run(CODE + 0x10)?;
        Ok(self.cpu.reg_read(Reg::RAX)?)
    }
    fn increment(&mut self, address: u64) -> Result<()> {
        self.cpu.reg_write(Reg::RDI, address)?;
        self.run(CODE + 0x20)
    }
    fn patch_byte(&mut self, address: u64, value: u8) -> Result<()> {
        self.cpu.reg_write(Reg::RDI, address)?;
        self.cpu.reg_write(Reg::RAX, u64::from(value))?;
        self.run(CODE + 0x30)
    }
    fn execute_shared(&mut self, address: u64) -> Result<u64> {
        self.run(address)?; // mov eax, imm32
        Ok(self.cpu.reg_read(Reg::RAX)?)
    }
}

fn main() -> Result<()> {
    println!(
        "calling_os_thread={:?}; guest_isa=x86_64; host_parallel_guest_execution=false",
        thread::current().id()
    );
    let page = Page::new(&[]);
    let mut a = Space::new()?;
    let mut b = Space::new()?;
    println!("default_x86_cpu_model_id={}", a.cpu.ctl_get_cpu_model()?);
    a.map(DATA_A, page.clone(), Prot::READ | Prot::WRITE)?;
    b.map(DATA_B, page.clone(), Prot::READ | Prot::WRITE)?;
    a.write(DATA_A, 0x1234)?;
    assert_eq!(b.read(DATA_B)?, 0x1234);
    b.write(DATA_B, 0x5678)?;
    assert_eq!(a.read(DATA_A)?, 0x5678);
    println!(
        "PASS different_va_guest_store_load: A=0x{DATA_A:x}, B=0x{DATA_B:x}; bidirectional visibility"
    );

    a.write(DATA_A, 0)?;
    for _ in 0..1000 {
        a.increment(DATA_A)?;
        b.increment(DATA_B)?;
    }
    assert_eq!(a.read(DATA_A)?, 2000);
    assert_eq!(b.read(DATA_B)?, 2000);
    println!("PASS interleaved_lock_inc: 1000 guest RMWs per engine; shared counter=2000");

    a.write(PRIVATE, 11)?;
    assert_eq!(b.read(PRIVATE)?, 0);
    b.write(PRIVATE, 22)?;
    assert_eq!(a.read(PRIVATE)?, 11);
    println!("PASS private_pages: same VA, A=11, B=22");

    // A deliberately broken representation: identical logical mapping labels,
    // but separate backing pages. The same guest-level alias oracle rejects it.
    let mut independent_a = Space::new()?;
    let mut independent_b = Space::new()?;
    independent_a.map(DATA_A, Page::new(&[]), Prot::READ | Prot::WRITE)?;
    independent_b.map(DATA_B, Page::new(&[]), Prot::READ | Prot::WRITE)?;
    independent_a.write(DATA_A, 17)?;
    let negative_observed = independent_b.read(DATA_B)?;
    assert_ne!(negative_observed, 17);
    println!(
        "PASS negative_control_rejected: independent backing observed={negative_observed}, alias oracle requires=17"
    );

    let executable = Page::new(&[0xb8, 1, 0, 0, 0]); // mov eax, 1
    a.map(EXEC_A, executable.clone(), Prot::ALL)?;
    b.map(EXEC_B, executable, Prot::ALL)?;
    assert_eq!(a.execute_shared(EXEC_A)?, 1);
    assert_eq!(a.execute_shared(EXEC_A)?, 1);
    a.cpu.ctl_request_cache(EXEC_A, None)?;
    println!(
        "PASS executable_cache_warm: repeated execution=1; translation cache explicitly requested before mutation"
    );
    b.patch_byte(EXEC_B + 1, 2)?;
    assert_eq!(a.cpu.mem_read_as_vec(EXEC_A, 5)?, [0xb8, 2, 0, 0, 0]);
    let without_invalidation = a.execute_shared(EXEC_A)?;
    println!(
        "OBSERVE shared_executable_without_cross_engine_invalidation: backing_imm=2, executed_rax={without_invalidation}; automatic_coherence={}",
        without_invalidation == 2
    );
    assert!([1, 2].contains(&without_invalidation));
    if without_invalidation == 1 {
        println!(
            "FAIL automatic_shared_executable_coherence: new backing bytes execute as stale translated code"
        );
    } else {
        println!("PASS automatic_shared_executable_coherence_in_this_probe");
    }
    a.cpu.ctl_remove_cache(EXEC_A, EXEC_A + PAGE_SIZE)?;
    assert_eq!(a.execute_shared(EXEC_A)?, 2);
    println!("PASS explicit_target_alias_translation_invalidation: executed_rax=2");

    a.cpu.mem_unmap(DATA_A, PAGE_SIZE)?;
    b.increment(DATA_B)?;
    assert_eq!(b.read(DATA_B)?, 2001);
    println!("PASS unmap_one_engine: surviving counter=2001");
    drop(a);
    drop(page); // B's retained Rc alone keeps the data allocation alive.
    b.increment(DATA_B)?;
    assert_eq!(b.read(DATA_B)?, 2002);
    assert_eq!(b.execute_shared(EXEC_B)?, 2);
    println!("PASS destroy_one_engine: surviving counter=2002; shared executable still executes=2");
    println!("PROBE_COMPLETED required_data_lifetime_and_explicit_code_invalidation_checks=PASS");
    Ok(())
}
