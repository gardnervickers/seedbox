//! Independent cost-policy experiment. No guest CPU or Linux is modeled here.
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    rc::Rc,
    thread::{self, ThreadId},
};

type ProbeResult<T> = Result<T, String>;

#[derive(Clone, Copy, Debug)]
enum Policy {
    BoundaryTicks,
    DeclaredWork,
    ZeroCost,
    ChargeCompletion,
    DispatchCompletion,
}
impl Policy {
    fn name(self) -> &'static str {
        match self {
            Self::BoundaryTicks => "four_ns_per_boundary",
            Self::DeclaredWork => "four_ns_per_declared_work_unit",
            Self::ZeroCost => "negative_zero_cost",
            Self::ChargeCompletion => "negative_charge_completion",
            Self::DispatchCompletion => "negative_dispatch_completion",
        }
    }
}

#[derive(Clone, Copy, Debug)]
enum Phase {
    Compute(u64),
    ClockPoll,
    CompletionOnly,
}

struct World {
    // Rc makes this world !Send/!Sync. Actual thread identity is diagnostic only.
    _owner: Rc<()>,
    owner: ThreadId,
    now: u64,
    sequence: u64,
    seed: u64,
    schedule_draws: u64,
    progress: [u64; 2],
    events: BTreeMap<(u64, u64), &'static str>,
    trace: Vec<Value>,
    delivered: Vec<(&'static str, u64, u64)>,
}
impl World {
    fn new(seed: u64) -> Self {
        Self {
            _owner: Rc::new(()),
            owner: thread::current().id(),
            now: 0,
            sequence: 0,
            seed,
            schedule_draws: 0,
            progress: [0, 0],
            events: BTreeMap::new(),
            trace: Vec::new(),
            delivered: Vec::new(),
        }
    }
    fn emit(&mut self, kind: &str, detail: Value) {
        assert_eq!(self.owner, thread::current().id());
        self.trace
            .push(json!({"time_ns":self.now,"event":kind,"detail":detail}));
    }
    fn schedule(&mut self, deadline: u64, name: &'static str) {
        assert!(deadline >= self.now);
        self.sequence += 1;
        self.events.insert((deadline, self.sequence), name);
        self.emit(
            "register",
            json!({"deadline_ns":deadline,"sequence":self.sequence,"name":name}),
        );
    }
    fn drain_due(&mut self) {
        while self
            .events
            .first_key_value()
            .is_some_and(|((due, _), _)| *due <= self.now)
        {
            let ((deadline, sequence), name) = self.events.pop_first().unwrap();
            self.delivered.push((name, deadline, self.now));
            self.emit(
                "deliver",
                json!({"deadline_ns":deadline,"sequence":sequence,
                "name":name,"lateness_ns":self.now-deadline}),
            );
        }
    }
    fn choose(&mut self, count: u64) -> u64 {
        assert!(count > 0);
        let mut hash = Sha256::new();
        hash.update(b"cooperative-time:schedule:v1");
        hash.update(self.seed.to_le_bytes());
        hash.update(self.schedule_draws.to_le_bytes());
        self.schedule_draws += 1;
        u64::from_le_bytes(hash.finalize()[..8].try_into().unwrap()) % count
    }
    fn phase(&mut self, phase: Phase, policy: Policy) {
        let (name, units) = match phase {
            Phase::Compute(units) => ("compute", units),
            Phase::ClockPoll => ("clock_poll", 1),
            Phase::CompletionOnly => ("completion_only", 0),
        };
        let completion = matches!(phase, Phase::CompletionOnly);
        let participant = (!completion).then(|| self.choose(2));
        if let Some(participant) = participant {
            self.progress[participant as usize] += units;
        }
        let cost = match (phase, policy) {
            (_, Policy::ZeroCost) => 0,
            (Phase::CompletionOnly, Policy::ChargeCompletion) => 4,
            (Phase::CompletionOnly, _) => 0,
            (Phase::Compute(units), Policy::DeclaredWork) => units.checked_mul(4).unwrap(),
            (_, _) => 4,
        };
        let started = self.now;
        self.now = self.now.checked_add(cost).unwrap();
        self.emit(
            "boundary",
            json!({"phase":name,"declared_units":units,
            "started_ns":started,"cost_ns":cost,"participant":participant,
            "schedule_draws":self.schedule_draws,"machine_progress":self.progress}),
        );
        // No fault executes inside this atomic cooperative phase. Deadlines
        // retain their due time; actual delivery records the reached boundary.
        if !completion || matches!(policy, Policy::DispatchCompletion) {
            self.drain_due();
        }
    }
    fn idle(&mut self) -> bool {
        let Some((&(deadline, _), _)) = self.events.first_key_value() else {
            self.emit("quiescent", json!({"next_event_ns":null}));
            return false;
        };
        let before = self.now;
        self.now = self.now.max(deadline);
        self.emit("idle_jump", json!({"from_ns":before,"to_ns":self.now}));
        self.drain_due();
        true
    }
    fn report(self, name: &str, policy: Policy) -> Value {
        json!({"case":name,"policy":policy.name(),"now_ns":self.now,
            "schedule_draws":self.schedule_draws,"machine_progress":self.progress,"trace":self.trace})
    }
}

fn polling(seed: u64, policy: Policy) -> ProbeResult<Value> {
    let mut w = World::new(seed);
    w.schedule(60, "scenario_fault");
    for _ in 0..80 {
        w.phase(Phase::ClockPoll, policy);
    }
    if !w
        .delivered
        .iter()
        .any(|(name, _, _)| *name == "scenario_fault")
    {
        return Err(format!(
            "timer_starvation now_ns={} runnable_boundaries=80 pending={}",
            w.now,
            w.events.len()
        ));
    }
    Ok(w.report("runnable_clock_polling", policy))
}
fn completion(seed: u64, policy: Policy) -> ProbeResult<Value> {
    let mut w = World::new(seed);
    w.schedule(0, "already_due_before_guest_progress");
    w.schedule(4, "fault_after_guest_progress");
    w.phase(Phase::CompletionOnly, policy);
    if w.now != 0 || w.schedule_draws != 0 || !w.delivered.is_empty() || w.progress != [0, 0] {
        return Err(format!(
            "completion_only_changed_world now_ns={} draws={} delivered={}",
            w.now,
            w.schedule_draws,
            w.delivered.len()
        ));
    }
    w.phase(Phase::ClockPoll, policy);
    if w.delivered
        != vec![
            ("already_due_before_guest_progress", 0, 4),
            ("fault_after_guest_progress", 4, 4),
        ]
    {
        return Err("completion_followed_by_progress_missing_fault".into());
    }
    Ok(w.report("completion_then_guest", policy))
}
fn long_phase(seed: u64, policy: Policy) -> Value {
    let mut w = World::new(seed);
    w.schedule(60, "partition");
    w.phase(Phase::Compute(32), policy);
    w.emit(
        "application_observation",
        json!({"partition_active":!w.delivered.is_empty()}),
    );
    while w.idle() {}
    w.report("long_finite_phase", policy)
}
fn idle(seed: u64) -> Value {
    let mut w = World::new(seed);
    // Input order intentionally differs from deadline order.
    w.schedule(9, "guest_timer");
    w.schedule(4, "packet");
    w.schedule(6, "scenario_wake");
    w.schedule(4, "equal_time_timer");
    while w.idle() {}
    assert_eq!(
        w.delivered,
        vec![
            ("packet", 4, 4),
            ("equal_time_timer", 4, 4),
            ("scenario_wake", 6, 6),
            ("guest_timer", 9, 9)
        ]
    );
    assert_eq!(w.schedule_draws, 0);
    w.report("all_guests_blocked", Policy::BoundaryTicks)
}
fn suite(seed: u64) -> Value {
    let zero_witness = polling(seed, Policy::ZeroCost).expect_err("zero-cost control must starve");
    let completion_witness =
        completion(seed, Policy::ChargeCompletion).expect_err("completion control must fail");
    let dispatch_witness =
        completion(seed, Policy::DispatchCompletion).expect_err("completion dispatch must fail");
    let cases = vec![
        polling(seed, Policy::BoundaryTicks).unwrap(),
        polling(seed, Policy::DeclaredWork).unwrap(),
        completion(seed, Policy::BoundaryTicks).unwrap(),
        long_phase(seed, Policy::BoundaryTicks),
        long_phase(seed, Policy::DeclaredWork),
        idle(seed),
    ];
    json!({"schema":1,"seed":seed,"scope":"synthetic cooperative time policy; no CPU/Linux/device fidelity",
        "input":{"source_sha256":format!("{:x}",Sha256::digest(include_bytes!("main.rs"))),
            "time_unit":"nanosecond","boundary_cost_ns":4,"deadline_order":"time_then_registration_sequence"},
        "cases":cases,"negative_controls":{"zero_cost":zero_witness,"completion_cost":completion_witness,"completion_dispatch":dispatch_witness}})
}
fn main() {
    let seed = std::env::args()
        .nth(1)
        .map(|s| s.parse().expect("decimal u64 seed"))
        .unwrap_or(42);
    println!("{}", serde_json::to_string(&suite(seed)).unwrap());
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn zero_cost_polling_does_not_acquire_time_from_pending_events() {
        assert!(
            polling(42, Policy::ZeroCost)
                .unwrap_err()
                .starts_with("timer_starvation now_ns=0")
        );
        let r = polling(42, Policy::BoundaryTicks).unwrap();
        assert!(
            r["trace"]
                .as_array()
                .unwrap()
                .iter()
                .any(|e| e["event"] == "deliver" && e["time_ns"] == 60)
        );
    }
    #[test]
    fn completion_round_has_no_time_rng_or_scenario_progress() {
        completion(42, Policy::BoundaryTicks).unwrap();
        assert!(
            completion(42, Policy::ChargeCompletion)
                .unwrap_err()
                .contains("now_ns=4")
        );
    }
    #[test]
    fn completion_must_not_dispatch_even_an_already_due_event() {
        assert!(
            completion(42, Policy::DispatchCompletion)
                .unwrap_err()
                .contains("delivered=1")
        );
        completion(42, Policy::BoundaryTicks).unwrap();
    }
    #[test]
    fn finite_phase_crossing_deadline_reports_late_boundary_delivery() {
        let r = long_phase(42, Policy::DeclaredWork);
        let event = r["trace"]
            .as_array()
            .unwrap()
            .iter()
            .find(|e| e["event"] == "deliver")
            .unwrap();
        assert_eq!(event["time_ns"], 128);
        assert_eq!(event["detail"]["deadline_ns"], 60);
        assert_eq!(event["detail"]["lateness_ns"], 68);
    }
    #[test]
    fn cost_policy_changes_observation_of_same_finite_work() {
        let a = long_phase(42, Policy::BoundaryTicks);
        let b = long_phase(42, Policy::DeclaredWork);
        let observed = |r: Value| {
            r["trace"]
                .as_array()
                .unwrap()
                .iter()
                .find(|e| e["event"] == "application_observation")
                .unwrap()["detail"]["partition_active"]
                .clone()
        };
        assert_eq!(observed(a), false);
        assert_eq!(observed(b), true);
    }
    #[test]
    fn idle_jump_and_equal_time_events_have_explicit_stable_order() {
        idle(42);
    }
    #[test]
    fn no_timer_is_quiescence_not_a_jump_to_u64_max() {
        let mut w = World::new(42);
        assert!(!w.idle());
        assert_eq!(w.now, 0);
    }
    #[test]
    fn seed_repeats_and_changes_schedule_without_changing_inputs() {
        assert_eq!(suite(42), suite(42));
        let a = polling(42, Policy::BoundaryTicks).unwrap();
        let b = polling(43, Policy::BoundaryTicks).unwrap();
        assert_eq!(
            a["machine_progress"][0].as_u64().unwrap() + a["machine_progress"][1].as_u64().unwrap(),
            80
        );
        assert_ne!(a["machine_progress"], b["machine_progress"]);
        assert_ne!(a["trace"], b["trace"]);
    }
}
