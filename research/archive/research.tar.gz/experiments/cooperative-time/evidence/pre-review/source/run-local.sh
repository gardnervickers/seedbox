#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
# Invoke through nix develop .#qemu-probe --command bash ... .
# Each measured world is a fresh single-threaded process. The optional CPU
# load is a separate process outside the world, never a simulation participant.
load_pid=""
trap 'if [[ -n "$load_pid" ]]; then kill "$load_pid" 2>/dev/null || true; wait "$load_pid" 2>/dev/null || true; fi' EXIT
for probe in cooperative-time device-faults; do
    export CARGO_TARGET_DIR="$PWD/target/$probe-probe"
    cargo build --manifest-path "experiments/$probe/Cargo.toml" --locked --offline --release
    executable="$CARGO_TARGET_DIR/release/seedbox-$probe-probe"
    evidence="experiments/$probe/evidence"
    if [[ -e "$evidence/run-1.json" ]]; then
        echo "Existing evidence at $evidence; choose a fresh MODEL_EVIDENCE_SUFFIX for a new run." >&2
        [[ -n "${MODEL_EVIDENCE_SUFFIX:-}" ]]
        evidence="$evidence/${MODEL_EVIDENCE_SUFFIX}"
        [[ ! -e "$evidence/run-1.json" ]]
    fi
    mkdir -p "$evidence/source/src"
    cp "experiments/$probe/Cargo.toml" "experiments/$probe/Cargo.lock" "$evidence/source/"
    cp "experiments/$probe/src/main.rs" "$evidence/source/src/main.rs"
    cp experiments/model-probes/run-local.sh "$evidence/source/run-local.sh"
    {
        uname -a
        rustc --version
        cargo --version
        printf 'nixpkgs: 8c6b39505383e6d5dcb431f00cb3597b71f8045c\n'
        printf 'command: nix develop .#qemu-probe --command bash experiments/model-probes/run-local.sh\n'
        printf 'runs 1-4: TZ=UTC, LC_ALL=C, seed=42\nrun 5: TZ=Pacific/Honolulu, LC_ALL=C, seed=42, outside yes CPU load\nseed sensitivity: TZ=UTC, LC_ALL=C, seed=43\n'
    } > "$evidence/host.txt"
    sha256sum "$executable" "experiments/$probe/Cargo.toml" "experiments/$probe/Cargo.lock" "experiments/$probe/src/main.rs" experiments/model-probes/run-local.sh flake.lock > "$evidence/inputs-sha256.txt"
    for run in 1 2 3 4; do
        TZ=UTC LC_ALL=C "$executable" 42 > "$evidence/run-$run.json"
    done
    yes > /dev/null &
    load_pid=$!
    TZ=Pacific/Honolulu LC_ALL=C "$executable" 42 > "$evidence/run-5.json"
    kill "$load_pid"
    wait "$load_pid" 2>/dev/null || true
    load_pid=""
    TZ=UTC LC_ALL=C "$executable" 43 > "$evidence/seed-43.json"
    for run in 2 3 4 5; do cmp "$evidence/run-1.json" "$evidence/run-$run.json"; done
    if [[ "$probe" == cooperative-time ]]; then
        jq -e '.cases[0].machine_progress' "$evidence/run-1.json" > "$evidence/seed-42-observation.json"
        jq -e '.cases[0].machine_progress' "$evidence/seed-43.json" > "$evidence/seed-43-observation.json"
    else
        jq -e '.cases[0].machines[0].received' "$evidence/run-1.json" > "$evidence/seed-42-observation.json"
        jq -e '.cases[0].machines[0].received' "$evidence/seed-43.json" > "$evidence/seed-43-observation.json"
    fi
    if cmp -s "$evidence/seed-42-observation.json" "$evidence/seed-43-observation.json"; then
        echo "seed sensitivity did not change actual model observation" >&2
        exit 1
    fi
    sha256sum "$evidence"/*.json > "$evidence/results-sha256.txt"
    jq -n --arg probe "$probe" --arg digest "$(sha256sum "$evidence/run-1.json" | cut -d ' ' -f 1)" \
        '{probe:$probe,repeat_processes:5,byte_identical:true,changed_seed_changes_model_observation:true,canonical_sha256:$digest}' > "$evidence/summary.json"
    cat "$evidence/summary.json"
done
