bits 64
global _start
section .text
_start:
    mov eax, 56
    syscall
    test eax, eax
    jz child
    lea r12, [rel output1]
    movdqu xmm0, [rel lanes1]
    movdqu xmm15, [rel lanes15_1]
    fld qword [rel one]
    fld qword [rel initial1]
    fldcw [rel cw1]
    ldmxcsr [rel mx1]
    jmp ready
child:
    lea r12, [rel output2]
    movdqu xmm0, [rel lanes2]
    movdqu xmm15, [rel lanes15_2]
    fld qword [rel one]
    fld qword [rel initial2]
    fldcw [rel cw2]
    ldmxcsr [rel mx2]
ready:
    mov eax, 1000
    syscall
    mov ecx, 4096
loop_body:
    paddq xmm0, [rel increments]
    psubq xmm15, [rel increments]
    fadd qword [rel one]
    dec ecx
    jnz loop_body
    movdqu [r12], xmm0
    fstp qword [r12+16]
    fstp qword [r12+32]
    movdqu [r12+40], xmm15
    fstcw [r12+24]
    stmxcsr [r12+28]
    mov eax, 1
    mov edi, 1
    mov rsi, r12
    mov edx, 64
    syscall
    mov eax, 60
    xor edi, edi
    syscall
section .data
lanes1: dq 10,20
lanes2: dq 30,40
lanes15_1: dq 100,200
lanes15_2: dq 300,400
increments: dq 1,2
initial1: dq 1.0
initial2: dq 2.0
one: dq 1.0
cw1: dw 0x077f
cw2: dw 0x0b7f
mx1: dd 0x3f80
mx2: dd 0x5f80
section .bss
output1: resb 64
output2: resb 64
