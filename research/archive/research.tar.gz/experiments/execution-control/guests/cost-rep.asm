bits 64
global _start
section .text
_start:
    mov rax,0x123456789abcdef0
loop_body:
    lea rdi,[rel buffer]
    mov ecx,8192
    rep stosq
    jmp loop_body
section .bss
buffer: resb 65536
