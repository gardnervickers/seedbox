bits 64
global _start
section .text
_start:
    mov rdi, 0x40000ff8
    lea rsi, [rel source]
    mov ecx, 16
    rep movsb
    mov eax, 60
    xor edi, edi
    syscall
section .data
source: db 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
