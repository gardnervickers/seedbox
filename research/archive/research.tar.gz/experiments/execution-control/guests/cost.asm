bits 64
global _start
section .text
_start:
    mov rbx, 0x123456789abcdef0
    pxor xmm0,xmm0
loop_body:
    add rax,rbx
    rol rax,7
    xor rdx,rax
    paddq xmm0,xmm0
    jmp loop_body
