bits 64
global _start
section .text
_start:
    cld
    lea rsi, [rel source]
    lea rdi, [rel forward]
    mov ecx, 65536
    rep movsb
    lea rsi, [rel source+65535]
    lea rdi, [rel backward+65535]
    mov ecx, 65536
    std
    rep movsb
    cld
    lea rdi, [rel filled]
    mov rax, 0x8877665544332211
    mov ecx, 8192
    rep stosq
    lea rsi, [rel source]
    lea rdi, [rel forward]
    mov ecx, 65536
    repe cmpsb
    test ecx, ecx
    jnz fail
    mov eax, 1
    mov edi, 1
    lea rsi, [rel forward]
    mov edx, 196608
    syscall
    mov eax, 60
    xor edi, edi
    syscall
fail:
    mov eax, 60
    mov edi, 1
    syscall
section .data
source: times 16384 db 0x01,0x7f,0xa5,0xff
section .bss
forward: resb 65536
backward: resb 65536
filled: resb 65536
