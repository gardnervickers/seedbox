use seedbox::{
    backend::{Process, STACK_BASE, STACK_SIZE, State, StopReason},
    fixtures,
    random::RandomStream,
    runtime::{canonical, digest},
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::PathBuf,
    process::Command,
    time::Instant,
};
use unicorn_engine::RegisterX86 as Reg;

fn root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}
fn image(name: &str) -> Vec<u8> {
    fs::read(root().join("build").join(name)).unwrap()
}
fn process(name: &str) -> Process {
    Process::new(
        name,
        &image(name),
        &mut RandomStream::new(42, "execution-control"),
        &["/app".into()],
        1,
    )
    .unwrap()
}
fn assemble() {
    let build = root().join("build");
    fs::create_dir_all(&build).unwrap();
    for name in ["contexts", "rep", "rep-fault", "cost", "cost-rep"] {
        fixtures::assemble(
            &root().join("guests").join(format!("{name}.asm")),
            &build.join(name),
            false,
        )
        .unwrap();
    }
    for (name, instruction) in [
        ("rdtsc", "rdtsc"),
        ("rdtscp", "rdtscp"),
        ("rdrand", "rdrand rax"),
        ("rdseed", "rdseed rax"),
        ("rdpmc", "rdpmc"),
        ("cpuid", "cpuid"),
        ("rdpid", "rdpid rax"),
        ("xgetbv", "xgetbv"),
        ("rdfsbase", "rdfsbase rax"),
        ("umwait", "umwait eax"),
        ("unmapped", "mov rax,[0x40000000]"),
        ("protected", "mov byte [0x40000000],0x99"),
        ("undefined", "ud2"),
    ] {
        let source = build.join(format!("{name}.asm"));
        fs::write(&source,format!("bits 64\nglobal _start\nsection .text\n_start:\nmov rax,0x11223344\n{instruction}\nmov rbx,0x55667788\nmov eax,60\nxor edi,edi\nsyscall\n")).unwrap();
        fixtures::assemble(&source, &build.join(name), false).unwrap();
    }
}
fn checked_run(
    p: &mut Process,
    tid: u64,
    quantum: u64,
    hash: &mut Sha256,
) -> seedbox::backend::ExecutionStop {
    let stop = p.run(tid, quantum).unwrap();
    assert!(stop.steps <= quantum, "instruction bound exceeded");
    assert_eq!(stop.steps, stop.entered.len() as u64);
    assert!(stop.steps > 0 || matches!(stop.reason, StopReason::Fault | StopReason::Unsupported));
    hash.update(tid.to_le_bytes());
    hash.update(quantum.to_le_bytes());
    hash.update(stop.steps.to_le_bytes());
    hash.update(stop.reason.as_str().as_bytes());
    for i in &stop.entered {
        hash.update(i.pc.to_le_bytes());
        hash.update((i.bytes.len() as u64).to_le_bytes());
        hash.update(&i.bytes);
    }
    for reg in [
        Reg::RIP,
        Reg::RAX,
        Reg::RCX,
        Reg::RSI,
        Reg::RDI,
        Reg::EFLAGS,
    ] {
        hash.update(p.register(reg).unwrap().to_le_bytes());
    }
    stop
}
fn functional(name: &str, q: u64, negative: bool) -> Value {
    let mut p = process(name);
    let mut hash = Sha256::new();
    let mut ready = BTreeSet::new();
    let mut outputs = BTreeMap::<u64, Vec<u8>>::new();
    let mut cursor = 0;
    let mut steps = 0;
    let mut injected = false;
    loop {
        if name == "contexts" && ready.len() == 2 && !injected {
            if negative {
                p.threads
                    .get_mut(&2)
                    .unwrap()
                    .context
                    .reg_write(Reg::MXCSR, 0x1f80)
                    .unwrap();
            }
            for t in p.threads.values_mut() {
                if t.state == State::Blocked {
                    t.state = State::Runnable;
                }
            }
            injected = true;
        }
        let tids: Vec<_> = p
            .threads
            .values()
            .filter(|t| t.state == State::Runnable)
            .map(|t| t.tid)
            .collect();
        if tids.is_empty() {
            break;
        }
        let tid = tids[cursor % tids.len()];
        cursor += 1;
        let stop = checked_run(&mut p, tid, q, &mut hash);
        steps += stop.steps;
        assert!(steps < 2_000_000);
        match stop.reason {
            StopReason::Quantum => {}
            StopReason::Syscall => {
                let req = stop.request.unwrap();
                match req.number {
                    56 => {
                        p.complete(tid, &req, 2).unwrap();
                        p.clone_thread(tid, 2, STACK_BASE + STACK_SIZE / 2, None)
                            .unwrap();
                    }
                    1000 => {
                        p.complete(tid, &req, 0).unwrap();
                        p.threads.get_mut(&tid).unwrap().state = State::Blocked;
                        ready.insert(tid);
                    }
                    1 => {
                        outputs.insert(tid, p.read(req.args[1], req.args[2]).unwrap());
                        p.complete(tid, &req, req.args[2] as i64).unwrap();
                    }
                    60 => {
                        assert_eq!(req.args[0], 0, "guest oracle failed");
                        p.threads.get_mut(&tid).unwrap().state = State::Exited;
                    }
                    n => panic!("unexpected syscall {n}"),
                }
            }
            _ => panic!("{name}: {} {:?}", stop.reason.as_str(), stop.detail),
        }
    }
    let valid = if name == "contexts" {
        outputs.len() == 2
            && outputs.iter().all(|(tid, b)| {
                let (lanes, initial, cw, mx) = if *tid == 1 {
                    ([10u64, 20], 1f64, 0x077fu16, 0x3f80u32)
                } else {
                    ([30u64, 40], 2f64, 0x0b7fu16, 0x5f80u32)
                };
                let lanes15 = if *tid == 1 {
                    [100u64, 200]
                } else {
                    [300u64, 400]
                };
                b.len() == 64
                    && u64::from_le_bytes(b[..8].try_into().unwrap()) == lanes[0] + 4096
                    && u64::from_le_bytes(b[8..16].try_into().unwrap()) == lanes[1] + 8192
                    && f64::from_le_bytes(b[16..24].try_into().unwrap()) == initial + 4096.0
                    && u16::from_le_bytes(b[24..26].try_into().unwrap()) == cw
                    && u32::from_le_bytes(b[28..32].try_into().unwrap()) == mx
                    && f64::from_le_bytes(b[32..40].try_into().unwrap()) == 1.0
                    && u64::from_le_bytes(b[40..48].try_into().unwrap())
                        == lanes15[0].wrapping_sub(4096)
                    && u64::from_le_bytes(b[48..56].try_into().unwrap())
                        == lanes15[1].wrapping_sub(8192)
            })
    } else {
        let pattern = [1, 0x7f, 0xa5, 0xff].repeat(16384);
        let fill = 0x8877665544332211u64.to_le_bytes().repeat(8192);
        outputs.get(&1) == Some(&[pattern.clone(), pattern, fill].concat())
    };
    if !negative {
        assert!(
            valid,
            "{name} final architectural oracle failed: {outputs:?}"
        );
    }
    json!({"image_sha256":digest(&image(name)),"steps":steps,"trace_sha256":hex::encode(hash.finalize()),
        "valid":valid,"output":outputs.iter().map(|(tid,b)|json!({"tid":tid,"bytes":b.len(),"sha256":digest(b),
            "hex_if_small":if b.len()<100 {Some(hex::encode(b))} else {None}})).collect::<Vec<_>>()})
}
fn fault_resume(q: u64) -> Value {
    let mut p = process("rep-fault");
    assert_eq!(p.mmap(0x40000000, 4096, 3, 0x32).unwrap(), 0x40000000);
    let mut h = Sha256::new();
    let mut steps = 0;
    let detail = loop {
        let s = checked_run(&mut p, 1, q, &mut h);
        steps += s.steps;
        if s.reason == StopReason::Fault {
            break s.detail;
        }
        assert_eq!(s.reason, StopReason::Quantum);
    };
    assert_eq!(p.register(Reg::RCX).unwrap(), 8);
    assert_eq!(p.register(Reg::RDI).unwrap(), 0x40001000);
    assert_eq!(p.read(0x40000ff8, 8).unwrap(), (0u8..8).collect::<Vec<_>>());
    assert_eq!(p.mmap(0x40001000, 4096, 3, 0x32).unwrap(), 0x40001000);
    loop {
        let s = checked_run(&mut p, 1, q, &mut h);
        steps += s.steps;
        if s.reason == StopReason::Syscall {
            assert_eq!(s.request.unwrap().number, 60);
            break;
        }
        assert_eq!(s.reason, StopReason::Quantum);
    }
    let bytes = p.read(0x40000ff8, 16).unwrap();
    assert_eq!(bytes, (0u8..16).collect::<Vec<_>>());
    json!({"detail":detail,"steps":steps,"bytes_hex":hex::encode(bytes),"trace_sha256":hex::encode(h.finalize())})
}
fn boundary(name: &str, q: u64) -> Value {
    let mut p = process(name);
    if name == "protected" {
        p.mmap(0x40000000, 4096, 3, 0x32).unwrap();
        p.mprotect(0x40000000, 4096, 1).unwrap();
    }
    let mut h = Sha256::new();
    let mut steps = 0;
    loop {
        let s = checked_run(&mut p, 1, q, &mut h);
        steps += s.steps;
        if s.reason != StopReason::Quantum {
            assert!(matches!(
                s.reason,
                StopReason::Unsupported | StopReason::Fault
            ));
            assert_eq!(
                p.register(Reg::RBX).unwrap(),
                0,
                "instruction following rejected/faulting instruction ran"
            );
            if !["unmapped", "protected", "undefined"].contains(&name) {
                assert_eq!(
                    p.register(Reg::RAX).unwrap(),
                    0x11223344,
                    "{name} changed RAX before rejection: {:?}",
                    s.detail
                );
            } else {
                assert_eq!(s.reason, StopReason::Fault);
            }
            return json!({"reason":s.reason.as_str(),"detail":s.detail,"steps":steps,"trace_sha256":hex::encode(h.finalize())});
        }
    }
}
fn observation(q: u64) -> Value {
    let names = [
        "rdtsc",
        "rdtscp",
        "rdrand",
        "rdseed",
        "rdpmc",
        "cpuid",
        "rdpid",
        "xgetbv",
        "rdfsbase",
        "umwait",
        "unmapped",
        "protected",
        "undefined",
    ];
    json!({"seed":42,"quantum":q,"contexts":functional("contexts",q,false),"rep":functional("rep",q,false),
        "fault_resume":fault_resume(q),"boundaries":names.iter().map(|n|((*n).into(),boundary(n,q))).collect::<BTreeMap<String,Value>>()})
}
fn cost(name: &str, q: u64, hashing: bool) -> Value {
    let mut p = process(name);
    let mut hash = Sha256::new();
    let start = Instant::now();
    let mut steps = 0;
    let mut calls = 0;
    while steps < 200_000 {
        let budget = q.min(200_000 - steps);
        let s = p.run(1, budget).unwrap();
        assert_eq!(s.reason, StopReason::Quantum);
        assert_eq!(s.steps, budget);
        assert_eq!(s.entered.len() as u64, budget);
        if hashing {
            for i in &s.entered {
                hash.update(i.pc.to_le_bytes());
                hash.update((i.bytes.len() as u32).to_le_bytes());
                hash.update(&i.bytes);
            }
        }
        steps += s.steps;
        calls += 1;
    }
    let elapsed = start.elapsed().as_secs_f64();
    json!({"workload":name,"quantum":q,"hashing":hashing,"steps":steps,"calls":calls,"seconds":elapsed,"steps_per_second":steps as f64/elapsed,"sha256":if hashing {Some(hex::encode(hash.finalize()))}else{None}})
}
fn command(c: &str, args: &[&str]) -> String {
    let o = Command::new(c).args(args).output().unwrap();
    assert!(o.status.success());
    String::from_utf8(o.stdout).unwrap().trim().into()
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    if args.get(1).is_some_and(|a| a == "--observe") {
        let q = args[2].parse().unwrap();
        println!("{}", String::from_utf8(canonical(&observation(q))).unwrap());
        return;
    }
    if args.get(1).is_some_and(|a| a == "--assemble") {
        assemble();
        return;
    }
    assemble();
    let mut observations = vec![];
    for q in [1, 7, 64, 4096] {
        let run = || {
            let o = Command::new(std::env::current_exe().unwrap())
                .args(["--observe", &q.to_string()])
                .output()
                .unwrap();
            assert!(
                o.status.success(),
                "fresh child failed: {}",
                String::from_utf8_lossy(&o.stderr)
            );
            o.stdout
        };
        let a = run();
        let b = run();
        assert_eq!(a, b, "fresh-process canonical observations differ");
        observations.push(serde_json::from_slice::<Value>(&a).unwrap());
    }
    // Changed quantum schedules may alter trace/step accounting at faulting REP entries.
    // Final bytes and complete SIMD/FPU output must still agree.
    for o in &observations[1..] {
        for k in ["contexts", "rep"] {
            assert_eq!(o[k]["output"], observations[0][k]["output"]);
        }
        assert_eq!(
            o["fault_resume"]["bytes_hex"],
            observations[0]["fault_resume"]["bytes_hex"]
        );
    }
    let negative = functional("contexts", 7, true);
    assert_eq!(
        negative["valid"], false,
        "negative context corruption went undetected"
    );
    let mut costs = vec![];
    for name in ["cost", "cost-rep"] {
        for q in [1, 8, 64, 1024] {
            for hashing in [false, true] {
                for _ in 0..2 {
                    costs.push(cost(name, q, hashing));
                }
            }
        }
    }
    let report = json!({"host":command("uname",&["-a"]),"cpu":command("sysctl",&["-n","machdep.cpu.brand_string"]),"rustc":command("rustc",&["--version"]),"unicorn":command("pkg-config",&["--modversion","unicorn"]),
        "nasm":command("nasm",&["-v"]),"probe_source_sha256":digest(include_bytes!("main.rs")),"seedbox_backend_sha256":digest(&fs::read(root().join("../../src/backend.rs")).unwrap()),
        "fresh_process_pairs":4,"observations":observations,"negative_detected":negative,"costs":costs});
    let output = root().join("results.json");
    fs::write(&output, serde_json::to_vec_pretty(&report).unwrap()).unwrap();
    println!("passed; evidence: {}", output.display());
}
