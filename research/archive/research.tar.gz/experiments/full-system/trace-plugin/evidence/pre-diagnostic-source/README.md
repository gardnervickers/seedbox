# Exact instruction-entry observer

This plugin targets **QEMU 11.1.1 plugin API 7**, native ARM64 macOS, x86-64 system emulation, and one vCPU. It is an observer, not a deterministic scheduler. Every entered instruction contributes the same 24-byte record as the original observer: little-endian 64-bit guest PC, one-byte opcode length, then 15 zero-padded opcode bytes. Whole-history SHA-256, exact million-entry chunk hashes, and the final partial-chunk hash are preserved. REP reentries and instructions that subsequently fault are entries, not retirement.

The hot path uses a vCPU0 thread-local pointer to a retained heap `RefCell<Trace>`, without a mutex or atomic operation on valid instruction entries. Records are buffered in groups of up to 4,096 (96 KiB), flushed into both instruction hash streams, and also flushed at exact million-entry cuts. IRQ/exception/discontinuity records retain the original byte order: current instruction-entry count (LE u64), kind (LE i32), from PC (LE u64), to PC (LE u64). Buffering changes SHA call granularity only. No sampling, TB-only mode, truncation, or replay input is introduced.

At each 50 million entries, stderr receives `SEEDBOX_TRACE_PROGRESS entries=N`. This is observational progress; a slow run may time out before final reporting. SHA hashes appear in `SEEDBOX_TRACE_JSON=...` only after normal QEMU completion.

## Ownership and FFI

- Install copies immutable configuration only; translation reads it and retains immutable per-instruction metadata through TB flushes and process exit.
- vCPU initialization runs on the vCPU context in pinned `plugins/core.c:256–280`. It copies register handles/names from `qemu_plugin_get_registers` using the explicit API-7 C layouts, then creates the trace storage and assigns its TLS pointer. Descriptor-provided handle 0 is retained as an opaque token; only a missing register name is rejected. Every register read first clears the GLib byte buffer because the underlying register helper appends bytes.
- Instruction and discontinuity callbacks mutate that vCPU0 trace. An unexpected CPU, missing TLS, reentrant borrow, invalid translation record, or caught Rust panic invalidates the observer instead of silently accepting a shortened history.
- At `fence=420000` (hex; default guest VA `0x420000`), the instruction callback requests `QEMU_PLUGIN_CB_R_REGS` and reads registers in that CPU context. Registers are never read from translation or atexit.
- Atexit uses the retained allocation only **after execution has finished**, as guaranteed by API-7 `include/plugins/qemu-plugin.h:991–1004`. TLS destruction cannot free this intentionally retained allocation. This is a quiescent final handoff, not support for concurrent access to `RefCell`. Atexit flushes both buffers and emits the report without any register/memory QEMU API calls.
- All Rust FFI entrypoints catch unwinding panics; allocation failure may abort rather than produce a report. A missing report is failure. GLib buffers use scoped release; translated instruction metadata and trace allocation intentionally live until process exit.

Accept only reports with `observer_valid=true`, `observer_errors=0`, and `wrong_vcpu_entries=0`, plus a successful expected fence observation. Errors also emit `observer_error_reasons` counts and up to 16 `observer_error_examples` with callback/descriptor/translation/capture context; the first 16 appear immediately as `SEEDBOX_TRACE_ERROR reason=... context=...`. Counts remain complete after the example cap. Diagnostics use a mutex only on invalid paths and at quiescent final reporting, leaving valid instruction entries without added locking. Valid reports contain no host pointer or thread identifiers. `register_count` and `zero_handle_registers` expose the copied inventory. The added `fence_observations` count allows the harness to require exactly one expected fence. The harness owns the acceptance policy.

The physical-memory observation covers the pinned 128 MiB PC RAM profile, omitting the 640 KiB–1 MiB ROM/MMIO hole. It is **not an atomic device/full-kernel snapshot**: stock QEMU DMA, device callbacks, and I/O workers may run while RAM is scanned. Observer overhead and progress output may change host timing and expose guest-visible effects in stock asynchronous backends. No one-host-thread or general determinism claim follows from matching reports.

## Binding corrections and diagnostic evidence

Pinned `plugins/api.c:429–481` encodes each opaque register token as `(gdb_reg << 1) | readonly_bit` and decodes it without rejecting zero. Therefore writable register 0 has a numerically zero token; it is not a pointer to dereference. Rejecting that token omitted RAX and caused the observed single initialization error. The invalid runtime report had 65 names beginning with RBX and no RAX. The observer now retains descriptor-provided zero tokens while rejecting null names. [Pinned QEMU release source](https://download.qemu.org/qemu-11.1.1.tar.xz)

The same source's register-read API delegates to GDB helpers. `include/gdbstub/helpers.h:28–65` appends to `GByteArray`; `tests/tcg/plugins/registers.c:36–37,57–58` explicitly clears it before each read. The invalid report contained 8-byte RBX, 16-byte RCX, 24-byte RDX and further cumulative samples. The observer now invokes `g_byte_array_set_size(buffer,0)` before **every** register read. Physical-memory reads already resize their buffer within the QEMU API. This corrects register observations without changing instruction/discontinuity record encoding.

The regressions retain handle 0/`rax` and reject a null name, and use an append-only mock reader starting with existing bytes then reading two distinct registers. Removing the reset causes contaminated/incorrect-length samples and fails the test. A separate test proves reason counts stay complete while examples are capped. Fixture-specific expected RAX/RIP values and widths remain the host harness's independent oracle. These source fixes do not make the earlier invalid trace acceptable; fresh boots must use a new immutable plugin/input closure.

## Checks and build

From the canonical repository root, use the project shell and ignored isolated target directory:

```sh
nix develop .#qemu-probe -c sh -c '
  export CARGO_TARGET_DIR=target/full-system-probe
  export RUSTFLAGS="-C link-arg=-undefined -C link-arg=dynamic_lookup"
  cargo fmt --manifest-path experiments/full-system/Cargo.toml -p seedbox-qemu-trace --check
  cargo clippy --manifest-path experiments/full-system/Cargo.toml -p seedbox-qemu-trace --offline --locked --release --all-targets -- -D warnings
  cargo test --manifest-path experiments/full-system/Cargo.toml -p seedbox-qemu-trace --offline --locked --release
  cargo build --manifest-path experiments/full-system/Cargo.toml -p seedbox-qemu-trace --offline --locked --release
'
```

The dynamic-lookup linker arguments are for native macOS QEMU-resolved plugin symbols. The project probe's pinned dependencies and native build are used; no host package installation is needed.

On 2026-10-05 after these fixes, strict release Clippy and release build passed. All five release tests passed (0.47 s execution): API-7 native structure sizes/offsets; buffered-versus-original per-entry SHA at counts 0, 1, 4,095,4,096,4,097,999,999,1,000,000 and 1,000,001 including discontinuity flushes/chunk boundaries; descriptor handle 0/null-name behavior; append-reader buffer resets; bounded diagnostics with complete counts. Formatting completed. These checks establish binding/regression and synthetic byte-stream behavior, not successful fresh guest boots or callback completeness. The parent harness must rerun at least two fresh boots with the new immutable inputs and record runtime results separately.
