#!/bin/sh
set -u
cost_dir="$PWD/experiments/full-system/build/boot-cost"
closure="$PWD/experiments/full-system/build/closure-10b81d0cc944f3481dd94bac9c0e929383b1cac6ee34af92e44fddd283121381"
qemu_bin=/nix/store/lzm84ri4kbyx8gqxwk5sd21mqc5all73-qemu-11.1.1/bin/qemu-system-x86_64
cmdline='console=ttyS0 rdinit=/init nokaslr randomize_kstack_offset=off panic=-1 random.trust_cpu=on lpj=1000000 tsc_early_khz=1000000 tsc=reliable clocksource=tsc nosoftlockup loglevel=8 initcall_debug'
{ uname -a; "$qemu_bin" --version; timeout --version | head -1; } > "$cost_dir/host.txt"
printf '%s\n' "$cmdline" > "$cost_dir/cmdline.txt"
date +%s > "$cost_dir/start-seconds.txt"
timeout --kill-after=2s 15s "$qemu_bin" \
  -machine pc,vmport=off -accel tcg,thread=single -cpu qemu64,+rdrand,+rdseed \
  -smp 1 -m 128M -nodefaults -display none -monitor none -no-reboot -serial stdio \
  -kernel "$closure/vmlinuz-virt" -initrd "$closure/initramfs.cpio" \
  -append "$cmdline" -device isa-debug-exit,iobase=0xf4,iosize=0x4 \
  -seed 42 -icount shift=10,align=off,sleep=off \
  -rtc base=2020-01-01T00:00:00,clock=vm \
  > "$cost_dir/serial.txt" 2> "$cost_dir/stderr.txt"
cost_status=$?
date +%s > "$cost_dir/end-seconds.txt"
printf '%s\n' "$cost_status" > "$cost_dir/status.txt"
printf 'bounded boot status=%s\n' "$cost_status"
exit 0
