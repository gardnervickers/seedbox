use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::error::Error;
use std::fs::{self, File};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};
use std::time::{Duration, Instant};

type Result<T> = std::result::Result<T, Box<dyn Error>>;
// Separate pinned probe profile: bypass costly calibration for the icount TSC
// (one nanosecond per tick); keep clocks, timers, processes, RNG and AIO active.
const KERNEL_CMDLINE: &str = "console=ttyS0 rdinit=/init nokaslr randomize_kstack_offset=off quiet panic=-1 random.trust_cpu=on lpj=1000000 tsc_early_khz=1000000 tsc=reliable clocksource=tsc nosoftlockup";
const ICOUNT_PROFILE: &str = "shift=4,align=off,sleep=off";
fn initial_epoch(observations: &[&str]) -> Result<u64> {
    let seconds = |prefix: &str| -> Result<u64> {
        let value = observations
            .iter()
            .find_map(|line| line.strip_prefix(prefix))
            .ok_or("missing initial clock")?;
        Ok(u64::from_str_radix(
            value
                .split_whitespace()
                .next()
                .ok_or("missing clock seconds")?,
            16,
        )?)
    };
    seconds("OBS initial.realtime sec=")?
        .checked_sub(seconds("OBS initial.monotonic sec=")?)
        .ok_or_else(|| "negative initial realtime epoch".into())
}
fn sha(path: &Path) -> Result<String> {
    Ok(hex::encode(Sha256::digest(fs::read(path)?)))
}
fn binary(name: &str) -> Result<PathBuf> {
    std::env::split_paths(&std::env::var_os("PATH").ok_or("no PATH")?)
        .map(|p| p.join(name))
        .find(|p| p.is_file())
        .ok_or_else(|| format!("missing {name}").into())
}
fn first_differing_chunk(a: &[Value], b: &[Value]) -> Option<usize> {
    a.iter()
        .zip(b)
        .position(|(a, b)| a != b)
        .or_else(|| (a.len() != b.len()).then_some(a.len().min(b.len())))
}
fn is_sha256(value: &Value) -> bool {
    value
        .as_str()
        .is_some_and(|hash| hash.len() == 64 && hash.bytes().all(|b| b.is_ascii_hexdigit()))
}
fn valid_tail(entries: u64, start: &Value, pcs: &Value) -> bool {
    let Some(pcs) = pcs.as_array() else {
        return false;
    };
    let len = entries.min(64);
    pcs.len() as u64 == len
        && pcs.iter().all(|pc| pc.as_u64().is_some())
        && start.as_u64() == Some(entries - len + 1)
}
fn valid_fence_prefix(trace: &Value) -> bool {
    let prefix = &trace["fence_prefix"];
    let Some(entries) = prefix["instruction_entries"].as_u64() else {
        return false;
    };
    let Some(total) = trace["instruction_entries"].as_u64() else {
        return false;
    };
    let Some(discontinuities) = trace["discontinuity_count"].as_u64() else {
        return false;
    };
    let Some(prefix_discontinuities) = prefix["discontinuity_count"].as_u64() else {
        return false;
    };
    let Some(chunks) = trace["million_entry_chunks"].as_array() else {
        return false;
    };
    let hashes = [
        "instruction_sha256",
        "discontinuity_sha256",
        "last_chunk_sha256",
    ];
    entries > 0
        && total >= entries
        && prefix_discontinuities <= discontinuities
        && chunks.len() as u64 == total / 1_000_000
        && chunks.iter().all(is_sha256)
        && hashes
            .iter()
            .all(|key| is_sha256(&trace[key]) && is_sha256(&prefix[key]))
        && trace["post_fence_entries"].as_u64() == Some(total - entries)
        && prefix["partial_chunk_entries"].as_u64() == Some(entries % 1_000_000)
        && prefix["completed_million_entry_chunks"].as_u64() == Some(entries / 1_000_000)
        && valid_tail(entries, &prefix["tail_start_entry"], &prefix["tail_pcs"])
        && valid_tail(
            total,
            &trace["final_tail_start_entry"],
            &trace["final_tail_pcs"],
        )
        && prefix["tail_pcs"]
            .as_array()
            .and_then(|tail| tail.last())
            .and_then(Value::as_u64)
            == Some(0x420000)
        && (total != entries
            || (trace["instruction_sha256"] == prefix["instruction_sha256"]
                && trace["last_chunk_sha256"] == prefix["last_chunk_sha256"]))
}
fn compare(left: &Value, right: &Value) -> Value {
    let a = &left["canonical"];
    let b = &right["canonical"];
    let aa = a["trace"]["million_entry_chunks"].as_array();
    let bb = b["trace"]["million_entry_chunks"].as_array();
    let first_chunk = aa.zip(bb).and_then(|(a, b)| first_differing_chunk(a, b));
    let first_instruction_chunk = first_chunk
        .map(|i| json!({"kind":"million","index_zero_based":i,"start_entry":i as u64 * 1_000_000 + 1}))
        .or_else(|| {
            (a["trace"]["last_chunk_sha256"] != b["trace"]["last_chunk_sha256"]
                || a["trace"]["instruction_entries"] != b["trace"]["instruction_entries"])
                .then(|| {
                    let i = aa.map_or(0, Vec::len);
                    json!({"kind":"partial","index_zero_based":i,"start_entry":i as u64 * 1_000_000 + 1})
                })
        });
    let prefixes_valid = valid_fence_prefix(&a["trace"]) && valid_fence_prefix(&b["trace"]);
    let initial_realtime = |canonical: &Value| {
        canonical["observations"]
            .as_array()
            .and_then(|lines| {
                lines
                    .iter()
                    .filter_map(Value::as_str)
                    .find(|line| line.starts_with("OBS initial.realtime sec="))
            })
            .map(str::to_owned)
    };
    json!({"left":left["name"],"right":right["name"],"exact_equal":a==b,
        "host_clock_negative":left["host_clock"],
        "initial_realtime_equal":initial_realtime(a)==initial_realtime(b),
        "initial_epoch_equal":left["initial_epoch_sec"]==right["initial_epoch_sec"],
        "observations_equal":a["observations"]==b["observations"],
        "instruction_history_equal":a["trace"]["instruction_sha256"]==b["trace"]["instruction_sha256"] && a["trace"]["instruction_entries"]==b["trace"]["instruction_entries"],
        "interrupt_exception_history_equal":a["trace"]["discontinuity_sha256"]==b["trace"]["discontinuity_sha256"] && a["trace"]["discontinuity_count"]==b["trace"]["discontinuity_count"],
        "registers_equal":a["trace"]["fence_observation"]["registers"]==b["trace"]["fence_observation"]["registers"],
        "ram_equal":a["trace"]["fence_observation"]["ram_sha256"]==b["trace"]["fence_observation"]["ram_sha256"],
        "fence_prefixes_valid":prefixes_valid,
        "fence_prefix_equal":prefixes_valid && a["trace"]["fence_prefix"]==b["trace"]["fence_prefix"],
        "fence_instruction_history_equal":prefixes_valid && a["trace"]["fence_prefix"]["instruction_sha256"]==b["trace"]["fence_prefix"]["instruction_sha256"] && a["trace"]["fence_prefix"]["instruction_entries"]==b["trace"]["fence_prefix"]["instruction_entries"],
        "fence_interrupt_exception_history_equal":prefixes_valid && a["trace"]["fence_prefix"]["discontinuity_sha256"]==b["trace"]["fence_prefix"]["discontinuity_sha256"] && a["trace"]["fence_prefix"]["discontinuity_count"]==b["trace"]["fence_prefix"]["discontinuity_count"],
        "first_differing_million_entry_chunk":first_chunk,
        "first_differing_instruction_chunk":first_instruction_chunk})
}

fn run(
    qemu: &Path,
    plugin: &Path,
    build: &Path,
    variant: (&str, u64, bool, bool, bool),
) -> Result<Value> {
    let (name, seed, disk, host_clock, host_load) = variant;
    let dir = build.join(name);
    fs::create_dir_all(&dir)?;
    let serial = dir.join("serial.txt");
    let stderr = dir.join("stderr.txt");
    let mut args: Vec<String> = [
        "-machine",
        "pc,vmport=off",
        "-accel",
        "tcg,thread=single",
        "-cpu",
        "qemu64,+rdrand,+rdseed",
        "-smp",
        "1",
        "-m",
        "128M",
        "-nodefaults",
        "-display",
        "none",
        "-monitor",
        "none",
        "-no-reboot",
        "-serial",
        "stdio",
    ]
    .iter()
    .map(|s| s.to_string())
    .collect();
    args.extend([
        "-kernel".into(),
        build.join("vmlinuz-virt").display().to_string(),
        "-initrd".into(),
        build.join("initramfs.cpio").display().to_string(),
        "-append".into(),
        KERNEL_CMDLINE.into(),
        "-device".into(),
        "isa-debug-exit,iobase=0xf4,iosize=0x4".into(),
        "-seed".into(),
        seed.to_string(),
        "-icount".into(),
        ICOUNT_PROFILE.into(),
        "-rtc".into(),
        if host_clock {
            "base=utc,clock=host".into()
        } else {
            "base=2020-01-01T00:00:00,clock=vm".into()
        },
        "-plugin".into(),
        format!("{},fence=0x420000", plugin.display()),
    ]);
    if disk {
        let path = dir.join("disk.raw");
        let data: Vec<u8> = (0..(1024 * 1024))
            .map(|i| ((i * 17 + 29) & 255) as u8)
            .collect();
        fs::write(&path, data)?;
        args.extend([
            "-drive".into(),
            format!("if=none,id=probe,file={},format=raw", path.display()),
            "-device".into(),
            "virtio-blk-pci,drive=probe".into(),
        ]);
    }
    fs::write(dir.join("args.json"), serde_json::to_vec_pretty(&args)?)?;
    let stop = Arc::new(AtomicBool::new(false));
    let worker = host_load.then(|| {
        let stop = stop.clone();
        std::thread::spawn(move || {
            let mut value = 1_u64;
            while !stop.load(Ordering::Relaxed) {
                for _ in 0..100_000 {
                    value = value.wrapping_mul(6364136223846793005).wrapping_add(1);
                }
                std::hint::black_box(value);
            }
        })
    });
    let start = Instant::now();
    let mut child = Command::new(qemu)
        .args(&args)
        .stdin(Stdio::null())
        .stdout(File::create(&serial)?)
        .stderr(File::create(&stderr)?)
        .spawn()?;
    let mut thread_inventory = String::new();
    let status = loop {
        if thread_inventory.is_empty() && start.elapsed() > Duration::from_millis(300) {
            let output = Command::new("ps")
                .args(["-M", "-p", &child.id().to_string(), "-o", "pid,comm"])
                .output()?;
            thread_inventory = String::from_utf8_lossy(&output.stdout).into_owned();
        }
        if let Some(status) = child.try_wait()? {
            break status;
        }
        if start.elapsed() > Duration::from_secs(300) {
            child.kill()?;
            child.wait()?;
            stop.store(true, Ordering::Relaxed);
            if let Some(worker) = worker {
                worker.join().map_err(|_| "host-load worker panic")?;
            }
            return Err(format!(
                "{name}: host resource deadline exceeded; inspect {}",
                serial.display()
            )
            .into());
        }
        std::thread::sleep(Duration::from_millis(10));
    };
    stop.store(true, Ordering::Relaxed);
    if let Some(worker) = worker {
        worker.join().map_err(|_| "host-load worker panic")?;
    }
    let seconds = start.elapsed().as_secs_f64();
    fs::write(dir.join("host-threads.txt"), &thread_inventory)?;
    let serial_text = fs::read_to_string(&serial)?.replace('\r', "");
    let stderr_text = fs::read_to_string(&stderr)?;
    let observations: Vec<&str> = serial_text
        .lines()
        .filter(|line| line.starts_with("OBS "))
        .collect();
    let trace: Value = serde_json::from_str(
        stderr_text
            .lines()
            .find_map(|s| s.strip_prefix("SEEDBOX_TRACE_JSON="))
            .ok_or_else(|| format!("{name}: no plugin trace; exit {status}; {}", stderr_text))?,
    )?;
    if status.code() != Some(33) || !observations.iter().any(|s| s.contains("OBS PASS")) {
        return Err(format!("{name}: guest failed: exit {status}; {serial_text}").into());
    }
    if disk
        && !observations
            .iter()
            .any(|s| s.starts_with("OBS disk.aio bytes="))
    {
        return Err(format!("{name}: disk AIO completion not exercised: {serial_text}").into());
    }
    if !observations
        .iter()
        .any(|s| s.starts_with("OBS initial.realtime sec="))
    {
        return Err(format!("{name}: missing CLOCK_REALTIME observation").into());
    }
    if trace["observer_valid"] != json!(true)
        || trace["observer_errors"] != json!(0)
        || trace["fence_observations"] != json!(1)
        || !valid_fence_prefix(&trace)
        || trace["fence_observation"].is_null()
        || trace["fence_observation"]["read_failures"] != json!([])
        || trace["fence_observation"]["registers"]
            .as_array()
            .is_none_or(|r| {
                r.is_empty()
                    || r.iter().any(|v| {
                        v["readable"] != json!(true)
                            || v["bytes"].as_str().is_none_or(str::is_empty)
                    })
            })
        || trace["wrong_vcpu_entries"] != json!(0)
    {
        return Err(format!(
            "{name}: invalid fence/CPU observation (valid={}, errors={}, fences={}); inspect {}",
            trace["observer_valid"],
            trace["observer_errors"],
            trace["fence_observations"],
            stderr.display()
        )
        .into());
    }
    let registers = trace["fence_observation"]["registers"]
        .as_array()
        .ok_or("missing registers")?;
    for (name, value) in [("rax", 0x10_u64), ("rip", 0x420000)] {
        let expected = hex::encode(value.to_le_bytes());
        if !registers
            .iter()
            .any(|r| r["name"] == json!(name) && r["bytes"] == json!(expected))
        {
            return Err(format!(
                "{name}: fixture fence register value/width mismatch; inspect {}",
                stderr.display()
            )
            .into());
        }
    }
    let epoch = initial_epoch(&observations)?;
    let report = json!({"name":name,"seed":seed,"disk":disk,"host_clock":host_clock,"initial_epoch_sec":epoch,
        "host_load":host_load,"host_seconds":seconds,"canonical":{"exit":status.code(),"observations":observations,"trace":trace}});
    fs::write(dir.join("report.json"), serde_json::to_vec_pretty(&report)?)?;
    eprintln!(
        "{name}: guest PASS, {seconds:.2}s, {} instruction entries",
        report["canonical"]["trace"]["instruction_entries"]
    );
    Ok(report)
}

fn main() -> Result<()> {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let source_build = root.join("build").canonicalize()?;
    let qemu = binary("qemu-system-x86_64")?;
    let target = std::env::var_os("CARGO_TARGET_DIR")
        .map(PathBuf::from)
        .unwrap_or(root.join("target"));
    let suffix = if cfg!(target_os = "macos") {
        "dylib"
    } else {
        "so"
    };
    let source_plugin = target
        .join("release")
        .join(format!("libseedbox_qemu_trace.{suffix}"))
        .canonicalize()?;
    // Copy bytes before launch so fixture rebuilds cannot change inputs between
    // fresh boots. Hash the copied closure, not mutable source filenames.
    let assets = [
        ("vmlinuz-virt", fs::read(source_build.join("vmlinuz-virt"))?),
        (
            "initramfs.cpio",
            fs::read(source_build.join("initramfs.cpio"))?,
        ),
        (
            if cfg!(target_os = "macos") {
                "observer.dylib"
            } else {
                "observer.so"
            },
            fs::read(&source_plugin)?,
        ),
    ];
    let mut closure_hash = Sha256::new();
    closure_hash.update(KERNEL_CMDLINE.as_bytes());
    closure_hash.update(ICOUNT_PROFILE.as_bytes());
    for (name, bytes) in &assets {
        closure_hash.update(name.as_bytes());
        closure_hash.update((bytes.len() as u64).to_le_bytes());
        closure_hash.update(bytes);
    }
    let build = source_build.join(format!("closure-{}", hex::encode(closure_hash.finalize())));
    fs::create_dir_all(&build)?;
    for (name, bytes) in &assets {
        let destination = build.join(name);
        if destination.exists() {
            if fs::read(&destination)? != *bytes {
                return Err("immutable input closure changed".into());
            }
        } else {
            fs::write(&destination, bytes)?;
        }
    }
    let plugin = build.join(assets[2].0);
    let version = Command::new(&qemu).arg("--version").output()?;
    let environment = json!({"qemu_version":String::from_utf8_lossy(&version.stdout),"qemu_path":qemu,"qemu_sha256":sha(&qemu)?,
        "kernel_sha256":sha(&build.join("vmlinuz-virt"))?,"initramfs_sha256":sha(&build.join("initramfs.cpio"))?,"plugin_sha256":sha(&plugin)?,
        "input_closure":build,"kernel_cmdline":KERNEL_CMDLINE,"icount":ICOUNT_PROFILE,
        "qemu_release_source_sha256":"079ffbff8a7111bbc89022107cbabf3bbfd614d5fc9d7cc675991196aca12482",
        "nixpkgs_revision":"8c6b39505383e6d5dcb431f00cb3597b71f8045c",
        "profile":"stock QEMU baseline; not the single-thread world; no record/replay input"});
    fs::write(
        root.join("environment.json"),
        serde_json::to_vec_pretty(&environment)?,
    )?;
    let selection = std::env::args().nth(1).unwrap_or_else(|| "all".to_string());
    let variants: Vec<(&str, u64, bool, bool, bool)> = match selection.as_str() {
        "cpu" => vec![
            ("cpu-1", 42, false, false, false),
            ("cpu-2", 42, false, false, true),
        ],
        "disk" => vec![
            ("disk-1", 42, true, false, false),
            ("disk-2", 42, true, false, true),
        ],
        "negative" => vec![
            ("host-clock-1", 42, false, true, false),
            ("host-clock-2", 42, false, true, true),
        ],
        "seed" => vec![("seed-43", 43, false, false, false)],
        "all" => vec![
            ("cpu-1", 42, false, false, false),
            ("cpu-2", 42, false, false, true),
            ("disk-1", 42, true, false, false),
            ("disk-2", 42, true, false, true),
            ("host-clock-1", 42, false, true, false),
            ("host-clock-2", 42, false, true, true),
            ("seed-43", 43, false, false, false),
        ],
        _ => return Err("use cpu | disk | negative | seed | all".into()),
    };
    let mut reports = Vec::new();
    for variant in variants {
        reports.push(run(&qemu, &plugin, &build, variant)?);
    }
    let comparisons: Vec<Value> = reports
        .windows(2)
        .filter(|pair| {
            pair[0]["disk"] == pair[1]["disk"]
                && pair[0]["host_clock"] == pair[1]["host_clock"]
                && pair[0]["seed"] == pair[1]["seed"]
        })
        .map(|pair| compare(&pair[0], &pair[1]))
        .collect();
    if comparisons
        .iter()
        .any(|c| c["host_clock_negative"] == json!(true) && c["initial_epoch_equal"] == json!(true))
    {
        return Err(
            "host-clock negative control did not change the initial realtime-minus-monotonic epoch seconds"
                .into(),
        );
    }
    let output = json!({"environment":environment,"runs":reports,"comparisons":comparisons,
        "scope":"CPU/RAM/entered-instruction observations, not a device snapshot or D001 validation"});
    fs::write(
        root.join(format!("results-{selection}.json")),
        serde_json::to_vec_pretty(&output)?,
    )?;
    println!("{}", serde_json::to_string_pretty(&output["comparisons"])?);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn report(total: u64, last_hash: &str) -> Value {
        let hash = "a".repeat(64);
        let history_hash = if total == 1_000_003 {
            hash.clone()
        } else {
            hex::encode(Sha256::digest(last_hash.as_bytes()))
        };
        let mut tail = vec![0x1000_u64; 64];
        tail[63] = 0x420000;
        json!({"name":"fixture","host_clock":false,"initial_epoch_sec":0,
            "canonical":{"observations":[],"trace":{
                "instruction_entries":total,"instruction_sha256":history_hash,
                "million_entry_chunks":[hash],"last_chunk_sha256":history_hash,
                "discontinuity_sha256":hash,"discontinuity_count":3,
                "post_fence_entries":total - 1_000_003,
                "final_tail_start_entry":total - 63,"final_tail_pcs":tail,
                "fence_prefix":{"instruction_entries":1_000_003,"instruction_sha256":hash,
                    "discontinuity_sha256":hash,"discontinuity_count":3,"last_chunk_sha256":hash,
                    "partial_chunk_entries":3,"completed_million_entry_chunks":1,
                    "tail_start_entry":1_000_003 - 63,"tail_pcs":tail},
                "fence_observation":{"registers":[],"ram_sha256":"same-ram"}}}})
    }

    #[test]
    fn shutdown_suffix_difference_is_reported_without_erasing_failure() {
        let left = report(1_000_010, "left");
        let right = report(1_000_003, "right");
        let result = compare(&left, &right);
        assert_eq!(result["exact_equal"], json!(false));
        assert_eq!(result["instruction_history_equal"], json!(false));
        assert_eq!(result["fence_prefix_equal"], json!(true));
        assert_eq!(result["first_differing_million_entry_chunk"], Value::Null);
        assert_eq!(
            result["first_differing_instruction_chunk"],
            json!({
            "kind":"partial","index_zero_based":1,"start_entry":1_000_001})
        );
    }

    #[test]
    fn missing_or_inconsistent_prefix_cannot_accept_a_pair() {
        let left = report(1_000_010, "left");
        let mut missing = left.clone();
        missing["canonical"]["trace"]["fence_prefix"] = Value::Null;
        assert!(!valid_fence_prefix(&missing["canonical"]["trace"]));
        assert_eq!(
            compare(&missing, &missing)["fence_prefix_equal"],
            json!(false)
        );
        let mut corrupt = left.clone();
        corrupt["canonical"]["trace"]["post_fence_entries"] = json!(0);
        assert!(!valid_fence_prefix(&corrupt["canonical"]["trace"]));
    }

    #[test]
    fn chunk_count_difference_has_a_location() {
        let a = [json!("same")];
        let b = [json!("same"), json!("extra")];
        assert_eq!(first_differing_chunk(&a, &b), Some(1));
        assert_eq!(first_differing_chunk(&a, &a), None);
    }

    #[test]
    fn missing_or_corrupt_trace_schema_cannot_accept_prefix_equality() {
        let source = report(1_000_010, "left");
        assert!(valid_fence_prefix(&source["canonical"]["trace"]));
        for pointer in [
            "/canonical/trace/instruction_sha256",
            "/canonical/trace/discontinuity_count",
            "/canonical/trace/million_entry_chunks/0",
            "/canonical/trace/final_tail_start_entry",
            "/canonical/trace/final_tail_pcs/0",
            "/canonical/trace/fence_prefix/discontinuity_count",
            "/canonical/trace/fence_prefix/tail_start_entry",
            "/canonical/trace/fence_prefix/tail_pcs/0",
        ] {
            let mut corrupt = source.clone();
            *corrupt.pointer_mut(pointer).unwrap() = Value::Null;
            assert!(
                !valid_fence_prefix(&corrupt["canonical"]["trace"]),
                "{pointer}"
            );
            assert_eq!(
                compare(&corrupt, &corrupt)["fence_prefix_equal"],
                json!(false)
            );
        }
        let mut no_suffix = report(1_000_003, "unused");
        assert!(valid_fence_prefix(&no_suffix["canonical"]["trace"]));
        no_suffix["canonical"]["trace"]["instruction_sha256"] = json!("b".repeat(64));
        assert!(!valid_fence_prefix(&no_suffix["canonical"]["trace"]));
    }
}
