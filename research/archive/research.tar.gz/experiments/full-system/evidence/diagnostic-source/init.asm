; Minimal real Linux x86-64 /init. NASM ELF64 + fixed-address linker script.
; No libc, shell, network, vDSO, host files, or input after boot.
BITS 64
DEFAULT ABS
section .text
global _start

%macro SAY 1
    lea rsi, [%1]
    mov edx, %1 %+ _len
    call write_stdout
%endmacro
%macro FIELD 2
    SAY %1
    mov rax, %2
    call print_hex
%endmacro
%macro CLOCK 2
    mov eax, 228
    mov edi, %1
    lea rsi, [%2]
    syscall
    test rax, rax
    js fail
%endmacro

_start:
    ; Kernel initramfs may lack a console node. Mount devtmpfs without helpers.
    mov eax, 165
    lea rdi, [devtmpfs]
    lea rsi, [devpath]
    lea rdx, [devtmpfs]
    xor r10d, r10d
    xor r8d, r8d
    syscall
    test rax, rax
    js early_fail
    mov eax, 2
    lea rdi, [console]
    mov esi, 2
    xor edx, edx
    syscall
    test rax, rax
    js early_fail
    mov ebp, eax
    xor ebx, ebx
.dup:
    mov eax, 33
    mov edi, ebp
    mov esi, ebx
    syscall
    test rax, rax
    js early_fail
    inc ebx
    cmp ebx, 3
    jb .dup
    SAY begin
    CLOCK 0, realtime
    FIELD real_sec, [realtime]
    FIELD nsec, [realtime + 8]
    SAY newline
    CLOCK 1, monotonic
    FIELD mono_sec, [monotonic]
    FIELD nsec, [monotonic + 8]
    SAY newline

    ; QEMU -seed/CPU RNG is deliberately an observed input, not assumed sound.
    mov ebx, 4
.rdrand:
    mov ecx, 64
.rand_retry:
    rdrand rax
    jc .rand_ready
    loop .rand_retry
    mov rax, -1001
    jmp fail
.rand_ready:
    mov r12, rax
    FIELD random_msg, r12
    SAY newline
    dec ebx
    jnz .rdrand
    mov ebx, 4
.rdseed:
    mov ecx, 64
.seed_retry:
    rdseed rax
    jc .seed_ready
    loop .seed_retry
    mov rax, -1002
    jmp fail
.seed_ready:
    mov r12, rax
    FIELD seed_msg, r12
    SAY newline
    mov ecx, 64
.drain:
    pause
    loop .drain
    dec ebx
    jnz .rdseed
    mov eax, 318                ; getrandom(nonblock) observes Linux RNG too
    lea rdi, [random_bytes]
    mov esi, 16
    mov edx, 1
    syscall
    mov r12, rax
    FIELD kernel_rng, r12
    FIELD rng_word0, [random_bytes]
    FIELD rng_word1, [random_bytes + 8]
    SAY newline                 ; EAGAIN is reported, not hidden or blocked on

    ; Anonymous MAP_SHARED memory is shared by two separate forked processes.
    mov eax, 9
    xor edi, edi
    mov esi, 4096
    mov edx, 3
    mov r10d, 0x21
    mov r8, -1
    xor r9d, r9d
    syscall
    test rax, rax
    js fail
    mov r15, rax
    mov eax, 57
    syscall
    test rax, rax
    js fail
    jz child_timer
    mov [pid_timer], rax
    mov eax, 57
    syscall
    test rax, rax
    js fail
    jz child_busy
    mov [pid_busy], rax
    mov dword [r15], 1           ; parent releases both competitors
    mov ebx, 2
.wait:
    mov eax, 61
    mov rdi, -1
    lea rsi, [wait_status]
    xor edx, edx
    xor r10d, r10d
    syscall
    test rax, rax
    js fail
    cmp dword [wait_status], 0
    jne child_failed
    dec ebx
    jnz .wait
    cmp qword [r15 + 8], 16
    jne bad_shared
    xor r14d, r14d              ; validate both workers' unique round IDs
    xor ebx, ebx
.observations:
    FIELD item_slot, rbx
    mov r12, rbx
    shl r12, 5
    lea r12, [r15 + r12 + 64]
    mov rax, [r12]
    mov ecx, eax
    cmp ecx, 8
    jae bad_shared
    shr rax, 32
    dec eax
    cmp eax, 1
    ja bad_shared
    shl eax, 3
    add ecx, eax
    bts r14d, ecx
    jc bad_shared
    FIELD item_tag, [r12]
    FIELD sec, [r12 + 8]
    FIELD nsec, [r12 + 16]
    FIELD item_hash, [r12 + 24]
    SAY newline
    inc ebx
    cmp ebx, 16
    jb .observations
    cmp r14d, 0xffff
    jne bad_shared

    call load_modules
    call disk_probe
    CLOCK 1, monotonic
    FIELD final_mono, [monotonic]
    FIELD nsec, [monotonic + 8]
    SAY newline
    CLOCK 0, realtime
    FIELD final_real, [realtime]
    FIELD nsec, [realtime + 8]
    SAY newline
    SAY passed
    mov bl, 0x10
    jmp finish

child_timer:
    mov ebx, 1
    jmp child
child_busy:
    mov ebx, 2
child:
    mov ecx, 100000000           ; bounded barrier; no syscall inside
.barrier:
    cmp dword [r15], 1
    je .released
    pause
    loop .barrier
    mov edi, 101
    jmp child_exit
.released:
    xor ebp, ebp
    mov r14, 0x6a09e667f3bcc909
    xor r14, rbx
.round:
    cmp ebx, 1
    jne .work
    mov eax, 35                 ; competing timer wakes: 1ms relative nanosleep
    lea rdi, [sleep_time]
    xor esi, esi
    syscall
    test rax, rax
    jnz child_error
.work:
    mov ecx, 50000
.syscall_free_work:
    imul r14, r14, 1664525
    add r14, 1013904223
    rol r14, 7
    dec ecx
    jnz .syscall_free_work
    CLOCK 1, child_clock
    mov eax, 1
    lock xadd [r15 + 8], rax     ; append order is a scheduler/interleaving oracle
    cmp rax, 16
    jae child_error
    shl rax, 5
    lea r13, [r15 + rax + 64]
    mov eax, ebx
    shl rax, 32
    or rax, rbp                 ; logical worker ID and iteration, no PID oracle
    mov [r13], rax
    mov rax, [child_clock]
    mov [r13 + 8], rax
    mov rax, [child_clock + 8]
    mov [r13 + 16], rax
    mov [r13 + 24], r14
    inc ebp
    cmp ebp, 8
    jb .round
    xor edi, edi
child_exit:
    mov eax, 231
    syscall
    ud2
child_error:
    mov edi, 102
    jmp child_exit

load_modules:
    ; Optional fixed module filenames, supplied from the pinned kernel artifact.
    lea r13, [module_names]
.next:
    mov rdi, [r13]
    test rdi, rdi
    jz .done
    mov eax, 2
    xor esi, esi
    xor edx, edx
    syscall
    cmp rax, -2                 ; absent module is normal for built-in drivers
    je .continue
    test rax, rax
    js fail
    mov r12, rax
    mov eax, 313                ; finit_module, uncompressed module profile
    mov rdi, r12
    lea rsi, [empty]
    xor edx, edx
    syscall
    cmp rax, -17                ; EEXIST allowed if already built in/loaded
    je .close
    test rax, rax
    js fail
.close:
    mov eax, 3
    mov rdi, r12
    syscall
.continue:
    add r13, 8
    jmp .next
.done:
    ret

disk_probe:
    mov eax, 2
    lea rdi, [disk_path]
    mov esi, 0x4000             ; O_RDONLY | O_DIRECT
    xor edx, edx
    syscall
    cmp rax, -2
    je .skip
    test rax, rax
    js fail
    mov r14, rax
    mov [iocb + 20], eax
    mov eax, 9                 ; aligned 4096-byte I/O buffer
    xor edi, edi
    mov esi, 4096
    mov edx, 3
    mov r10d, 0x22
    mov r8, -1
    xor r9d, r9d
    syscall
    test rax, rax
    js fail
    mov r13, rax
    mov [iocb + 24], rax
    mov eax, 206               ; io_setup(1, &context)
    mov edi, 1
    lea rsi, [aio_context]
    syscall
    test rax, rax
    js fail
    mov eax, 209               ; io_submit(context, 1, iocb**)
    mov rdi, [aio_context]
    mov esi, 1
    lea rdx, [iocb_pointer]
    syscall
    cmp rax, 1
    jne fail
    mov eax, 208               ; io_getevents(..., 100ms bound)
    mov rdi, [aio_context]
    mov esi, 1
    mov edx, 1
    lea r10, [aio_event]
    lea r8, [aio_timeout]
    syscall
    cmp rax, 1
    jne fail
    cmp qword [aio_event], 0x1234
    jne bad_disk
    cmp qword [aio_event + 16], 4096
    jne bad_disk
    cmp qword [aio_event + 24], 0
    jne bad_disk
    mov r12, 0xcbf29ce484222325 ; FNV-1a over first raw block
    mov rdi, 0x100000001b3
    xor ecx, ecx
.hash:
    movzx eax, byte [r13 + rcx]
    xor r12, rax
    imul r12, rdi
    inc ecx
    cmp ecx, 4096
    jb .hash
    FIELD disk_done, [aio_event + 16]
    FIELD item_hash, r12
    SAY newline
    mov eax, 207
    mov rdi, [aio_context]
    syscall
    test rax, rax
    js fail
    mov eax, 3
    mov rdi, r14
    syscall
    ret
.skip:
    SAY disk_skip
    ret

child_failed:
    mov rax, -1003
    jmp fail
bad_shared:
    mov rax, -1004
    jmp fail
bad_disk:
    mov rax, -1005
fail:
    mov r12, rax
    FIELD failure, r12
    SAY newline
    mov bl, 0x11
    jmp finish
early_fail:
    mov bl, 0x11               ; console unavailable: exit status still fails
finish:
    mov eax, 172               ; iopl(3), PID1 capability required
    mov edi, 3
    syscall
    test rax, rax
    js halt_forever
    mov dx, 0xf4
    movzx eax, bl
    jmp probe_fence
halt_forever:
    mov eax, 34
    syscall
    jmp halt_forever

write_stdout:
    ; fixed-size observations fit tty write; fail rather than silently truncate
    mov eax, 1
    mov edi, 1
    syscall
    cmp rax, rdx
    jne early_fail
    ret
print_hex:
    push rbx
    push rcx
    mov rdi, rax
    lea rsi, [hex_buffer]
    mov ecx, 16
.digit:
    rol rdi, 4
    mov rbx, rdi
    and ebx, 15
    mov bl, [hex_digits + rbx]
    mov [rsi], bl
    inc rsi
    loop .digit
    lea rsi, [hex_buffer]
    mov edx, 16
    call write_stdout
    pop rcx
    pop rbx
    ret

%macro TEXT 2+
%1: db %2
%1 %+ _len: equ $ - %1
%endmacro
TEXT begin, "OBS begin profile=linux-real-v1 workers=2 rounds=8 busy_iterations=50000 timer_ns=1000000", 10
TEXT real_sec, "OBS initial.realtime sec="
TEXT mono_sec, "OBS initial.monotonic sec="
TEXT final_real, "OBS final.realtime sec="
TEXT final_mono, "OBS final.monotonic sec="
TEXT sec, " sec="
TEXT nsec, " nsec="
TEXT random_msg, "OBS rdrand value="
TEXT seed_msg, "OBS rdseed value="
TEXT kernel_rng, "OBS getrandom result="
TEXT rng_word0, " word0="
TEXT rng_word1, " word1="
TEXT item_slot, "OBS item slot="
TEXT item_tag, " tag="
TEXT item_hash, " hash="
TEXT disk_done, "OBS disk.aio bytes="
TEXT disk_skip, "OBS disk.aio SKIP reason=no-device", 10
TEXT failure, "OBS FAIL code="
TEXT passed, "OBS PASS", 10
TEXT newline, 10
devtmpfs: db "devtmpfs", 0
devpath: db "/dev", 0
console: db "/dev/console", 0
disk_path: db "/dev/vda", 0
empty: db 0
hex_digits: db "0123456789abcdef"
align 8
module_names: dq module_virtio, module_ring, module_modern, module_legacy, module_pci, module_blk, 0
module_virtio: db "/modules/virtio.ko", 0
module_ring: db "/modules/virtio_ring.ko", 0
module_modern: db "/modules/virtio_pci_modern_dev.ko", 0
module_legacy: db "/modules/virtio_pci_legacy_dev.ko", 0
module_pci: db "/modules/virtio_pci.ko", 0
module_blk: db "/modules/virtio_blk.ko", 0
align 8
sleep_time: dq 0, 1000000
aio_timeout: dq 0, 100000000
iocb_pointer: dq iocb
iocb: dq 0x1234, 0             ; data, key+rwflags
      dw 0, 0                 ; IOCB_CMD_PREAD, priority
      dd 0                    ; fd
      dq 0, 4096, 0, 0        ; buf, nbytes, offset, reserved
      dd 0, 0                 ; flags, resfd
aio_context: dq 0
aio_event: times 32 db 0
realtime: times 16 db 0
monotonic: times 16 db 0
child_clock: times 16 db 0     ; fork gives each child its own copy
random_bytes: times 16 db 0
pid_timer: dq 0
pid_busy: dq 0
wait_status: dd 0
hex_buffer: times 16 db 0
section .probe_fence progbits alloc exec align=1
global probe_fence
probe_fence:
    out dx, eax                ; VA 0x420000; success 0x10 => QEMU exit 33
    jmp halt_forever
