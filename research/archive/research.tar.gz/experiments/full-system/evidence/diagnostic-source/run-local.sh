#!/bin/sh
set -eu
probe_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
probe_repo=$(CDPATH= cd -- "$probe_dir/../.." && pwd)
probe_selection=${1:-cpu}
case "$probe_selection" in cpu|disk|negative|seed|all) ;; *) echo 'use cpu | disk | negative | seed | all' >&2; exit 2;; esac
if [ "${QEMU_PROBE_VERSION:-}" != 11.1.1 ]; then
  cd "$probe_repo"
  exec nix develop .#qemu-probe --command sh "$probe_dir/run-local.sh" "$probe_selection"
fi
cd "$probe_repo"
mkdir -p "$probe_dir/build"
probe_archive="$probe_dir/build/alpine-netboot-3.22.2-x86_64.tar.gz"
if [ ! -f "$probe_archive" ]; then
  curl --fail --location --retry 2 \
    https://dl-cdn.alpinelinux.org/alpine/v3.22/releases/x86_64/alpine-netboot-3.22.2-x86_64.tar.gz \
    -o "$probe_archive.partial"
  printf '42ddf844d17c7eed833a1cafe52c446651b9cb5a6a28a32dbf37829231c17f4f  %s\n' "$probe_archive.partial" | sha256sum -c -
  mv "$probe_archive.partial" "$probe_archive"
fi
printf '42ddf844d17c7eed833a1cafe52c446651b9cb5a6a28a32dbf37829231c17f4f  %s\n' "$probe_archive" | sha256sum -c -
tar -xzf "$probe_archive" -C "$probe_dir/build" boot/vmlinuz-virt boot/initramfs-virt boot/config-6.12.51-0-virt
cp "$probe_dir/build/boot/vmlinuz-virt" "$probe_dir/build/vmlinuz-virt"
sh "$probe_dir/prepare-guest.sh"
export CARGO_TARGET_DIR="$probe_repo/target/full-system-probe"
cargo fmt --manifest-path "$probe_dir/Cargo.toml" --check
cargo clippy --locked --release --manifest-path "$probe_dir/Cargo.toml" --all-targets -- -D warnings
cargo test --locked --release --manifest-path "$probe_dir/Cargo.toml" --workspace
cargo build --locked --release --manifest-path "$probe_dir/Cargo.toml"
"$CARGO_TARGET_DIR/release/seedbox-full-system-probe" "$probe_selection"
