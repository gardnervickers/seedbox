fn main() {
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("macos") {
        // The loaded QEMU process supplies the plugin and GLib ABI symbols.
        println!("cargo:rustc-link-arg=-Wl,-undefined,dynamic_lookup");
    }
}
