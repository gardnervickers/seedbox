#!/bin/sh
set -eu
# Invoke inside: nix develop .#qemu-probe -c sh experiments/full-system/prepare-guest.sh
# Root harness owns pinned kernel acquisition and the output build directory.
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
project_dir=$(CDPATH= cd -- "$script_dir/../.." && pwd)
output_dir=${1:-"$script_dir/build"}
module_dir=${2:-}
mkdir -p "$output_dir"
output_dir=$(CDPATH= cd -- "$output_dir" && pwd)
if [ -f "$output_dir/vmlinuz-virt" ]; then
  (cd "$output_dir" && printf '%s\n' 'ec9073e710b26f5907024476c084188a01610a5a48a948bd1664ac42faaadbd4  vmlinuz-virt' | sha256sum -c -)
fi
root_dir="$output_dir/initramfs-root"
rm -rf "$root_dir"             # this script's generated tree only
mkdir -p "$root_dir/dev" "$root_dir/modules"
nasm -f elf64 "$script_dir/guest/init.asm" -o "$output_dir/init.o"
ld.lld -m elf_x86_64 -T "$script_dir/guest/init.ld" "$output_dir/init.o" -o "$root_dir/init"
chmod 0755 "$root_dir/init"
if [ -n "$module_dir" ]; then
  # Six exact module names, from the same pinned kernel; no live host modules.
  for module in virtio virtio_ring virtio_pci_modern_dev virtio_pci_legacy_dev virtio_pci virtio_blk; do
    if [ -f "$module_dir/$module.ko" ]; then
      cp "$module_dir/$module.ko" "$root_dir/modules/$module.ko"
    fi
  done
fi
# The matching official netboot initramfs is used only as a module container,
# never as /init or another userspace dependency. The host owns its acquisition.
if [ -z "$module_dir" ] && [ -f "$output_dir/boot/initramfs-virt" ]; then
  module_extract="$output_dir/kernel-module-extract"
  mkdir -p "$module_extract"
  (cd "$output_dir" && printf '%s\n' 'e8a5fcc2d9f1a5c8accd7948aad30ab941f8916e94b6a34bf93d106fb81b4192  boot/initramfs-virt' | sha256sum -c -)
  (cd "$module_extract" && gzip -dc "$output_dir/boot/initramfs-virt" | cpio --quiet -idu 'lib/modules/*/kernel/drivers/block/virtio_blk.ko')
  for module in "$module_extract"/lib/modules/*/kernel/drivers/block/virtio_blk.ko; do
    if [ -f "$module" ]; then cp "$module" "$root_dir/modules/virtio_blk.ko"; fi
  done
  (cd "$root_dir/modules" && printf '%s\n' '3b61ff0fd61fd3b5841ff6db131e36d2c44e2f1b04661fed8cf2a862d410f93e  virtio_blk.ko' | sha256sum -c -)
fi
# Fixed metadata/order makes fresh archives reproducible. No root/mknod needed;
# /init mounts devtmpfs before opening the console.
TZ=UTC find "$root_dir" -exec touch -h -t 197001010000.00 {} +
(cd "$root_dir" && find . -print | LC_ALL=C sort | cpio --quiet -o -H newc --reproducible --owner=0:0) > "$output_dir/initramfs.cpio"
sha256sum "$root_dir/init" "$output_dir/initramfs.cpio"
printf '%s\n' "Prepared $output_dir/initramfs.cpio; use kernel rdinit=/init console=ttyS0."
