//! Observational plugin for pinned QEMU 11.1.1, plugin API 7.
//! Entries include faulting/REP entries, not architectural retirement.
//! The fence CPU/RAM observation is not an atomic device/worker snapshot.
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::cell::{Cell, RefCell};
use std::collections::BTreeMap;
use std::ffi::{CStr, c_char, c_int, c_uint, c_void};
use std::io::{self, Write};
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::ptr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Mutex, OnceLock};

const API: c_int = 7;
const NO_REGS: c_int = 0;
const R_REGS: c_int = 1;
const RECORD_BYTES: usize = 24;
const BUFFER_BYTES: usize = RECORD_BYTES * 4096;
const CHUNK_ENTRIES: u64 = 1_000_000;
const PROGRESS_ENTRIES: u64 = 50_000_000;
const TAIL_PCS: usize = 64;
const _: () = assert!(TAIL_PCS.is_power_of_two());

// API 7 qemu_info_t: version's two ints and the system union's two ints have
// these offsets on the pinned native ARM64 macOS C ABI. bool is C _Bool.
#[repr(C)]
pub struct QemuInfo {
    target: *const c_char,
    minimum_api: c_int,
    current_api: c_int,
    system_emulation: bool,
    initial_vcpus: c_int,
    maximum_vcpus: c_int,
}
#[repr(C)]
struct GArray {
    data: *mut c_void,
    len: c_uint,
}
#[repr(C)]
struct ByteArray {
    data: *mut u8,
    len: c_uint,
}
#[repr(C)]
struct RegisterDescriptor {
    handle: *mut c_void,
    name: *const c_char,
    feature: *const c_char,
    readonly: bool,
}
type VcpuCallback = unsafe extern "C" fn(c_uint, *mut c_void);
unsafe extern "C" {
    fn qemu_plugin_register_vcpu_init_cb(id: u64, cb: VcpuCallback, data: *mut c_void);
    fn qemu_plugin_register_vcpu_tb_trans_cb(
        id: u64,
        cb: unsafe extern "C" fn(*mut c_void, *mut c_void),
        data: *mut c_void,
    );
    fn qemu_plugin_register_vcpu_insn_exec_cb(
        insn: *mut c_void,
        cb: VcpuCallback,
        flags: c_int,
        data: *mut c_void,
    );
    fn qemu_plugin_register_vcpu_discon_cb(
        id: u64,
        kind: c_int,
        cb: unsafe extern "C" fn(c_uint, c_int, u64, u64, *mut c_void),
        data: *mut c_void,
    );
    fn qemu_plugin_register_atexit_cb(
        id: u64,
        cb: unsafe extern "C" fn(*mut c_void),
        data: *mut c_void,
    );
    fn qemu_plugin_tb_n_insns(tb: *const c_void) -> usize;
    fn qemu_plugin_tb_get_insn(tb: *const c_void, index: usize) -> *mut c_void;
    fn qemu_plugin_insn_vaddr(insn: *const c_void) -> u64;
    fn qemu_plugin_insn_data(insn: *const c_void, dest: *mut c_void, len: usize) -> usize;
    fn qemu_plugin_get_registers() -> *mut GArray;
    fn qemu_plugin_read_register(handle: *mut c_void, bytes: *mut ByteArray) -> bool;
    fn qemu_plugin_read_memory_hwaddr(address: u64, bytes: *mut ByteArray, len: usize) -> c_int;
    fn g_array_free(array: *mut GArray, free_segment: c_int) -> *mut c_char;
    fn g_byte_array_sized_new(size: c_uint) -> *mut ByteArray;
    fn g_byte_array_unref(bytes: *mut ByteArray);
    fn g_byte_array_set_size(bytes: *mut ByteArray, len: c_uint) -> *mut ByteArray;
}

#[unsafe(no_mangle)]
pub static qemu_plugin_version: c_int = API;

struct Config {
    fence_pc: u64,
    ram_bytes: u64,
}
struct Instruction {
    // LE VA, u8 length, 15 zero-padded opcode bytes. Schema unchanged.
    record: [u8; RECORD_BYTES],
    fence: bool,
}
struct Trace {
    instructions: Sha256,
    chunk: Sha256,
    buffer: Vec<u8>,
    chunks: Vec<String>,
    entries: u64,
    discontinuities: Sha256,
    discontinuity_buffer: Vec<u8>,
    discontinuity_count: u64,
    registers: Vec<(usize, String)>,
    snapshot: Value,
    fence_observations: u64,
    recent_pcs: [u64; TAIL_PCS],
    fence_entry: Option<u64>,
    fence_prefix: Value,
}
impl Trace {
    fn new(registers: Vec<(usize, String)>) -> Self {
        Self {
            instructions: Sha256::new(),
            chunk: Sha256::new(),
            buffer: Vec::with_capacity(BUFFER_BYTES),
            chunks: Vec::new(),
            entries: 0,
            discontinuities: Sha256::new(),
            discontinuity_buffer: Vec::with_capacity(BUFFER_BYTES),
            discontinuity_count: 0,
            registers,
            snapshot: Value::Null,
            fence_observations: 0,
            recent_pcs: [0; TAIL_PCS],
            fence_entry: None,
            fence_prefix: Value::Null,
        }
    }

    fn flush_instructions(&mut self) {
        self.instructions.update(&self.buffer);
        self.chunk.update(&self.buffer);
        self.buffer.clear();
    }

    fn flush_discontinuities(&mut self) {
        self.discontinuities.update(&self.discontinuity_buffer);
        self.discontinuity_buffer.clear();
    }

    fn entry(&mut self, record: &[u8; RECORD_BYTES]) {
        // One fixed-ring store per entry; no allocation, lock or hash clone.
        self.recent_pcs[self.entries as usize & (TAIL_PCS - 1)] =
            u64::from_le_bytes(record[..8].try_into().unwrap());
        self.buffer.extend_from_slice(record);
        self.entries += 1;
        // Flush also at exact million-entry cuts: hashes and final empty-chunk
        // digest stay byte-for-byte identical to the original unbuffered oracle.
        if self.buffer.len() >= BUFFER_BYTES || self.entries.is_multiple_of(CHUNK_ENTRIES) {
            self.flush_instructions();
        }
        if self.entries.is_multiple_of(CHUNK_ENTRIES) {
            self.chunks
                .push(hex::encode(std::mem::take(&mut self.chunk).finalize()));
        }
        if self.entries.is_multiple_of(PROGRESS_ENTRIES) {
            let _ = writeln!(
                io::stderr().lock(),
                "SEEDBOX_TRACE_PROGRESS entries={}",
                self.entries
            );
        }
    }

    fn tail_pcs(&self) -> Vec<u64> {
        let len = self.entries.min(TAIL_PCS as u64) as usize;
        let start = (self.entries - len as u64) as usize;
        (0..len)
            .map(|offset| self.recent_pcs[(start + offset) & (TAIL_PCS - 1)])
            .collect()
    }
    fn tail_start_entry(&self) -> Option<u64> {
        (self.entries != 0).then(|| self.entries - self.entries.min(TAIL_PCS as u64) + 1)
    }
    fn post_fence_entries(&self) -> Option<u64> {
        self.fence_entry.map(|fence| self.entries - fence)
    }
    fn mark_fence_prefix(&mut self) {
        if self.fence_entry.is_some() {
            return;
        }
        // Includes the fence instruction entry, before it executes and before
        // register/RAM APIs run. Flushes preserve the original full streams.
        self.flush_instructions();
        self.flush_discontinuities();
        self.fence_entry = Some(self.entries);
        self.fence_prefix = json!({
            "instruction_entries":self.entries,
            "instruction_sha256":hex::encode(self.instructions.clone().finalize()),
            "last_chunk_sha256":hex::encode(self.chunk.clone().finalize()),
            "partial_chunk_entries":self.entries % CHUNK_ENTRIES,
            "completed_million_entry_chunks":self.chunks.len(),
            "discontinuity_count":self.discontinuity_count,
            "discontinuity_sha256":hex::encode(self.discontinuities.clone().finalize()),
            "tail_start_entry":self.tail_start_entry(),
            "tail_pcs":self.tail_pcs(),
        });
    }

    fn discon(&mut self, kind: c_int, from: u64, to: u64) {
        self.discontinuity_buffer
            .extend_from_slice(&self.entries.to_le_bytes());
        self.discontinuity_buffer
            .extend_from_slice(&kind.to_le_bytes());
        self.discontinuity_buffer
            .extend_from_slice(&from.to_le_bytes());
        self.discontinuity_buffer
            .extend_from_slice(&to.to_le_bytes());
        self.discontinuity_count += 1;
        if self.discontinuity_buffer.len() >= BUFFER_BYTES {
            self.flush_discontinuities();
        }
    }
}

// Translation needs only immutable config, never the mutable vCPU trace.
static CONFIG: OnceLock<Config> = OnceLock::new();
static OBSERVER_ERRORS: AtomicU64 = AtomicU64::new(0);
static WRONG_VCPU: AtomicU64 = AtomicU64::new(0);

// Heap allocation is deliberately retained through process exit. TLS points to
// its RefCell during vCPU execution, avoiding per-instruction locks/atomics.
// The numeric address is ONLY dereferenced by finish(), after API 7 guarantees
// execution has finished. It is not an API for concurrent cross-thread reads.
static FINISH_TRACE: OnceLock<usize> = OnceLock::new();
thread_local! {
    static LOCAL_TRACE: Cell<Option<&'static RefCell<Trace>>> = const { Cell::new(None) };
}

const ERROR_EXAMPLES: usize = 16;
#[derive(Default)]
struct ErrorDiagnostics {
    reasons: BTreeMap<&'static str, u64>,
    examples: Vec<Value>,
}
impl ErrorDiagnostics {
    fn record(&mut self, reason: &'static str, context: Value) -> bool {
        *self.reasons.entry(reason).or_default() += 1;
        if self.examples.len() < ERROR_EXAMPLES {
            self.examples
                .push(json!({"reason":reason,"context":context}));
            true
        } else {
            false
        }
    }
}
static ERROR_DIAGNOSTICS: Mutex<ErrorDiagnostics> = Mutex::new(ErrorDiagnostics {
    reasons: BTreeMap::new(),
    examples: Vec::new(),
});
fn error(reason: &'static str, context: Value) {
    OBSERVER_ERRORS.fetch_add(1, Ordering::Relaxed);
    // Locks and context allocations occur only on invalid paths, never valid
    // instruction entries. Keep all reason counts but cap detailed examples.
    let mut diagnostics = ERROR_DIAGNOSTICS.lock().unwrap_or_else(|e| e.into_inner());
    if diagnostics.record(reason, context.clone()) {
        let _ = writeln!(
            io::stderr().lock(),
            "SEEDBOX_TRACE_ERROR reason={reason} context={context}"
        );
    }
}

// No Rust panic may unwind into QEMU; errors still invalidate the report.
fn ffi_guard(stage: &'static str, f: impl FnOnce()) {
    if let Err(payload) = catch_unwind(AssertUnwindSafe(f)) {
        let message = payload
            .downcast_ref::<&str>()
            .copied()
            .or_else(|| payload.downcast_ref::<String>().map(String::as_str))
            .unwrap_or("non-string panic payload");
        error("ffi_panic", json!({"stage":stage,"message":message}));
    }
}
fn with_trace(cpu: c_uint, stage: &'static str, f: impl FnOnce(&mut Trace)) {
    if cpu != 0 {
        WRONG_VCPU.fetch_add(1, Ordering::Relaxed);
        error("wrong_vcpu", json!({"stage":stage,"cpu":cpu}));
        return;
    }
    LOCAL_TRACE.with(|local| {
        let Some(cell) = local.get() else {
            error("missing_tls", json!({"stage":stage,"cpu":cpu}));
            return;
        };
        let Ok(mut state) = cell.try_borrow_mut() else {
            error("reentrant_trace_borrow", json!({"stage":stage,"cpu":cpu}));
            return;
        };
        f(&mut state);
    });
}
// SAFETY: caller supplies an API-7 descriptor and live QEMU-owned C name.
unsafe fn copy_register_descriptor(
    r: &RegisterDescriptor,
) -> Result<(usize, String), &'static str> {
    if r.name.is_null() {
        return Err("register_null_name");
    }
    // api.c:456 encodes (gdb_reg<<1)|readonly. Register0's writable handle
    // is numerically zero; it is an opaque token, never a pointer to dereference.
    Ok((
        r.handle as usize,
        unsafe { CStr::from_ptr(r.name) }
            .to_string_lossy()
            .into_owned(),
    ))
}

// SAFETY: QEMU invokes initialization in the vCPU context. Register handles and
// names are copied only here, using the pinned API 7 descriptor layout.
unsafe extern "C" fn cpu_init(cpu: c_uint, _data: *mut c_void) {
    ffi_guard("cpu_init", || {
        if cpu != 0 {
            WRONG_VCPU.fetch_add(1, Ordering::Relaxed);
            error("wrong_vcpu", json!({"stage":"cpu_init","cpu":cpu}));
            return;
        }
        unsafe {
            let array = qemu_plugin_get_registers();
            if array.is_null() {
                error("register_array_null", json!({"cpu":cpu}));
                return;
            }
            let len = (*array).len as usize;
            let descriptors = if len == 0 {
                &[]
            } else if (*array).data.is_null() {
                g_array_free(array, 1);
                error("register_array_null_data", json!({"cpu":cpu,"len":len}));
                return;
            } else {
                std::slice::from_raw_parts((*array).data.cast::<RegisterDescriptor>(), len)
            };
            let registers = descriptors.iter().enumerate().filter_map(|(index, r)| {
                match copy_register_descriptor(r) {
                    Ok(register) => Some(register),
                    Err(reason) => {
                        error(reason, json!({"cpu":cpu,"index":index,"descriptor_count":len,"handle_token":r.handle as usize}));
                        None
                    }
                }
            }).collect();
            g_array_free(array, 1);
            let cell = Box::leak(Box::new(RefCell::new(Trace::new(registers))));
            if FINISH_TRACE
                .set(cell as *const RefCell<Trace> as usize)
                .is_err()
            {
                error(
                    "duplicate_cpu_init",
                    json!({"cpu":cpu,"descriptor_count":len}),
                );
                return;
            }
            LOCAL_TRACE.with(|local| local.set(Some(cell)));
        }
    });
}

struct OwnedBytes(*mut ByteArray);
impl Drop for OwnedBytes {
    fn drop(&mut self) {
        // SAFETY: created once by GLib; this guard releases even on caught panic.
        if !self.0.is_null() {
            unsafe { g_byte_array_unref(self.0) };
        }
    }
}
unsafe fn byte_slice<'a>(bytes: *const ByteArray) -> &'a [u8] {
    // SAFETY: called while the owned GLib buffer is live; callers do not retain
    // the returned slice across QEMU operations that may reallocate it.
    unsafe {
        if (*bytes).len == 0 {
            &[]
        } else {
            std::slice::from_raw_parts((*bytes).data, (*bytes).len as usize)
        }
    }
}

struct RegisterReadApi {
    reset: unsafe extern "C" fn(*mut ByteArray, c_uint) -> *mut ByteArray,
    read: unsafe extern "C" fn(*mut c_void, *mut ByteArray) -> bool,
}
// SAFETY: a live GLib buffer (or equivalent test buffer) and valid opaque token.
unsafe fn sample_register(
    handle: *mut c_void,
    bytes: *mut ByteArray,
    api: &RegisterReadApi,
) -> Option<Vec<u8>> {
    unsafe {
        // gdb_get_reg* appends. Match QEMU tests/tcg/plugins/registers.c:36–37.
        (api.reset)(bytes, 0);
        (api.read)(handle, bytes).then(|| byte_slice(bytes).to_vec())
    }
}

// SAFETY: called only from the fence instruction's R_REGS callback in vCPU0.
// This physical-RAM scan does not freeze QEMU's device/DMA/I/O threads.
unsafe fn capture(state: &Trace, config: &Config) -> Value {
    unsafe {
        let bytes = OwnedBytes(g_byte_array_sized_new(1 << 20));
        if bytes.0.is_null() {
            error("capture_allocation", json!({"entries":state.entries}));
            return json!({"capture_error":"GLib allocation failed"});
        }
        let register_api = RegisterReadApi {
            reset: g_byte_array_set_size,
            read: qemu_plugin_read_register,
        };
        let registers: Vec<Value> = state
            .registers
            .iter()
            .map(|(handle, name)| {
                let sample = sample_register(*handle as *mut c_void, bytes.0, &register_api);
                let ok = sample.is_some();
                if !ok {
                    error(
                        "register_read_failed",
                        json!({"name":name,"handle_token":handle,"entries":state.entries}),
                    );
                }
                let value = sample.map(hex::encode).unwrap_or_default();
                json!({"name":name,"readable":ok,"bytes":value})
            })
            .collect();
        let mut digest = Sha256::new();
        let mut chunks = Vec::new();
        let mut failures = Vec::new();
        // Pinned 128 MiB PC profile: omit 640 KiB..1 MiB ROM/MMIO hole.
        for (start, end) in [(0, 640 * 1024), (1024 * 1024, config.ram_bytes)] {
            let mut address = start;
            while address < end {
                let len = (end - address).min(1 << 20) as usize;
                let result = qemu_plugin_read_memory_hwaddr(address, bytes.0, len);
                if result != 0 || (*bytes.0).len as usize != len {
                    error(
                        "ram_read_failed",
                        json!({"address":address,"result":result,"expected_length":len,"actual_length":(*bytes.0).len,"entries":state.entries}),
                    );
                    failures
                        .push(json!({"address":address,"result":result,"length":(*bytes.0).len}));
                    break;
                }
                let data = byte_slice(bytes.0);
                digest.update(address.to_le_bytes());
                digest.update((len as u64).to_le_bytes());
                digest.update(data);
                chunks.push(json!({"address":address,"length":len,"sha256":hex::encode(Sha256::digest(data))}));
                address += len as u64;
            }
        }
        json!({"registers":registers,"ram_sha256":hex::encode(digest.finalize()),"ram_chunks":chunks,"read_failures":failures})
    }
}

unsafe extern "C" fn instruction(cpu: c_uint, data: *mut c_void) {
    ffi_guard("instruction", || {
        if data.is_null() {
            error("instruction_metadata_null", json!({"cpu":cpu}));
            return;
        }
        // SAFETY: immutable metadata is leaked by translate through QEMU exit.
        let metadata = unsafe { &*data.cast::<Instruction>() };
        with_trace(cpu, "instruction", |state| {
            state.entry(&metadata.record);
            if metadata.fence {
                if let Some(config) = CONFIG.get() {
                    state.mark_fence_prefix();
                    state.snapshot = unsafe { capture(state, config) };
                    state.fence_observations += 1;
                } else {
                    error(
                        "fence_missing_config",
                        json!({"cpu":cpu,"entries":state.entries}),
                    );
                }
            }
        });
    });
}

unsafe extern "C" fn translate(tb: *mut c_void, _data: *mut c_void) {
    ffi_guard("translate", || {
        let Some(config) = CONFIG.get() else {
            error("translation_missing_config", json!({}));
            return;
        };
        if tb.is_null() {
            error("translation_tb_null", json!({}));
            return;
        }
        unsafe {
            for index in 0..qemu_plugin_tb_n_insns(tb) {
                let insn = qemu_plugin_tb_get_insn(tb, index);
                if insn.is_null() {
                    error(
                        "translation_insn_null",
                        json!({"index":index,"tb_insns":qemu_plugin_tb_n_insns(tb)}),
                    );
                    continue;
                }
                let pc = qemu_plugin_insn_vaddr(insn);
                let mut record = [0_u8; RECORD_BYTES];
                record[..8].copy_from_slice(&pc.to_le_bytes());
                let len = qemu_plugin_insn_data(insn, record[9..].as_mut_ptr().cast(), 15);
                if !(1..=15).contains(&len) {
                    error(
                        "translation_invalid_opcode_length",
                        json!({"index":index,"pc":pc,"length":len,"tb_insns":qemu_plugin_tb_n_insns(tb)}),
                    );
                    continue;
                }
                record[8] = len as u8;
                let metadata = Box::new(Instruction {
                    record,
                    fence: pc == config.fence_pc,
                });
                // Preserve metadata through TB flush/reuse, as in the old probe.
                let flags = if metadata.fence { R_REGS } else { NO_REGS };
                qemu_plugin_register_vcpu_insn_exec_cb(
                    insn,
                    instruction,
                    flags,
                    Box::into_raw(metadata).cast(),
                );
            }
        }
    });
}

unsafe extern "C" fn discontinuity(
    cpu: c_uint,
    kind: c_int,
    from: u64,
    to: u64,
    _data: *mut c_void,
) {
    ffi_guard("discontinuity", || {
        with_trace(cpu, "discontinuity", |state| state.discon(kind, from, to))
    });
}

unsafe extern "C" fn finish(_data: *mut c_void) {
    ffi_guard("finish", || {
        let (Some(address), Some(config)) = (FINISH_TRACE.get(), CONFIG.get()) else {
            error(
                "finish_missing_state",
                json!({"trace_present":FINISH_TRACE.get().is_some(),"config_present":CONFIG.get().is_some()}),
            );
            return;
        };
        // SAFETY: API7 atexit callback runs once execution has finished
        // (qemu-plugin.h:991–1004). Storage is leaked and never freed by TLS.
        // No register or memory QEMU APIs are queried in this context.
        let cell = unsafe { &*(*address as *const RefCell<Trace>) };
        let Ok(mut state) = cell.try_borrow_mut() else {
            error("finish_trace_borrow", json!({}));
            return;
        };
        state.flush_instructions();
        state.flush_discontinuities();
        let errors = OBSERVER_ERRORS.load(Ordering::Relaxed);
        let wrong_vcpu = WRONG_VCPU.load(Ordering::Relaxed);
        let diagnostics = ERROR_DIAGNOSTICS.lock().unwrap_or_else(|e| e.into_inner());
        let report = json!({
            "plugin_api":API,"instruction_entries":state.entries,
            "instruction_sha256":hex::encode(state.instructions.clone().finalize()),
            "million_entry_chunks":state.chunks,
            "last_chunk_sha256":hex::encode(state.chunk.clone().finalize()),
            "discontinuity_count":state.discontinuity_count,
            "discontinuity_sha256":hex::encode(state.discontinuities.clone().finalize()),
            "wrong_vcpu_entries":wrong_vcpu,"fence_pc":config.fence_pc,
            "fence_observation":state.snapshot,"fence_observations":state.fence_observations,
            "fence_prefix":state.fence_prefix,"post_fence_entries":state.post_fence_entries(),
            "final_tail_start_entry":state.tail_start_entry(),"final_tail_pcs":state.tail_pcs(),
            "observer_errors":errors,"observer_valid":errors == 0 && wrong_vcpu == 0,
            "observer_error_reasons":diagnostics.reasons,"observer_error_examples":diagnostics.examples,
            "register_count":state.registers.len(),
            "zero_handle_registers":state.registers.iter().filter(|(handle,_)| *handle == 0).map(|(_,name)| name).collect::<Vec<_>>()
        });
        let _ = writeln!(io::stderr().lock(), "SEEDBOX_TRACE_JSON={report}");
    });
}

/// # Safety
/// QEMU must supply valid API-7 info/arguments and keep callbacks loaded through
/// exit. This probe supports one x86-64 system vCPU. Atexit must follow execution.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn qemu_plugin_install(
    id: u64,
    info: *const QemuInfo,
    argc: c_int,
    argv: *const *const c_char,
) -> c_int {
    let result = catch_unwind(AssertUnwindSafe(|| unsafe {
        if info.is_null()
            || argc < 0
            || (argc > 0 && argv.is_null())
            || !(*info).system_emulation
            || (*info).initial_vcpus != 1
            || (*info).current_api < API
            || (*info).minimum_api > API
            || (*info).target.is_null()
            || CStr::from_ptr((*info).target).to_bytes() != b"x86_64"
        {
            return 1;
        }
        let mut fence_pc = 0x420000;
        for index in 0..argc {
            let value = *argv.add(index as usize);
            if value.is_null() {
                return 1;
            }
            let arg = CStr::from_ptr(value).to_string_lossy();
            if let Some(value) = arg.strip_prefix("fence=") {
                let Ok(value) = u64::from_str_radix(value.trim_start_matches("0x"), 16) else {
                    return 1;
                };
                fence_pc = value;
            } else {
                return 1;
            }
        }
        if CONFIG
            .set(Config {
                fence_pc,
                ram_bytes: 128 * 1024 * 1024,
            })
            .is_err()
        {
            return 1;
        }
        qemu_plugin_register_vcpu_init_cb(id, cpu_init, ptr::null_mut());
        qemu_plugin_register_vcpu_tb_trans_cb(id, translate, ptr::null_mut());
        qemu_plugin_register_vcpu_discon_cb(id, -1, discontinuity, ptr::null_mut());
        qemu_plugin_register_atexit_cb(id, finish, ptr::null_mut());
        0
    }));
    match result {
        Ok(status) => status,
        Err(_) => {
            error("install_panic", json!({}));
            1
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn descriptor_zero_handle_is_valid_but_null_name_is_not() {
        let mut descriptor = RegisterDescriptor {
            handle: ptr::null_mut(),
            name: c"rax".as_ptr(),
            feature: ptr::null(),
            readonly: false,
        };
        assert_eq!(
            unsafe { copy_register_descriptor(&descriptor) },
            Ok((0, "rax".into()))
        );
        descriptor.name = ptr::null();
        assert_eq!(
            unsafe { copy_register_descriptor(&descriptor) },
            Err("register_null_name")
        );
    }
    unsafe extern "C" fn reset_test_buffer(bytes: *mut ByteArray, len: c_uint) -> *mut ByteArray {
        unsafe {
            (*bytes).len = len;
        }
        bytes
    }
    unsafe extern "C" fn append_test_register(handle: *mut c_void, bytes: *mut ByteArray) -> bool {
        unsafe {
            std::ptr::write_bytes(
                (*bytes).data.add((*bytes).len as usize),
                (handle as usize + 0x31) as u8,
                8,
            );
            (*bytes).len += 8;
        }
        true
    }
    #[test]
    fn register_reads_clear_append_buffer_for_each_sample() {
        let mut data = [0x99u8; 64];
        let mut bytes = ByteArray {
            data: data.as_mut_ptr(),
            len: 7,
        };
        let api = RegisterReadApi {
            reset: reset_test_buffer,
            read: append_test_register,
        };
        assert_eq!(
            unsafe { sample_register(ptr::null_mut(), &mut bytes, &api) },
            Some(vec![0x31; 8])
        );
        assert_eq!(
            unsafe { sample_register(2usize as *mut c_void, &mut bytes, &api) },
            Some(vec![0x33; 8])
        );
        assert_eq!(bytes.len, 8);
    }
    #[test]
    fn error_counts_remain_complete_when_examples_are_capped() {
        let mut diagnostics = ErrorDiagnostics::default();
        for index in 0..100 {
            diagnostics.record("translation_invalid_opcode_length", json!({"index":index}));
        }
        assert_eq!(
            diagnostics.reasons["translation_invalid_opcode_length"],
            100
        );
        assert_eq!(diagnostics.examples.len(), ERROR_EXAMPLES);
        assert_eq!(diagnostics.examples[0]["context"]["index"], 0);
    }

    fn synthetic_record(pc: u64) -> [u8; RECORD_BYTES] {
        let mut record = [0u8; RECORD_BYTES];
        record[..8].copy_from_slice(&pc.to_le_bytes());
        record[8] = 3;
        record[9..12].copy_from_slice(&[0x48, 0x31, 0xc0]);
        record
    }
    #[test]
    fn tail_ring_is_bounded_and_chronological_across_wraps() {
        for count in [0u64, 1, 63, 64, 65, 130] {
            let mut trace = Trace::new(Vec::new());
            assert_eq!(trace.post_fence_entries(), None);
            for pc in 0..count {
                trace.entry(&synthetic_record(pc));
            }
            let first = count.saturating_sub(TAIL_PCS as u64);
            assert_eq!(trace.tail_pcs(), (first..count).collect::<Vec<_>>());
            assert_eq!(trace.tail_start_entry(), (count != 0).then_some(first + 1));
        }
    }
    #[test]
    fn fence_prefix_matches_reference_and_preserves_full_history() {
        for count in [1u64, 4095, 4096, 4097, 999_999, 1_000_000, 1_000_001] {
            let mut trace = Trace::new(Vec::new());
            let mut full = Sha256::new();
            let mut chunk = Sha256::new();
            let mut discon = Sha256::new();
            let mut discontinuities = 0u64;
            for pc in 0..count {
                let record = synthetic_record(pc);
                trace.entry(&record);
                full.update(record);
                chunk.update(record);
                if (pc + 1).is_multiple_of(CHUNK_ENTRIES) {
                    chunk = Sha256::new();
                }
                if pc % 251 == 0 {
                    trace.discon(1, pc, pc + 1);
                    discon.update((pc + 1).to_le_bytes());
                    discon.update(1_i32.to_le_bytes());
                    discon.update(pc.to_le_bytes());
                    discon.update((pc + 1).to_le_bytes());
                    discontinuities += 1;
                }
            }
            trace.mark_fence_prefix();
            let witness = trace.fence_prefix.clone();
            assert_eq!(witness["instruction_entries"], count);
            assert_eq!(
                witness["instruction_sha256"],
                hex::encode(full.clone().finalize())
            );
            assert_eq!(
                witness["last_chunk_sha256"],
                hex::encode(chunk.clone().finalize())
            );
            assert_eq!(witness["partial_chunk_entries"], count % CHUNK_ENTRIES);
            assert_eq!(
                witness["completed_million_entry_chunks"],
                count / CHUNK_ENTRIES
            );
            assert_eq!(witness["discontinuity_count"], discontinuities);
            assert_eq!(
                witness["discontinuity_sha256"],
                hex::encode(discon.clone().finalize())
            );
            assert_eq!(
                witness["tail_pcs"],
                json!((count.saturating_sub(TAIL_PCS as u64)..count).collect::<Vec<_>>())
            );
            for suffix in 0..7u64 {
                let record = synthetic_record(0xdead0000 + suffix);
                trace.entry(&record);
                full.update(record);
                chunk.update(record);
                if trace.entries.is_multiple_of(CHUNK_ENTRIES) {
                    chunk = Sha256::new();
                }
            }
            trace.discon(2, 0x420000, 0xdead0000);
            discon.update((count + 7).to_le_bytes());
            discon.update(2_i32.to_le_bytes());
            discon.update(0x420000u64.to_le_bytes());
            discon.update(0xdead0000u64.to_le_bytes());
            trace.mark_fence_prefix(); // first witness must remain frozen
            assert_eq!(trace.fence_prefix, witness);
            assert_eq!(trace.post_fence_entries(), Some(7));
            trace.flush_instructions();
            trace.flush_discontinuities();
            assert_eq!(trace.instructions.finalize(), full.finalize());
            assert_eq!(trace.chunk.finalize(), chunk.finalize());
            assert_eq!(trace.discontinuities.finalize(), discon.finalize());
        }
    }
    #[test]
    fn suffix_divergence_does_not_normalize_the_whole_history() {
        let mut a = Trace::new(Vec::new());
        let mut b = Trace::new(Vec::new());
        for pc in 0..100u64 {
            let record = synthetic_record(pc);
            a.entry(&record);
            b.entry(&record);
        }
        a.mark_fence_prefix();
        b.mark_fence_prefix();
        for suffix in 0..3u64 {
            a.entry(&synthetic_record(0xdead0000 + suffix));
        }
        for suffix in 0..10u64 {
            b.entry(&synthetic_record(0xdead0000 + suffix));
        }
        assert_eq!(a.fence_prefix, b.fence_prefix);
        assert_eq!(a.post_fence_entries(), Some(3));
        assert_eq!(b.post_fence_entries(), Some(10));
        a.flush_instructions();
        b.flush_instructions();
        assert_ne!(a.tail_pcs(), b.tail_pcs());
        assert_ne!(a.instructions.finalize(), b.instructions.finalize());
    }

    // A reference to the old per-entry updates verifies buffered canonical byte
    // ordering, partial buffers, exact chunk cuts, and discontinuity positions.
    #[test]
    fn buffered_hashes_match_unbuffered_oracle() {
        for count in [0_u64, 1, 4095, 4096, 4097, 999_999, 1_000_000, 1_000_001] {
            let mut trace = Trace::new(Vec::new());
            let mut full = Sha256::new();
            let mut chunk = Sha256::new();
            let mut chunks = Vec::new();
            let mut discontinuities = Sha256::new();
            let mut discon_count = 0;
            for index in 0..count {
                let mut record = [0_u8; RECORD_BYTES];
                record[..8].copy_from_slice(&index.to_le_bytes());
                record[8] = 3;
                record[9..12].copy_from_slice(&[0x48, 0x31, 0xc0]);
                trace.entry(&record);
                full.update(record);
                chunk.update(record);
                if (index + 1).is_multiple_of(CHUNK_ENTRIES) {
                    chunks.push(hex::encode(std::mem::take(&mut chunk).finalize()));
                }
                if index % 251 == 0 {
                    trace.discon(1, index, index + 1);
                    discontinuities.update((index + 1).to_le_bytes());
                    discontinuities.update(1_i32.to_le_bytes());
                    discontinuities.update(index.to_le_bytes());
                    discontinuities.update((index + 1).to_le_bytes());
                    discon_count += 1;
                }
            }
            trace.flush_instructions();
            trace.flush_discontinuities();
            assert_eq!(trace.entries, count);
            assert_eq!(trace.instructions.finalize(), full.finalize());
            assert_eq!(trace.chunk.finalize(), chunk.finalize());
            assert_eq!(trace.chunks, chunks);
            assert_eq!(trace.discontinuity_count, discon_count);
            assert_eq!(trace.discontinuities.finalize(), discontinuities.finalize());
        }
    }

    #[test]
    fn api7_native_layouts() {
        use std::mem::{offset_of, size_of};
        assert_eq!(size_of::<QemuInfo>(), 32);
        assert_eq!(offset_of!(QemuInfo, system_emulation), 16);
        assert_eq!(offset_of!(QemuInfo, initial_vcpus), 20);
        assert_eq!(size_of::<RegisterDescriptor>(), 32);
        assert_eq!(offset_of!(RegisterDescriptor, readonly), 24);
        assert_eq!(size_of::<GArray>(), 16);
        assert_eq!(size_of::<ByteArray>(), 16);
    }
}
