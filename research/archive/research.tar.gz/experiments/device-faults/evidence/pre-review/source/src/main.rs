//! Independent modeled devices and imperative scenario; no Linux or CPU fidelity.
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    cell::RefCell,
    collections::{BTreeMap, BTreeSet},
    future::Future,
    pin::Pin,
    rc::Rc,
    task::{Context, Poll, Waker},
    thread::{self, ThreadId},
};

type Shared = Rc<RefCell<World>>;
type ProbeResult<T> = Result<T, String>;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Endpoint {
    Scenario,
    Machine(u8),
}
#[derive(Clone, Copy, Debug)]
enum Scope {
    Machine(u8),
    Az(u8),
}
#[derive(Clone, Copy, Debug)]
enum Payload {
    Byte(u8),
    HealthRequest(u64),
    HealthReply(u64, bool, u64),
}
#[derive(Clone, Copy, Debug)]
struct Packet {
    id: u64,
    from: Endpoint,
    to: Endpoint,
    payload: Payload,
}
struct Rule {
    from: Scope,
    to: Scope,
    bidirectional: bool,
    drop_numerator: u64,
    drop_denominator: u64,
}
#[derive(Clone, Copy, Debug)]
enum Event {
    ScenarioWake,
    Wire(Packet),
    Dma {
        machine: u8,
        incarnation: u64,
        byte: u8,
    },
    Write {
        machine: u8,
        incarnation: u64,
        op: u64,
        byte: u8,
    },
    Flush {
        machine: u8,
        incarnation: u64,
        through: u64,
        reply: u64,
    },
    Timeout(u64),
}
struct Machine {
    az: u8,
    incarnation: u64,
    alive: bool,
    volatile: u8,
    durable: u8,
    next_op: u64,
    writes: BTreeMap<u64, u64>,
    received: Vec<(u64, u8)>,
    memory: u8,
}
#[derive(Clone, Copy, Default)]
struct Controls {
    ignore_overlap: bool,
    ignore_incarnation: bool,
    ignore_flush_barrier: bool,
    cancel_wire_on_crash: bool,
}
struct World {
    owner: ThreadId,
    seed: u64,
    now: u64,
    sequence: u64,
    next_id: u64,
    machines: BTreeMap<u8, Machine>,
    rules: BTreeMap<u64, Rule>,
    queue: BTreeMap<(u64, u64), Event>,
    replies: BTreeMap<u64, Value>,
    outstanding: BTreeSet<u64>,
    scenario_ready: bool,
    controls: Controls,
    stale_rejected: u64,
    dropped: u64,
    dropped_by_rule: BTreeMap<u64, u64>,
    delivered_ids: BTreeSet<u64>,
    trace: Vec<Value>,
}
impl World {
    fn new(seed: u64, controls: Controls) -> Shared {
        Rc::new(RefCell::new(Self {
            owner: thread::current().id(),
            seed,
            now: 0,
            sequence: 0,
            next_id: 0,
            machines: (1..=6)
                .map(|id| {
                    (
                        id,
                        Machine {
                            az: (id - 1) / 2 + 1,
                            incarnation: 1,
                            alive: true,
                            volatile: b'0',
                            durable: b'0',
                            next_op: 0,
                            writes: BTreeMap::new(),
                            received: Vec::new(),
                            memory: 0,
                        },
                    )
                })
                .collect(),
            rules: BTreeMap::new(),
            queue: BTreeMap::new(),
            replies: BTreeMap::new(),
            outstanding: BTreeSet::new(),
            scenario_ready: true,
            controls,
            stale_rejected: 0,
            dropped: 0,
            dropped_by_rule: BTreeMap::new(),
            delivered_ids: BTreeSet::new(),
            trace: Vec::new(),
        }))
    }
    fn emit(&mut self, event: &str, detail: Value) {
        assert_eq!(self.owner, thread::current().id());
        self.trace
            .push(json!({"time_ns":self.now,"event":event,"detail":detail}));
    }
    fn id(&mut self) -> u64 {
        self.next_id += 1;
        self.next_id
    }
    fn schedule(&mut self, deadline: u64, event: Event) {
        assert!(deadline >= self.now);
        self.sequence += 1;
        self.queue.insert((deadline, self.sequence), event);
    }
    fn random(&self, domain: &[u8], id: u64, context: u64) -> u64 {
        let mut h = Sha256::new();
        h.update(domain);
        h.update(self.seed.to_le_bytes());
        h.update(id.to_le_bytes());
        h.update(context.to_le_bytes());
        u64::from_le_bytes(h.finalize()[..8].try_into().unwrap())
    }
    fn matches(&self, scope: Scope, endpoint: Endpoint) -> bool {
        let Endpoint::Machine(id) = endpoint else {
            return false;
        };
        match scope {
            Scope::Machine(wanted) => id == wanted,
            Scope::Az(az) => self.machines[&id].az == az,
        }
    }
    fn applies(&self, rule: &Rule, packet: Packet) -> bool {
        (self.matches(rule.from, packet.from) && self.matches(rule.to, packet.to))
            || (rule.bidirectional
                && self.matches(rule.to, packet.from)
                && self.matches(rule.from, packet.to))
    }
    fn send(
        &mut self,
        from: Endpoint,
        to: Endpoint,
        payload: Payload,
        fixed_delay: Option<u64>,
    ) -> u64 {
        if let Endpoint::Machine(id) = from {
            assert!(self.machines[&id].alive);
        }
        let id = self.id();
        let delay = fixed_delay.unwrap_or_else(|| 2 + self.random(b"device:latency:v1", id, 0) % 3);
        assert!(delay > 0);
        self.schedule(
            self.now + delay,
            Event::Wire(Packet {
                id,
                from,
                to,
                payload,
            }),
        );
        self.emit(
            "send",
            json!({"packet":id,"from":format!("{from:?}"),"to":format!("{to:?}"),"delay_ns":delay}),
        );
        id
    }
    fn stale(&mut self, machine: u8, incarnation: u64, kind: &str) -> bool {
        let current = &self.machines[&machine];
        if !current.alive
            || (!self.controls.ignore_incarnation && current.incarnation != incarnation)
        {
            self.stale_rejected += 1;
            self.emit("obsolete_device_completion", json!({"machine":machine,"owner_incarnation":incarnation,"current_incarnation":current.incarnation,"kind":kind}));
            return true;
        }
        false
    }
    fn deliver(&mut self, event: Event) {
        match event {
            Event::ScenarioWake => self.scenario_ready = true,
            Event::Timeout(id) => {
                if self.outstanding.contains(&id) {
                    self.replies
                        .entry(id)
                        .or_insert_with(|| json!({"timeout":true}));
                    self.scenario_ready = true;
                }
            }
            Event::Wire(packet) => {
                let rule = self.rules.iter().find_map(|(&id, rule)| {
                    (self.applies(rule, packet)
                        && self.random(b"device:loss:v1", packet.id, id) % rule.drop_denominator
                            < rule.drop_numerator)
                        .then_some(id)
                });
                if let Some(rule) = rule {
                    self.dropped += 1;
                    *self.dropped_by_rule.entry(rule).or_default() += 1;
                    self.emit("packet_dropped", json!({"packet":packet.id,"rule":rule}));
                    return;
                }
                match packet.to {
                    Endpoint::Scenario => {
                        if let Payload::HealthReply(id, healthy, incarnation) = packet.payload
                            && self.outstanding.contains(&id)
                        {
                            self.replies
                                .insert(id, json!({"healthy":healthy,"incarnation":incarnation}));
                            self.scenario_ready = true;
                        }
                    }
                    Endpoint::Machine(id) => {
                        if !self.machines[&id].alive {
                            self.emit(
                                "packet_to_down_machine",
                                json!({"packet":packet.id,"machine":id}),
                            );
                            return;
                        }
                        // A world-owned wire packet resolves the current NIC at
                        // delivery, rather than inheriting an old boot epoch.
                        let m = self.machines.get_mut(&id).unwrap();
                        match packet.payload {
                            Payload::Byte(byte) => m.received.push((packet.id, byte)),
                            Payload::HealthRequest(request) => {
                                let healthy = m.volatile == b'D' && m.durable == b'D';
                                let incarnation = m.incarnation;
                                self.send(
                                    Endpoint::Machine(id),
                                    packet.from,
                                    Payload::HealthReply(request, healthy, incarnation),
                                    None,
                                );
                            }
                            Payload::HealthReply(..) => panic!("fixture protocol routing error"),
                        }
                    }
                }
                self.delivered_ids.insert(packet.id);
                self.emit(
                    "packet_delivered",
                    json!({"packet":packet.id,"to":format!("{:?}",packet.to)}),
                );
            }
            Event::Dma {
                machine,
                incarnation,
                byte,
            } => {
                if self.stale(machine, incarnation, "dma") {
                    return;
                }
                self.machines.get_mut(&machine).unwrap().memory = byte;
                self.emit(
                    "dma_completed",
                    json!({"machine":machine,"owner_incarnation":incarnation,"byte":byte}),
                );
            }
            Event::Write {
                machine,
                incarnation,
                op,
                byte,
            } => {
                if self.stale(machine, incarnation, "disk_write") {
                    return;
                }
                let m = self.machines.get_mut(&machine).unwrap();
                m.volatile = byte;
                m.writes.remove(&op);
                self.emit(
                    "disk_write_ack",
                    json!({"machine":machine,"op":op,"byte":byte,"durable":false}),
                );
            }
            Event::Flush {
                machine,
                incarnation,
                through,
                reply,
            } => {
                if self.stale(machine, incarnation, "disk_flush") {
                    self.replies.insert(reply, json!({"io_error":true}));
                    self.scenario_ready = true;
                    return;
                }
                let m = &self.machines[&machine];
                let waiting = m.writes.range(..=through).map(|(_, &due)| due).max();
                if !self.controls.ignore_flush_barrier
                    && let Some(due) = waiting
                {
                    self.schedule(self.now.max(due), event);
                    self.emit(
                        "flush_waits_for_prior_write",
                        json!({"machine":machine,"through_op":through,"until_ns":due}),
                    );
                    return;
                }
                let m = self.machines.get_mut(&machine).unwrap();
                m.durable = m.volatile;
                let byte = m.durable;
                self.replies
                    .insert(reply, json!({"flushed":true,"byte":byte}));
                self.scenario_ready = true;
                self.emit(
                    "flush_ack",
                    json!({"machine":machine,"through_op":through,"byte":byte}),
                );
            }
        }
    }
    fn advance(&mut self) -> bool {
        let Some((&(due, _), _)) = self.queue.first_key_value() else {
            return false;
        };
        let before = self.now;
        self.now = due;
        self.emit("idle_jump", json!({"from_ns":before,"to_ns":due}));
        // Guest services are instantaneous event handlers in this model. All
        // are blocked between events. Stable FIFO resolves equal timestamps.
        while self
            .queue
            .first_key_value()
            .is_some_and(|((at, _), _)| *at == self.now)
        {
            let (_, event) = self.queue.pop_first().unwrap();
            self.deliver(event);
        }
        true
    }
    fn report(&self, case: &str) -> Value {
        let machines: Vec<Value> = self.machines.iter().map(|(&id, m)| json!({
            "machine":id,"az":m.az,"incarnation":m.incarnation,"alive":m.alive,
            "volatile":m.volatile,"durable":m.durable,"memory":m.memory,"received":m.received,
        })).collect();
        json!({"case":case,"now_ns":self.now,"stale_rejected":self.stale_rejected,
            "dropped":self.dropped,"dropped_by_rule":self.dropped_by_rule,
            "machines":machines,"trace":self.trace})
    }
}

#[derive(Clone)]
struct Controller(Shared);
impl Controller {
    fn sleep(&self, delay: u64) -> Sleep {
        Sleep {
            world: self.0.clone(),
            deadline: self.0.borrow().now + delay,
            armed: false,
        }
    }
    fn fault(
        &self,
        from: Scope,
        to: Scope,
        bidirectional: bool,
        numerator: u64,
        denominator: u64,
    ) -> u64 {
        assert!(denominator > 0 && numerator <= denominator);
        let mut w = self.0.borrow_mut();
        let id = w.id();
        w.rules.insert(
            id,
            Rule {
                from,
                to,
                bidirectional,
                drop_numerator: numerator,
                drop_denominator: denominator,
            },
        );
        w.emit("fault_applied", json!({"handle":id,"from":format!("{from:?}"),"to":format!("{to:?}"),"bidirectional":bidirectional,"drop_fraction":[numerator,denominator]}));
        id
    }
    fn heal(&self, handle: u64) {
        let mut w = self.0.borrow_mut();
        assert!(w.rules.remove(&handle).is_some());
        if w.controls.ignore_overlap {
            w.rules.clear();
        }
        let remaining: Vec<u64> = w.rules.keys().copied().collect();
        w.emit(
            "fault_healed",
            json!({"handle":handle,"remaining_handles":remaining}),
        );
    }
    fn send(&self, from: u8, to: u8, byte: u8, delay: Option<u64>) -> u64 {
        self.0.borrow_mut().send(
            Endpoint::Machine(from),
            Endpoint::Machine(to),
            Payload::Byte(byte),
            delay,
        )
    }
    fn crash(&self, machine: u8) {
        let mut w = self.0.borrow_mut();
        let m = w.machines.get_mut(&machine).unwrap();
        assert!(m.alive);
        m.alive = false;
        m.volatile = m.durable;
        m.writes.clear();
        m.memory = 0;
        if w.controls.cancel_wire_on_crash {
            w.queue.retain(|_, event| !matches!(event, Event::Wire(packet) if packet.from == Endpoint::Machine(machine) || packet.to == Endpoint::Machine(machine)));
        }
        w.emit("crash", json!({"machine":machine}));
    }
    fn reboot(&self, machine: u8) {
        let mut w = self.0.borrow_mut();
        let m = w.machines.get_mut(&machine).unwrap();
        assert!(!m.alive);
        m.incarnation += 1;
        m.alive = true;
        m.next_op = 0;
        m.received.clear();
        let incarnation = m.incarnation;
        w.emit(
            "reboot",
            json!({"machine":machine,"incarnation":incarnation}),
        );
    }
    fn dma(&self, machine: u8, byte: u8, delay: u64) {
        let mut w = self.0.borrow_mut();
        let incarnation = w.machines[&machine].incarnation;
        let due = w.now + delay;
        w.schedule(
            due,
            Event::Dma {
                machine,
                incarnation,
                byte,
            },
        );
    }
    fn write(&self, machine: u8, byte: u8, delay: u64) {
        assert!(delay > 0);
        let mut w = self.0.borrow_mut();
        let due = w.now + delay;
        let m = w.machines.get_mut(&machine).unwrap();
        assert!(m.alive);
        m.next_op += 1;
        let op = m.next_op;
        let incarnation = m.incarnation;
        m.writes.insert(op, due);
        w.schedule(
            due,
            Event::Write {
                machine,
                incarnation,
                op,
                byte,
            },
        );
        w.emit(
            "disk_write_submitted",
            json!({"machine":machine,"op":op,"byte":byte,"due_ns":due}),
        );
    }
    fn flush(&self, machine: u8, delay: u64) -> Response {
        assert!(delay > 0);
        let mut w = self.0.borrow_mut();
        let reply = w.id();
        w.outstanding.insert(reply);
        let due = w.now + delay;
        let m = &w.machines[&machine];
        assert!(m.alive);
        let event = Event::Flush {
            machine,
            incarnation: m.incarnation,
            through: m.next_op,
            reply,
        };
        w.schedule(due, event);
        Response {
            world: self.0.clone(),
            id: reply,
        }
    }
    fn health(&self, machine: u8) -> Response {
        let mut w = self.0.borrow_mut();
        let id = w.id();
        w.outstanding.insert(id);
        w.send(
            Endpoint::Scenario,
            Endpoint::Machine(machine),
            Payload::HealthRequest(id),
            None,
        );
        let deadline = w.now + 12;
        w.schedule(deadline, Event::Timeout(id));
        Response {
            world: self.0.clone(),
            id,
        }
    }
    fn delivered(&self, packet: u64) -> bool {
        self.0.borrow().delivered_ids.contains(&packet)
    }
    fn volatile(&self, machine: u8) -> u8 {
        self.0.borrow().machines[&machine].volatile
    }
    fn memory(&self, machine: u8) -> u8 {
        self.0.borrow().machines[&machine].memory
    }
    fn stale_count(&self) -> u64 {
        self.0.borrow().stale_rejected
    }
    fn received(&self, machine: u8, packet: u64, byte: u8) -> bool {
        self.0.borrow().machines[&machine]
            .received
            .iter()
            .any(|&(id, value)| id == packet && value == byte)
    }
    fn check(&self, condition: bool, message: &str) -> ProbeResult<()> {
        if condition {
            self.0
                .borrow_mut()
                .emit("scenario_assertion", json!({"assertion":message}));
            Ok(())
        } else {
            Err(message.into())
        }
    }
}
struct Sleep {
    world: Shared,
    deadline: u64,
    armed: bool,
}
impl Future for Sleep {
    type Output = ();
    fn poll(mut self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<()> {
        if self.world.borrow().now >= self.deadline {
            return Poll::Ready(());
        }
        if !self.armed {
            self.world
                .borrow_mut()
                .schedule(self.deadline, Event::ScenarioWake);
            self.armed = true;
        }
        Poll::Pending
    }
}
struct Response {
    world: Shared,
    id: u64,
}
impl Future for Response {
    type Output = Value;
    fn poll(self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<Value> {
        let mut w = self.world.borrow_mut();
        if let Some(value) = w.replies.remove(&self.id) {
            assert!(w.outstanding.remove(&self.id));
            Poll::Ready(value)
        } else {
            Poll::Pending
        }
    }
}
fn execute(
    seed: u64,
    controls: Controls,
    case: &'static str,
    make: impl FnOnce(Controller) -> Pin<Box<dyn Future<Output = ProbeResult<()>>>>,
) -> ProbeResult<Value> {
    let world = World::new(seed, controls);
    let mut scenario = make(Controller(world.clone()));
    let mut cx = Context::from_waker(Waker::noop());
    for _ in 0..10000 {
        if world.borrow().scenario_ready {
            world.borrow_mut().scenario_ready = false;
            match scenario.as_mut().poll(&mut cx) {
                Poll::Ready(result) => {
                    result?;
                    return Ok(world.borrow().report(case));
                }
                Poll::Pending => {}
            }
        }
        if !world.borrow_mut().advance() {
            return Err("scenario_deadlocked_without_event".into());
        }
    }
    Err("probe_event_budget_exhausted".into())
}
fn links(seed: u64, controls: Controls) -> ProbeResult<Value> {
    execute(seed, controls, "directed_az_and_overlapping_faults", |c| {
        Box::pin(async move {
            c.sleep(60).await;
            let az = c.fault(Scope::Az(2), Scope::Az(1), false, 1, 1);
            let partial = c.fault(Scope::Az(3), Scope::Az(1), false, 1, 2);
            let overlap = c.fault(Scope::Machine(3), Scope::Machine(1), false, 1, 1);
            let blocked = c.send(4, 2, 1, None);
            let reverse = c.send(2, 4, 2, None);
            let samples: Vec<u64> = (0..32).map(|byte| c.send(5, 1, byte, None)).collect();
            c.sleep(5).await;
            c.check(
                !c.delivered(blocked) && c.delivered(reverse),
                "az_partition_preserves_reverse_direction",
            )?;
            let delivered = samples.iter().filter(|&&id| c.delivered(id)).count();
            c.check(
                delivered > 0 && delivered < samples.len(),
                "partial_az_fault_has_deliveries_and_drops",
            )?;
            c.sleep(25).await;
            c.heal(az);
            let still_blocked = c.send(3, 1, 3, None);
            let now_allowed = c.send(4, 2, 4, None);
            c.sleep(5).await;
            c.check(
                !c.delivered(still_blocked) && c.delivered(now_allowed),
                "healing_one_handle_preserves_overlap",
            )?;
            c.heal(overlap);
            c.heal(partial);
            let healed = c.send(3, 1, 5, None);
            c.sleep(5).await;
            c.check(c.delivered(healed), "healed_link_recovers")?;
            // Delivery-time rule evaluation is part of this pinned model contract.
            let inflight = c.send(1, 2, 6, Some(5));
            let both = c.fault(Scope::Machine(1), Scope::Machine(2), true, 1, 1);
            let reverse = c.send(2, 1, 7, None);
            c.sleep(5).await;
            c.check(
                !c.delivered(inflight) && !c.delivered(reverse),
                "bidirectional_fault_applies_to_inflight_delivery",
            )?;
            c.heal(both);
            Ok(())
        })
    })
}
fn storage(seed: u64, controls: Controls) -> ProbeResult<Value> {
    execute(seed, controls, "flush_order_and_crash_recovery", |c| {
        Box::pin(async move {
            c.write(1, b'D', 12);
            let flush = c.flush(1, 1).await;
            c.check(flush["flushed"] == true, "flush_completes")?;
            c.write(1, b'V', 1);
            c.sleep(2).await;
            c.check(c.volatile(1) == b'V', "unflushed_write_ack_is_exercised")?;
            c.write(1, b'X', 20);
            c.crash(1);
            c.sleep(2).await;
            c.reboot(1);
            let health = c.health(1).await;
            c.check(
                health["healthy"] == true && health["incarnation"] == 2,
                "reboot_recovers_flushed_data_and_discards_volatile_write",
            )?;
            c.sleep(25).await;
            c.check(
                c.volatile(1) == b'D',
                "old_disk_completion_cannot_change_rebooted_cache",
            )?;
            c.check(c.stale_count() == 1, "old_disk_completion_is_rejected")?;
            Ok(())
        })
    })
}
fn dma(seed: u64, controls: Controls) -> ProbeResult<Value> {
    execute(seed, controls, "device_completion_ownership", |c| {
        Box::pin(async move {
            c.dma(1, b'X', 10);
            c.sleep(1).await;
            c.crash(1);
            c.sleep(1).await;
            c.reboot(1);
            c.dma(1, b'N', 2);
            c.sleep(10).await;
            c.check(
                c.memory(1) == b'N',
                "old_dma_cannot_overwrite_new_incarnation_memory",
            )?;
            c.check(c.stale_count() == 1, "old_dma_is_rejected")?;
            Ok(())
        })
    })
}
fn wire(seed: u64, controls: Controls) -> ProbeResult<Value> {
    execute(seed, controls, "wire_lifetime_and_scenario_immunity", |c| {
        Box::pin(async move {
            let packet = c.send(1, 2, b'W', Some(20));
            c.sleep(1).await;
            for id in 1..=6 {
                c.crash(id);
            }
            let health = c.health(2).await;
            c.check(
                health["timeout"] == true,
                "scenario_runs_and_queries_while_every_machine_is_down",
            )?;
            for id in 1..=6 {
                c.reboot(id);
            }
            c.sleep(10).await;
            c.check(
                c.delivered(packet),
                "old_wire_packet_can_reach_rebooted_address",
            )?;
            c.check(
                c.received(2, packet, b'W'),
                "rebooted_service_actually_receives_old_wire_payload",
            )?;
            Ok(())
        })
    })
}
fn suite(seed: u64) -> Value {
    let positive = Controls::default();
    let cases = vec![
        links(seed, positive).unwrap(),
        storage(seed, positive).unwrap(),
        dma(seed, positive).unwrap(),
        wire(seed, positive).unwrap(),
    ];
    let controls = json!({
        "erase_overlapping_fault":links(seed, Controls { ignore_overlap:true, ..positive }).unwrap_err(),
        "early_flush_ack":storage(seed, Controls { ignore_flush_barrier:true, ..positive }).unwrap_err(),
        "stale_disk_completion":storage(seed, Controls { ignore_incarnation:true, ..positive }).unwrap_err(),
        "stale_dma":dma(seed, Controls { ignore_incarnation:true, ..positive }).unwrap_err(),
        "discard_wire_on_crash":wire(seed, Controls { cancel_wire_on_crash:true, ..positive }).unwrap_err(),
    });
    json!({"schema":1,"seed":seed,"scope":"synthetic event services and devices; no Linux/CPU/NIC/filesystem conformance",
        "inputs":{"source_sha256":format!("{:x}",Sha256::digest(include_bytes!("main.rs"))),
            "time_unit":"nanosecond","event_order":"deadline_then_registration_sequence",
            "link_latency_ns":[2,4],"loss_evaluation":"delivery_time","disk":"one_byte_writeback_cache_and_ordered_flush"},
        "cases":cases,"negative_controls":controls})
}
fn main() {
    let seed = std::env::args()
        .nth(1)
        .map(|s| s.parse().expect("decimal u64 seed"))
        .unwrap_or(42);
    println!("{}", serde_json::to_string(&suite(seed)).unwrap());
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn directed_partial_and_overlapping_faults() {
        links(42, Controls::default()).unwrap();
        assert_eq!(
            links(
                42,
                Controls {
                    ignore_overlap: true,
                    ..Controls::default()
                }
            )
            .unwrap_err(),
            "healing_one_handle_preserves_overlap"
        );
    }
    #[test]
    fn flush_completion_cannot_overtake_older_write() {
        storage(42, Controls::default()).unwrap();
        assert_eq!(
            storage(
                42,
                Controls {
                    ignore_flush_barrier: true,
                    ..Controls::default()
                }
            )
            .unwrap_err(),
            "reboot_recovers_flushed_data_and_discards_volatile_write"
        );
    }
    #[test]
    fn pending_disk_write_cannot_attach_to_rebooted_device() {
        assert_eq!(
            storage(
                42,
                Controls {
                    ignore_incarnation: true,
                    ..Controls::default()
                }
            )
            .unwrap_err(),
            "old_disk_completion_cannot_change_rebooted_cache"
        );
    }
    #[test]
    fn pending_dma_cannot_attach_to_rebooted_memory() {
        dma(42, Controls::default()).unwrap();
        assert_eq!(
            dma(
                42,
                Controls {
                    ignore_incarnation: true,
                    ..Controls::default()
                }
            )
            .unwrap_err(),
            "old_dma_cannot_overwrite_new_incarnation_memory"
        );
    }
    #[test]
    fn wire_ownership_differs_from_device_callback_ownership() {
        wire(42, Controls::default()).unwrap();
        assert_eq!(
            wire(
                42,
                Controls {
                    cancel_wire_on_crash: true,
                    ..Controls::default()
                }
            )
            .unwrap_err(),
            "old_wire_packet_can_reach_rebooted_address"
        );
    }
    #[test]
    fn seed_controls_partial_loss_not_only_report_metadata() {
        let a = links(42, Controls::default()).unwrap();
        let b = links(43, Controls::default()).unwrap();
        assert_ne!(a["machines"][0]["received"], b["machines"][0]["received"]);
        assert_eq!(suite(42), suite(42));
    }
}
