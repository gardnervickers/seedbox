#!/bin/sh
set -eu
platform_dir=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
work_root=$1
label=$2
patch_input=$3
case "$label" in ''|*[!a-zA-Z0-9_-]*) echo 'label must contain letters/digits/_/-' >&2; exit 2;; esac
: "${SEEDBOX_LINUX_SOURCE:?run through linux-platform/shell.nix}"
: "${SEEDBOX_LINUX_VERSION:?}"
source_base="$work_root/source/linux-$SEEDBOX_LINUX_VERSION"
build_root="$work_root/build-$label"
mkdir -p "$work_root/source" "$build_root" "$work_root/ccache"
# Shared source is immutable after extraction. Serialize only its creation.
if mkdir "$work_root/source.lock" 2>/dev/null; then
  trap 'rmdir "$work_root/source.lock" 2>/dev/null || true' EXIT HUP INT TERM
  if [ ! -d "$source_base" ]; then tar -C "$work_root/source" -xf "$SEEDBOX_LINUX_SOURCE"; fi
  rmdir "$work_root/source.lock"
  trap - EXIT HUP INT TERM
else
  while [ -d "$work_root/source.lock" ]; do sleep 1; done
fi
test -f "$source_base/Makefile"
if [ -e "$build_root/src" ]; then echo "refusing existing build source $build_root/src" >&2; exit 2; fi
cp -a --reflink=auto "$source_base" "$build_root/src"
if [ "$patch_input" != "-" ]; then patch -d "$build_root/src" -p1 < "$patch_input"; fi
mkdir -p "$build_root/out"
export CCACHE_DIR="$work_root/ccache" CCACHE_MAXSIZE=2G CCACHE_BASEDIR="$work_root"
export KBUILD_BUILD_USER=seedbox KBUILD_BUILD_HOST=probe KBUILD_BUILD_VERSION=1
export KBUILD_BUILD_TIMESTAMP='Thu Jan 1 00:00:00 UTC 1970' SOURCE_DATE_EPOCH=0
make -C "$build_root/src" O="$build_root/out" ARCH=x86_64 CC='ccache gcc' allnoconfig
while read -r state option; do
  case "$state" in y) "$build_root/src/scripts/config" --file "$build_root/out/.config" --enable "$option";;
    n) "$build_root/src/scripts/config" --file "$build_root/out/.config" --disable "$option";; esac
done < "$platform_dir/config.options"
if [ "$#" -ge 4 ]; then cat "$4" >> "$build_root/out/.config"; fi
make -C "$build_root/src" O="$build_root/out" ARCH=x86_64 CC='ccache gcc' olddefconfig
cp "$build_root/out/.config" "$build_root/config"
{
  printf 'nixpkgs_revision=%s\nlinux_version=%s\nsource=%s\n' "$SEEDBOX_NIXPKGS_REVISION" "$SEEDBOX_LINUX_VERSION" "$SEEDBOX_LINUX_SOURCE"
  gcc --version | head -1
  qemu-system-x86_64 --version | head -1
  sha256sum "$SEEDBOX_LINUX_SOURCE" "$platform_dir/config.options" "$build_root/config"
  if [ "$patch_input" != "-" ]; then sha256sum "$patch_input"; fi
} > "$build_root/inputs.txt"
make -C "$build_root/src" O="$build_root/out" ARCH=x86_64 CC='ccache gcc' -j8 bzImage
cp "$build_root/out/arch/x86/boot/bzImage" "$build_root/bzImage"
sha256sum "$build_root/bzImage" "$build_root/out/vmlinux" >> "$build_root/inputs.txt"
printf '%s\n' "$build_root/bzImage"
