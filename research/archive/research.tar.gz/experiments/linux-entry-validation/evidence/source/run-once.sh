#!/bin/sh
set -eu
# Run inside the copied pinned linux-platform shell. This boots one positive case.
probe_dir=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
kernel=$1
initrd=$2
results=$3
actual=$(sha256sum "$initrd" | cut -d ' ' -f1)
test "$actual" = cb83dfde0d91993c5ec7448e4af6f35eafd875f703742cb35f32a5497205ce47
rustc --edition=2024 -O "$probe_dir/runner.rs" -o "$probe_dir/runner"
qemu=$(command -v qemu-system-x86_64)
"$probe_dir/runner" "$qemu" "$kernel" "$initrd" "$results"
{ uname -a; rustc --version; qemu-system-x86_64 --version; } > "$results/host.txt"
cat /proc/cpuinfo > "$results/cpu.txt"
sha256sum "$probe_dir/runner-original.rs" "$probe_dir/runner.rs" "$probe_dir/runner" "$probe_dir/run-once.sh" "$kernel" "$initrd" > "$results/runtime-inputs.sha256"
