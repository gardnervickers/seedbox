use std::{env, fs, path::{Path, PathBuf}, process::{Command, Stdio}, thread, time::{Duration, Instant}};

fn run(qemu: &str, kernel: &Path, initrd: &Path, root: &Path, name: &str, negative: bool) {
    let dir = root.join(name);
    fs::create_dir(&dir).expect("fresh output directory");
    let serial = dir.join("serial.txt");
    let phases = dir.join("phases.bin");
    let args = vec![
        "-machine".to_owned(), "pc,accel=kvm".to_owned(), "-cpu".to_owned(), "qemu64".to_owned(),
        "-smp".to_owned(), "1".to_owned(), "-m".to_owned(), "128M".to_owned(),
        "-nodefaults".to_owned(), "-display".to_owned(), "none".to_owned(), "-no-reboot".to_owned(),
        "-kernel".to_owned(), kernel.display().to_string(), "-initrd".to_owned(), initrd.display().to_string(),
        "-append".to_owned(), "console=ttyS0 rdinit=/init nokaslr randomize_kstack_offset=off panic=-1".to_owned(),
        "-rtc".to_owned(), "base=2024-01-01T00:00:00,clock=vm".to_owned(),
        "-serial".to_owned(), format!("file:{}", serial.display()),
        "-debugcon".to_owned(), format!("file:{}", phases.display()),
        "-global".to_owned(), "isa-debugcon.iobase=0xe9".to_owned(),
        "-device".to_owned(), "isa-debug-exit,iobase=0xf4,iosize=4".to_owned(),
    ];
    fs::write(dir.join("args.txt"), format!("qemu={qemu}\n{args:#?}\n")).unwrap();
    let stderr = fs::File::create(dir.join("stderr.txt")).unwrap();
    let mut child = Command::new(qemu).args(&args).stdin(Stdio::null()).stdout(Stdio::null()).stderr(stderr).spawn().unwrap();
    let start = Instant::now();
    let mut max_threads = 0;
    let status = loop {
        if let Ok(tasks) = fs::read_dir(format!("/proc/{}/task", child.id())) {
            max_threads = max_threads.max(tasks.count());
        }
        if let Some(status) = child.try_wait().unwrap() { break status; }
        if start.elapsed() > Duration::from_secs(30) {
            child.kill().unwrap(); child.wait().unwrap();
            panic!("{name}: infrastructure resource deadline; no simulated timeout");
        }
        thread::sleep(Duration::from_millis(10));
    };
    fs::write(dir.join("host-threads.txt"), format!("max_observed_qemu_threads={max_threads}\nfunctional_only_not_D001=true\n")).unwrap();
    let serial = fs::read_to_string(serial).unwrap();
    let phases = fs::read(phases).unwrap();
    let mut counts = [0usize; 8];
    for byte in &phases { if (b'A'..=b'H').contains(byte) { counts[(byte-b'A') as usize] += 1; } }
    let required = [
        "OBS pipe PASS bytes=1 shared=0x51 child=0",
        "OBS signal restart=0 PASS first=-1 errno=4 handled=1 bytes=1",
        "OBS signal restart=1 PASS first=1 errno=0 handled=1 bytes=1",
        "OBS sqpoll worker=1 PASS status=1 consumed=8",
        "OBS sqpoll worker=0 PASS status=3 consumed=0",
        "OBS PASS linux-yield-hooks",
    ];
    assert_eq!(status.code(), Some(33), "{name}: wrong final exit, serial={serial}");
    for line in required { assert!(serial.contains(line), "{name}: missing ABI observation {line}; serial={serial}"); }
    assert!(!serial.contains("OBS FAIL") && !serial.contains("BUG:") && !serial.contains("WARNING:"), "{name}: guest/kernel failure");
    assert_eq!(phases.iter().filter(|byte| **byte == b'+').count(), 1, "final guest marker");
    for index in [0,1,2,4,5,7] { assert!(counts[index] > 0, "{name}: required phase {} absent; counts={counts:?}", (b'A'+index as u8) as char); }
    if negative {
        assert_eq!(counts[6], 0, "omitted-loop control unexpectedly has G");
    } else {
        assert!(counts[6] >= 2, "actual repeated SQPOLL-loop intervention absent");
    }
    let verdict = if negative { "PASS negative: normal coverage oracle rejects missing G while H and ABI pass" } else { "PASS functional phase reachability and ABI only" };
    fs::write(dir.join("report.txt"), format!("{verdict}\nqemu_exit=33\nphase_counts_A_to_H={counts:?}\nphase_capture_bytes={}\nmax_qemu_threads={max_threads}\n", phases.len())).unwrap();
    println!("{name}: {verdict}; phases={counts:?}; max_qemu_threads={max_threads}");
}
fn main() {
    let args: Vec<String> = env::args().collect();
    assert_eq!(args.len(), 5, "runner QEMU VALIDATION_KERNEL INITRAMFS NEW_RESULTS_DIR");
    let root = PathBuf::from(&args[4]);
    fs::create_dir(&root).expect("new results root required");
    run(&args[1], Path::new(&args[2]), Path::new(&args[3]), &root, "positive-entry-validation", false);
}
