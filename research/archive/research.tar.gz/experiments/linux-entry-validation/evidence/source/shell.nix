{ pkgs ? (builtins.getFlake "github:NixOS/nixpkgs/8c6b39505383e6d5dcb431f00cb3597b71f8045c").legacyPackages.x86_64-linux }:
pkgs.mkShell {
  packages = with pkgs; [ stdenv.cc gnumake binutils bison flex bc perl python3 pkg-config openssl elfutils ccache cpio gzip xz patch coreutils qemu nasm lld rustc cargo rustfmt clippy ];
  SEEDBOX_LINUX_SOURCE = pkgs.linux_6_12.src;
  SEEDBOX_LINUX_VERSION = pkgs.linux_6_12.version;
  SEEDBOX_NIXPKGS_REVISION = "8c6b39505383e6d5dcb431f00cb3597b71f8045c";
}
