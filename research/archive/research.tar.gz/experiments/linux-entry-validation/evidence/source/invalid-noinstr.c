/* Deliberately invalid checker-liveness witness; never linked into the kernel. */
__attribute__((noinline)) void ordinary_instrumentable(void) { __asm__ volatile("nop"); }
__attribute__((noinline, section(".noinstr.text"))) void forbidden_entry_call(void) {
    ordinary_instrumentable();
    __asm__ volatile("nop");
}
