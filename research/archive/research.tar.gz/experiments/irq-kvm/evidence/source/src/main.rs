use sha2::{Digest, Sha256};
pub(crate) const GUEST: &[u8] = include_bytes!(concat!(env!("OUT_DIR"), "/guest.bin"));
pub(crate) const ORG: u64 = 0x8000;
pub(crate) fn word(bytes: &[u8], at: usize) -> u64 {
    u64::from_le_bytes(bytes[at..at + 8].try_into().expect("fixture word"))
}
pub(crate) fn fixture_table() -> [u64; 5] {
    assert_eq!(word(GUEST, 8), 0x5345454449525131);
    std::array::from_fn(|i| word(GUEST, 16 + i * 8))
}
pub(crate) fn hash(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
mod linux;
fn main() {
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    if let Err(e) = linux::run() {
        eprintln!("HARDWARE_GATE_FAILED: {e}");
        std::process::exit(1);
    }
    #[cfg(not(all(target_os = "linux", target_arch = "x86_64")))]
    {
        let _ = (fixture_table(), hash(GUEST), ORG);
        eprintln!("UNSUPPORTED_HOST: x86_64 Linux KVM required");
        std::process::exit(42);
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn sti_shadow_manifest_is_exact() {
        let t = fixture_table();
        let pc = (t[4] - ORG) as usize;
        // The protected instruction is a single MOV imm32->qword, following STI.
        assert_eq!(&GUEST[pc - 13..pc - 11], &[0xfb, 0x48]);
        assert_eq!(&GUEST[pc..pc + 4], &[0x48, 0xc7, 0x04, 0x25]);
    }
}
