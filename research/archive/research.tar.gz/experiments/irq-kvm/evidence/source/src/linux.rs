use crate::{GUEST, ORG, fixture_table, hash, word};
use kvm_bindings::{KVM_MAX_CPUID_ENTRIES, kvm_regs, kvm_segment, kvm_userspace_memory_region};
use kvm_ioctls::{Cap, Kvm, VcpuExit, VcpuFd, VmFd};
use serde_json::{Value, json};
use std::{
    fmt::Display,
    marker::PhantomData,
    rc::Rc,
    thread::{self, ThreadId},
};

type Result<T> = std::result::Result<T, String>;
const SIZE: usize = 0x40000;
const PORT: u16 = 0x504;
fn checked<T, E: Display>(r: std::result::Result<T, E>, context: &str) -> Result<T> {
    r.map_err(|e| format!("{context}: {e}"))
}
fn require(c: bool, message: impl Into<String>) -> Result<()> {
    if c { Ok(()) } else { Err(message.into()) }
}
#[derive(Clone)]
struct Owner {
    thread: ThreadId,
    tid: libc::pid_t,
    _not_send: PhantomData<Rc<()>>,
}
impl Owner {
    fn new() -> Self {
        Self {
            thread: thread::current().id(),
            tid: unsafe { libc::syscall(libc::SYS_gettid) as libc::pid_t },
            _not_send: PhantomData,
        }
    }
    fn check(&self) {
        assert_eq!(self.thread, thread::current().id());
        assert_eq!(self.tid, unsafe {
            libc::syscall(libc::SYS_gettid) as libc::pid_t
        });
    }
}
struct Memory {
    pointer: *mut u8,
    owner: Owner,
}
impl Memory {
    fn new(owner: &Owner) -> Result<Self> {
        owner.check();
        let p = unsafe {
            libc::mmap(
                std::ptr::null_mut(),
                SIZE,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_PRIVATE | libc::MAP_ANONYMOUS,
                -1,
                0,
            )
        };
        require(
            p != libc::MAP_FAILED,
            format!("mmap: {}", std::io::Error::last_os_error()),
        )?;
        Ok(Self {
            pointer: p.cast(),
            owner: owner.clone(),
        })
    }
    fn bytes(&self) -> &[u8] {
        self.owner.check();
        unsafe { std::slice::from_raw_parts(self.pointer, SIZE) }
    }
    fn write(&mut self, at: usize, bytes: &[u8]) {
        self.owner.check();
        assert!(at + bytes.len() <= SIZE);
        unsafe { std::ptr::copy_nonoverlapping(bytes.as_ptr(), self.pointer.add(at), bytes.len()) };
    }
    fn put(&mut self, at: usize, v: u64) {
        self.write(at, &v.to_le_bytes());
    }
    fn get(&self, at: usize) -> u64 {
        word(self.bytes(), at)
    }
}
impl Drop for Memory {
    fn drop(&mut self) {
        self.owner.check();
        assert_eq!(unsafe { libc::munmap(self.pointer.cast(), SIZE) }, 0);
    }
}
#[derive(Clone, Copy)]
enum Variant {
    Positive,
    EarlyForced,
}
struct Machine {
    vcpu: VcpuFd,
    _vm: VmFd,
    memory: Memory,
    owner: Owner,
}
fn segment(selector: u16, code: bool, user: bool) -> kvm_segment {
    kvm_segment {
        base: 0,
        limit: u32::MAX,
        selector,
        type_: if code { 11 } else { 3 },
        present: 1,
        dpl: if user { 3 } else { 0 },
        db: if code { 0 } else { 1 },
        s: 1,
        l: u8::from(code),
        g: 1,
        avl: 0,
        unusable: 0,
        padding: 0,
    }
}
fn gate(handler: u64, dpl: u8) -> [u8; 16] {
    let mut bytes = [0u8; 16];
    bytes[..2].copy_from_slice(&(handler as u16).to_le_bytes());
    bytes[2..4].copy_from_slice(&8u16.to_le_bytes());
    bytes[5] = 0x8e | (dpl << 5);
    bytes[6..8].copy_from_slice(&((handler >> 16) as u16).to_le_bytes());
    bytes[8..12].copy_from_slice(&((handler >> 32) as u32).to_le_bytes());
    bytes
}
impl Machine {
    fn new(kvm: &Kvm, owner: &Owner, _variant: Variant, seed: u64) -> Result<Self> {
        owner.check();
        let mut memory = Memory::new(owner)?;
        memory.write(ORG as usize, GUEST);
        memory.put(0x1000, 0x2007);
        memory.put(0x2000, 0x3007);
        memory.put(0x3000, 0x87);
        // Flat code/data plus 64-bit TSS. All pages user-mapped: trusted bare
        // fixture, no kernel/user memory-protection or security claim.
        for (i, v) in [
            0,
            0x00af9b000000ffff,
            0x00cf93000000ffff,
            0x00affb000000ffff,
            0x00cff3000000ffff,
            0x0000890060000067,
            0,
        ]
        .into_iter()
        .enumerate()
        {
            memory.put(0x5000 + i * 8, v);
        }
        memory.put(0x6004, 0x1f000); // unaligned TSS.RSP0
        memory.write(0x6066, &104u16.to_le_bytes()); // no IO bitmap within limit
        memory.write(0x7000 + 64 * 16, &gate(0x9000, 0));
        memory.put(0x4030, seed);
        let vm = checked(kvm.create_vm(), "create VM")?;
        unsafe {
            checked(
                vm.set_user_memory_region(kvm_userspace_memory_region {
                    slot: 0,
                    flags: 0,
                    guest_phys_addr: 0,
                    memory_size: SIZE as u64,
                    userspace_addr: memory.pointer as u64,
                }),
                "register memory",
            )?
        };
        let vcpu = checked(vm.create_vcpu(0), "create vCPU")?;
        let cpuid = checked(
            kvm.get_supported_cpuid(KVM_MAX_CPUID_ENTRIES),
            "supported CPUID",
        )?;
        checked(vcpu.set_cpuid2(&cpuid), "set CPUID")?;
        let mut s = checked(vcpu.get_sregs(), "get sregs")?;
        s.cs = segment(8, true, false);
        s.ds = segment(0x10, false, false);
        s.es = s.ds;
        s.ss = s.ds;
        s.fs = s.ds;
        s.gs = s.ds;
        s.gdt.base = 0x5000;
        s.gdt.limit = 55;
        s.idt.base = 0x7000;
        s.idt.limit = 4095;
        s.tr = kvm_segment {
            base: 0x6000,
            limit: 103,
            selector: 0x28,
            type_: 9,
            present: 1,
            dpl: 0,
            db: 0,
            s: 0,
            l: 0,
            g: 0,
            avl: 0,
            unusable: 0,
            padding: 0,
        };
        s.cr0 = 0x80010033; // PG,WP,NE,ET,MP,PE
        s.cr3 = 0x1000;
        s.cr4 = 1 << 5;
        s.efer = (1 << 8) | (1 << 10); // LME,LMA
        checked(vcpu.set_sregs(&s), "set long-mode sregs")?;
        checked(
            vcpu.set_regs(&kvm_regs {
                rip: ORG + 0x80,
                rsp: 0x1f000,
                rflags: 2,
                ..Default::default()
            }),
            "set regs",
        )?;
        Ok(Self {
            vcpu,
            _vm: vm,
            memory,
            owner: owner.clone(),
        })
    }
    fn exit(&mut self) -> Result<u32> {
        self.owner.check();
        self.vcpu.set_kvm_immediate_exit(0);
        loop {
            match self.vcpu.run() {
                Ok(VcpuExit::IoOut(port, data)) => {
                    require(
                        port == PORT && data.len() == 4,
                        format!("unexpected IO port={port:#x} bytes={}", data.len()),
                    )?;
                    let tag = u32::from_le_bytes(data.try_into().unwrap());
                    self.vcpu.set_kvm_immediate_exit(1);
                    let complete = self.vcpu.run();
                    require(
                        matches!(&complete,Err(e) if e.errno()==libc::EINTR),
                        format!("completion-only reentry: {complete:?}"),
                    )?;
                    self.vcpu.set_kvm_immediate_exit(0);
                    let regs = checked(self.vcpu.get_regs(), "completed regs")?;
                    let table = fixture_table();
                    let expected = match tag {
                        0 => table[0],
                        0x40 => table[1],
                        2 => table[2],
                        _ => return Err(format!("unknown tag {tag:#x}")),
                    };
                    require(
                        regs.rip == expected,
                        format!("PIO completion RIP {:#x}!={expected:#x}", regs.rip),
                    )?;
                    return Ok(tag);
                }
                Err(e) if e.errno() == libc::EINTR => continue,
                other => return Err(format!("unexpected KVM exit {other:?}")),
            }
        }
    }
    fn snapshot(&self) -> Result<Value> {
        self.owner.check();
        let r = checked(self.vcpu.get_regs(), "snapshot regs")?;
        let mut bytes = Vec::new();
        for value in [
            r.rax, r.rbx, r.rcx, r.rdx, r.rsi, r.rdi, r.rsp, r.rbp, r.r8, r.r9, r.r10, r.r11,
            r.r12, r.r13, r.r14, r.r15, r.rip, r.rflags,
        ] {
            bytes.extend_from_slice(&value.to_le_bytes());
        }
        Ok(
            json!({"registers_sha256":hash(&bytes),"memory_sha256":hash(self.memory.bytes()),"rip":r.rip}),
        )
    }
}
impl Drop for Machine {
    fn drop(&mut self) {
        self.owner.check();
    }
}
// Linux UAPI: _IOW(KVMIO=0xae, 0x86, struct kvm_interrupt { u32 irq; }).
// kvm-ioctls 0.25 does not expose this userspace-PIC ioctl. No irqchip is created.
fn inject(m: &Machine, vector: u32) -> Result<()> {
    use std::os::fd::AsRawFd;
    m.owner.check();
    let interrupt = kvm_bindings::kvm_interrupt { irq: vector };
    let rc = unsafe { libc::ioctl(m.vcpu.as_raw_fd(), 0x4004ae86 as libc::c_ulong, &interrupt) };
    require(
        rc == 0,
        format!("KVM_INTERRUPT: {}", std::io::Error::last_os_error()),
    )
}
fn execute(kvm: &Kvm, owner: &Owner, variant: Variant, seed: u64) -> Result<Value> {
    let mut m = Machine::new(kvm, owner, variant, seed)?;
    let table = fixture_table();
    require(m.exit()? == 0, "missing initial IF0 PIO")?;
    require(
        m.memory.get(0x4000) == 0 && m.memory.get(0x4008) == 0,
        "completion ran next instruction",
    )?;
    let initial = m.snapshot()?;
    let mut regs = checked(m.vcpu.get_regs(), "initial regs")?;
    require(regs.rflags & 0x200 == 0, "initial IF not zero")?;
    let window;
    if matches!(variant, Variant::EarlyForced) {
        // Broken world: force IF and inject pending IRQ before guest STI/shadow.
        regs.rflags |= 0x200;
        checked(m.vcpu.set_regs(&regs), "negative force IF")?;
        inject(&m, 0x40)?;
        window = json!({"negative_forced_if":true});
    } else {
        // Pending vector remains world-owned until the real CPU reports a legal window.
        m.vcpu.get_kvm_run().request_interrupt_window = 1;
        loop {
            match m.vcpu.run() {
                Ok(VcpuExit::IrqWindowOpen) => break,
                Err(e) if e.errno() == libc::EINTR => continue,
                other => return Err(format!("expected IRQ window: {other:?}")),
            }
        }
        let ready = m.vcpu.get_kvm_run().ready_for_interrupt_injection;
        regs = checked(m.vcpu.get_regs(), "window regs")?;
        require(
            ready == 1 && regs.rflags & 0x200 != 0,
            "window not injection-ready/IF1",
        )?;
        require(
            regs.rip == table[4] && m.memory.get(0x4000) == 1 && m.memory.get(0x4008) == 1,
            format!(
                "STI shadow/window mismatch rip={:#x} phase={} shadow={}",
                regs.rip,
                m.memory.get(0x4000),
                m.memory.get(0x4008)
            ),
        )?;
        window = json!({"ready":ready,"snapshot":m.snapshot()?,"phase":1,"shadow":1});
        m.vcpu.get_kvm_run().request_interrupt_window = 0;
        inject(&m, 0x40)?;
    }
    require(m.exit()? == 0x40, "missing handler PIO")?;
    let phase = m.memory.get(0x4018);
    let shadow = m.memory.get(0x4020);
    require(
        m.memory.get(0x4010) == 1 && m.memory.get(0x4028) == 0,
        "handler duplicate/completion advanced marker",
    )?;
    if phase != 1 || shadow != 1 {
        return Err(format!(
            "early_irq_guest_order_rejected phase={phase} shadow={shadow} count=1"
        ));
    }
    let handler = m.snapshot()?;
    require(m.exit()? == 2, "missing resumed guest PIO")?;
    require(
        m.memory.get(0x4000) == 2 && m.memory.get(0x4010) == 1 && m.memory.get(0x4028) == 1,
        "resumed oracle mismatch",
    )?;
    let resumed = m.snapshot()?;
    loop {
        match m.vcpu.run() {
            Ok(VcpuExit::Hlt) => break,
            Err(e) if e.errno() == libc::EINTR => continue,
            other => return Err(format!("terminal exit {other:?}")),
        }
    }
    Ok(
        json!({"events":["if0_pending_held","sti_shadow_completed_window","irq_injected","handler_once","guest_resumed","halt"],"initial":initial,"window":window,"handler":handler,"resumed":resumed,"terminal":m.snapshot()?}),
    )
}
pub fn run() -> Result<()> {
    let owner = Owner::new();
    let mut seed = 0x51eeb5eed;
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--once" => {}
            "--seed" => {
                let text = args.next().ok_or("seed missing")?;
                seed = if let Some(hex) = text.strip_prefix("0x") {
                    checked(u64::from_str_radix(hex, 16), "seed")?
                } else {
                    checked(text.parse(), "seed")?
                };
            }
            _ => return Err(format!("unknown argument {arg}")),
        }
    }
    let kvm = checked(Kvm::new(), "open KVM")?;
    require(kvm.get_api_version() == 12, "KVM API !=12")?;
    require(
        kvm.check_extension(Cap::ImmediateExit),
        "ImmediateExit required",
    )?;
    let positive = execute(&kvm, &owner, Variant::Positive, seed)?;
    let negative = execute(&kvm, &owner, Variant::EarlyForced, seed)
        .expect_err("early forced IRQ control must fail");
    require(
        negative == "early_irq_guest_order_rejected phase=0 shadow=0 count=1",
        format!("negative wrong failure: {negative}"),
    )?;
    println!(
        "{}",
        json!({"schema":1,"profile":"bare_cpl0_long_mode_userspace_pic","seed":seed,"guest_sha256":hash(GUEST),"positive":positive,"negative_control":negative})
    );
    Ok(())
}
