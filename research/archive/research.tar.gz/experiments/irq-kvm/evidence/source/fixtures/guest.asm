; Bare long-mode CPL0 IRQ legality; no kernel, irqchip or timers.
BITS 64
ORG 0x8000
    jmp near boot
    times 8-($-$$) db 0
    dq 0x5345454449525131
    dq initial_next, handler_next, done_next, reject_next, shadow_next
    times 0x80-($-$$) db 0x90
boot:
    cli
    mov dx, 0x504
    xor eax, eax
    out dx, eax
initial_next:
    mov qword [0x4000], 1 ; phase before STI
    sti
    mov qword [0x4008], 1 ; one instruction inside interrupt shadow
shadow_next:
    mov qword [0x4000], 2
    mov eax, 2
    out dx, eax
done_next:
    cli
    hlt
    ud2
    times 0x1000-($-$$) db 0x90
handler:
    push rax
    push rdx
    inc qword [0x4010]
    mov rax, [0x4000]
    mov [0x4018], rax
    mov rax, [0x4008]
    mov [0x4020], rax
    mov eax, 0x40
    mov dx, 0x504
    out dx, eax
handler_next:
    mov qword [0x4028], 1 ; must not run during completion-only reentry
    pop rdx
    pop rax
    iretq
reject_next:
    ud2
