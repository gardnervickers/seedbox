#!/bin/sh
set -eu
probe_runs=${PROBE_RUNS:-5}
probe_seed=${PROBE_SEED:-0x51eeb5eed}
case "$probe_runs" in ''|*[!0-9]*) printf 'PROBE_RUNS must be integer >=2\n' >&2; exit 2;; esac
if [ "$probe_runs" -lt 2 ]; then printf 'PROBE_RUNS must be >=2\n' >&2; exit 2; fi
mkdir -p results
rm -f results/run-*.json results/run-*.stderr results/canonical.sha256
{ uname -a; rustc --version; cargo --version; nasm -v; } > results/host.txt
cargo test --locked --release
cargo build --locked --release
probe_bin="${CARGO_TARGET_DIR:-target}/release/seedbox-tsc-kvm-probe"
probe_index=1
while [ "$probe_index" -le "$probe_runs" ]; do
    timeout 30 "$probe_bin" --once --seed "$probe_seed" > "results/run-$probe_index.json" 2> "results/run-$probe_index.stderr"
    if [ "$probe_index" -gt 1 ]; then cmp results/run-1.json "results/run-$probe_index.json"; fi
    probe_index=$((probe_index+1))
done
sha256sum results/run-*.json > results/canonical.sha256
printf 'PASS: %s fresh processes matched the narrow mediated-TSC canonical world.\n' "$probe_runs"
