#!/bin/sh
set -eu
source_dir=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
output=$1
mkdir -p "$output"
output=$(CDPATH= cd -- "$output" && pwd)
cd "$output"
mkdir -p initramfs-root/dev
gcc -static -no-pie -fno-pie -std=c11 -O2 -Wall -Wextra -Werror -Wl,--build-id=none \
  "$source_dir/init.c" "$source_dir/read.S" -o initramfs-root/init
chmod 0755 initramfs-root/init
TZ=UTC find initramfs-root -exec touch -h -t 197001010000.00 {} +
(cd initramfs-root && find . -print | LC_ALL=C sort | cpio --quiet -o -H newc --reproducible --owner=0:0) >initramfs.cpio
sha256sum "$source_dir/init.c" "$source_dir/read.S" "$source_dir/prepare-guest.sh" initramfs-root/init initramfs.cpio >guest-inputs.sha256
gcc --version >compiler.txt
printf 'static_libc=%s\n' "${GUEST_STATIC_LIBC:-unrecorded}" >libc.txt
readelf -l initramfs-root/init >elf-segments.txt
objdump -d --disassemble=witness_read initramfs-root/init >read-disassembly.txt
