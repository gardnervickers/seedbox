use std::{env,fs,path::{Path,PathBuf},process::{Command,Stdio},thread,time::{Duration,Instant}};
fn number(line:&str,key:&str)->u64 {
    let v=line.split_whitespace().find_map(|field|field.strip_prefix(key)).expect("missing saved register field");
    if let Some(hex)=v.strip_prefix("0x") { u64::from_str_radix(hex,16).unwrap() } else { v.parse().unwrap() }
}
fn run(qemu:&str,kernel:&Path,initrd:&Path,root:&Path,name:&str) {
    let dir=root.join(name);fs::create_dir(&dir).expect("fresh output required");
    let serial=dir.join("serial.txt");let phases=dir.join("phases.bin");
    let args=vec!["-machine".into(),"pc,accel=kvm".into(),"-cpu".into(),"qemu64".into(),"-smp".into(),"1".into(),"-m".into(),"128M".into(),"-nodefaults".into(),"-display".into(),"none".into(),"-no-reboot".into(),"-kernel".into(),kernel.display().to_string(),"-initrd".into(),initrd.display().to_string(),"-append".into(),"console=ttyS0 rdinit=/init nokaslr randomize_kstack_offset=off panic=-1".into(),"-rtc".into(),"base=2024-01-01T00:00:00,clock=vm".into(),"-serial".into(),format!("file:{}",serial.display()),"-debugcon".into(),format!("file:{}",phases.display()),"-global".into(),"isa-debugcon.iobase=0xe9".into(),"-device".into(),"isa-debug-exit,iobase=0xf4,iosize=4".into()];
    fs::write(dir.join("args.txt"),format!("qemu={qemu}\n{args:#?}\n")).unwrap();
    let mut child=Command::new(qemu).args(args).stdin(Stdio::null()).stdout(Stdio::null()).stderr(fs::File::create(dir.join("stderr.txt")).unwrap()).spawn().unwrap();
    let start=Instant::now();let mut threads=0;
    let status=loop {
        if let Ok(tasks)=fs::read_dir(format!("/proc/{}/task",child.id())) {threads=threads.max(tasks.count());}
        if let Some(s)=child.try_wait().unwrap(){break s;}
        if start.elapsed()>Duration::from_secs(30){child.kill().unwrap();child.wait().unwrap();panic!("host resource deadline; raw evidence retained");}
        thread::sleep(Duration::from_millis(10));
    };
    let serial=fs::read_to_string(serial).unwrap();
    assert_eq!(status.code(),Some(33),"failed guest fence: {serial}");
    assert!(!serial.contains("OBS FAIL")&&!serial.contains("BUG:")&&!serial.contains("WARNING:"));
    let contexts:Vec<_>=serial.lines().filter(|l|l.starts_with("OBS context ")).collect();
    assert_eq!(contexts.len(),3);
    for (line,(restart,pre)) in contexts.iter().zip([(0,0),(1,0),(1,1)]) {
        assert_eq!(number(line,"restart="),restart);assert_eq!(number(line,"pre_read="),pre);
        assert_eq!(number(line,"handled="),1);
        let site=number(line,"site=");let after=number(line,"after=");assert_eq!(after,site+2);
        let rip=number(line,"rip=");let rax=number(line,"rax=");let rcx=number(line,"rcx=");
        if pre==1 {assert_ne!((rip,rax,rcx),(site,0,after));assert_eq!(number(line,"active_restart="),0);assert_eq!(number(line,"active_eintr="),0);}
        else if restart==1 {assert_eq!((rip,rax,rcx),(site,0,after));assert_eq!(number(line,"active_restart="),1);assert_eq!(number(line,"active_eintr="),0);}
        else {assert_eq!((rip,rax,rcx),(after,(-4i64) as u64,after));assert_eq!(number(line,"active_restart="),0);assert_eq!(number(line,"active_eintr="),1);}
    }
    for line in ["OBS case restart=0 pre_read=0 PASS child=0 bytes=1","OBS case restart=1 pre_read=0 PASS child=0 bytes=1","OBS case restart=1 pre_read=1 PASS child=0 bytes=1","OBS PASS linux-restart-witness"] {assert!(serial.contains(line),"missing case outcome");}
    fs::write(dir.join("report.txt"),format!("PASS exact raw-read signal-context witness and pre-read rejection\nqemu_exit=33\nmax_qemu_threads={threads}\nfunctional_only_not_D001=true\n{}\n",contexts.join("\n"))).unwrap();
    println!("{name}: PASS saved syscall context and pre-read negative; QEMU threads={threads}");
}
fn main(){let args:Vec<String>=env::args().collect();assert_eq!(args.len(),5,"runner QEMU KERNEL INITRAMFS NEW_RESULTS");let root=PathBuf::from(&args[4]);fs::create_dir(&root).expect("fresh root required");for name in ["fresh-1","fresh-2"]{run(&args[1],Path::new(&args[2]),Path::new(&args[3]),&root,name);}}
