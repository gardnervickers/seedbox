#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/mount.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>
#include <ucontext.h>
#include <unistd.h>

extern long witness_read(int, void *, unsigned long);
extern unsigned char witness_read_syscall[], witness_read_after[];
static volatile sig_atomic_t handled;
static volatile uint64_t saved_rip, saved_rax, saved_rcx;
static void handler(int signal, siginfo_t *info, void *context) {
    (void)signal; (void)info;
    ucontext_t *uc = context;
    saved_rip = (uint64_t)uc->uc_mcontext.gregs[REG_RIP];
    saved_rax = (uint64_t)uc->uc_mcontext.gregs[REG_RAX];
    saved_rcx = (uint64_t)uc->uc_mcontext.gregs[REG_RCX];
    handled++;
}
static _Noreturn void finish(int pass) {
    printf("OBS %s linux-restart-witness\n", pass ? "PASS" : "FAIL");
    uint32_t value = pass ? 0x10 : 0x11;
    __asm__ __volatile__("outl %0, %w1" : : "a"(value), "Nd"((uint16_t)0xf4));
    for (;;) pause();
}
static void check(int okay, const char *what) {
    if (!okay) { printf("OBS FAIL check=%s errno=%d\n", what, errno); finish(0); }
}
static void sleep_ms(long ms) {
    struct timespec left = { .tv_sec=0, .tv_nsec=ms * 1000000 };
    while (nanosleep(&left, &left) && errno == EINTR) {}
}
static void signal_case(int restart, int pre_read) {
    handled = 0; saved_rip = saved_rax = saved_rcx = UINT64_MAX;
    struct sigaction act = { .sa_sigaction=handler, .sa_flags=SA_SIGINFO | (restart ? SA_RESTART : 0) };
    sigemptyset(&act.sa_mask);
    check(sigaction(SIGUSR1, &act, NULL) == 0, "sigaction");
    int fds[2]; check(pipe(fds) == 0, "pipe");
    pid_t parent = getpid(), child = fork(); check(child >= 0, "fork");
    if (!child) {
        close(fds[0]); sleep_ms(20);
        if (!pre_read && kill(parent, SIGUSR1)) _exit(1);
        sleep_ms(20);
        if (write(fds[1], "S", 1) != 1) _exit(1);
        _exit(0);
    }
    close(fds[1]);
    if (pre_read) {
        check(kill(parent, SIGUSR1) == 0 && handled == 1, "pre-read-signal-delivered");
    }
    char byte = 0;
    long first = witness_read(fds[0], &byte, 1);
    uint64_t rip = saved_rip, rax = saved_rax, rcx = saved_rcx;
    int active_restart = handled == 1 && rip == (uintptr_t)witness_read_syscall && rax == SYS_read && rcx == (uintptr_t)witness_read_after;
    int active_eintr = handled == 1 && rip == (uintptr_t)witness_read_after && (int64_t)rax == -EINTR && rcx == (uintptr_t)witness_read_after;
    printf("OBS context restart=%d pre_read=%d handled=%d rip=0x%016lx rax=0x%016lx rcx=0x%016lx site=0x%016lx after=0x%016lx active_restart=%d active_eintr=%d first=%ld byte=0x%02x\n",
           restart, pre_read, (int)handled, (unsigned long)rip, (unsigned long)rax, (unsigned long)rcx,
           (unsigned long)(uintptr_t)witness_read_syscall, (unsigned long)(uintptr_t)witness_read_after,
           active_restart, active_eintr, first, (unsigned char)byte);
    if (pre_read) {
        check(first == 1 && byte == 'S' && handled == 1, "pre-read-ambiguous-ABI-outcome");
        check(!active_restart && !active_eintr, "pre-read-active-oracle-rejects");
    } else if (restart) {
        check(first == 1 && byte == 'S' && active_restart && !active_eintr, "actual-SA_RESTART-context-and-result");
    } else {
        check(first == -EINTR && active_eintr && !active_restart, "actual-EINTR-context-and-result");
        check(witness_read(fds[0], &byte, 1) == 1 && byte == 'S', "post-EINTR-read");
    }
    int status = -1;
    check(waitpid(child, &status, 0) == child && WIFEXITED(status) && WEXITSTATUS(status) == 0, "child-status");
    close(fds[0]);
    printf("OBS case restart=%d pre_read=%d PASS child=0 bytes=1\n", restart, pre_read);
}
int main(void) {
    if (mount("devtmpfs", "/dev", "devtmpfs", 0, NULL) && errno != EBUSY) return 1;
    int console = open("/dev/console", O_RDWR); if (console < 0) return 1;
    for (int fd=0; fd<3; fd++) if (dup2(console, fd) < 0) return 1;
    if (console > 2) close(console);
    setvbuf(stdout, NULL, _IONBF, 0);
    check(syscall(SYS_iopl, 3) == 0, "iopl");
    check(syscall(9999) == -1 && errno == ENOSYS, "arm-existing-hook-ABI");
    check((uintptr_t)witness_read_after == (uintptr_t)witness_read_syscall + 2, "two-byte-syscall-site");
    puts("OBS begin linux-restart-witness");
    signal_case(0, 0); signal_case(1, 0); signal_case(1, 1);
    finish(1);
}
