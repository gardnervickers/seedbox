{ pkgs ? (builtins.getFlake "github:NixOS/nixpkgs/8c6b39505383e6d5dcb431f00cb3597b71f8045c").legacyPackages.x86_64-linux }:
pkgs.mkShell {
  packages = with pkgs; [ stdenv.cc glibc.static nasm cpio coreutils binutils ];
  NIX_LDFLAGS = "-L${pkgs.glibc.static}/lib";
  GUEST_STATIC_LIBC = pkgs.glibc.static;
}
