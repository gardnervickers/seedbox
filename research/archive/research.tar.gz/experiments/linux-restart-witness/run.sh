#!/bin/sh
set -eu
source_dir=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
kernel=$1
guest_build=$2
results=$3
rustc --edition=2024 -O "$source_dir/runner.rs" -o "$source_dir/runner"
"$source_dir/runner" "$(command -v qemu-system-x86_64)" "$kernel" "$guest_build/initramfs.cpio" "$results"
uname -a >"$results/host.txt"
cat /proc/cpuinfo >"$results/cpu.txt"
rustc --version >"$results/rustc.txt"
qemu-system-x86_64 --version >"$results/qemu.txt"
sha256sum "$source_dir/init.c" "$source_dir/read.S" "$source_dir/runner.rs" "$source_dir/run.sh" "$source_dir/runner" "$kernel" "$guest_build/initramfs.cpio" >"$results/runtime-inputs.sha256"
