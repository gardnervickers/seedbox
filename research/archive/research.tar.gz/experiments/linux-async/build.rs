use std::{env, path::PathBuf, process::Command};

fn main() {
    println!("cargo:rerun-if-changed=guest.asm");
    let output = PathBuf::from(env::var_os("OUT_DIR").unwrap()).join("guest.bin");
    assert!(
        Command::new("nasm")
            .args(["-f", "bin", "guest.asm", "-o"])
            .arg(output)
            .status()
            .unwrap()
            .success()
    );
    let version = Command::new("pkg-config")
        .args(["--modversion", "unicorn"])
        .output()
        .unwrap();
    assert!(version.status.success());
    let version = String::from_utf8(version.stdout).unwrap();
    assert_eq!(version.trim(), "2.1.4", "probe pins the native engine too");
    println!("cargo:rustc-env=PROBE_UNICORN_VERSION={}", version.trim());
}
