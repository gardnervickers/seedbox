#!/bin/sh
set -eu
experiment_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
project_dir=$(CDPATH= cd -- "$experiment_dir/../.." && pwd)
cd "$project_dir"
mkdir -p "$experiment_dir/evidence"
export CARGO_TARGET_DIR="$project_dir/target/linux-async-probe"
nix develop -c cargo run --offline --locked --manifest-path "$experiment_dir/Cargo.toml" > "$experiment_dir/evidence/local-run-1.txt"
nix develop -c cargo run --offline --locked --manifest-path "$experiment_dir/Cargo.toml" > "$experiment_dir/evidence/local-run-2.txt"
cmp "$experiment_dir/evidence/local-run-1.txt" "$experiment_dir/evidence/local-run-2.txt"
nix develop -c cargo clippy --offline --locked --manifest-path "$experiment_dir/Cargo.toml" -- -D warnings
nix develop -c nasm -f bin "$experiment_dir/guest.asm" -o "$experiment_dir/evidence/guest.bin"
(cd "$experiment_dir" && shasum -a 256 guest.asm evidence/guest.bin Cargo.lock) > "$experiment_dir/evidence/input-sha256.txt"
cat "$experiment_dir/evidence/local-run-1.txt"
printf '%s\n' 'PASS separate-process output equality and clippy'
