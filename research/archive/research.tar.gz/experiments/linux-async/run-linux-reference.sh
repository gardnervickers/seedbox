#!/bin/sh
set -eu
# Run from a temporary directory on an x86-64 Linux host. No root needed.
experiment_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$experiment_dir"
# Same nixpkgs revision as the project's current flake.lock.
reference_nixpkgs=github:NixOS/nixpkgs/8c6b39505383e6d5dcb431f00cb3597b71f8045c
nix shell "$reference_nixpkgs#gcc" "$reference_nixpkgs#nasm" --command sh -eu -c '
  gcc -std=c11 -O2 -Wall -Wextra -Werror linux-reference.c -o linux-reference
  nasm -f bin guest.asm -o guest.bin
  sha256sum guest.bin
  ./linux-reference sqpoll guest.bin
  ./linux-reference no-worker guest.bin
'
