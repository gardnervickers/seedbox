//! Mechanism probe only: a preconfigured mapped ring and modeled NOP worker.
use iced_x86::{Decoder, DecoderOptions, Mnemonic};
use std::thread::{self, ThreadId};
use unicorn_engine::{Arch, Mode, Prot, RegisterX86, Unicorn};

const CODE: u64 = 0x100000;
const END: u64 = CODE + 0xfff;
const RING: u64 = 0x200000;
const SQES: u64 = 0x201000;
const CONTROL: u64 = 0x202000;
const STACK: u64 = 0x300000;
const TOTAL: u32 = 8;
const BASE: u64 = 0xabc0000000000000;
const GUEST: &[u8] = include_bytes!(concat!(env!("OUT_DIR"), "/guest.bin"));

#[repr(C)]
#[derive(Default)]
struct SqOffsets {
    head: u32,
    tail: u32,
    ring_mask: u32,
    ring_entries: u32,
    flags: u32,
    dropped: u32,
    array: u32,
    resv1: u32,
    user_addr: u64,
}
#[repr(C)]
#[derive(Default)]
struct CqOffsets {
    head: u32,
    tail: u32,
    ring_mask: u32,
    ring_entries: u32,
    overflow: u32,
    cqes: u32,
    flags: u32,
    resv1: u32,
    user_addr: u64,
}
#[repr(C)]
#[derive(Default)]
struct Params {
    sq_entries: u32,
    cq_entries: u32,
    flags: u32,
    sq_thread_cpu: u32,
    sq_thread_idle: u32,
    features: u32,
    wq_fd: u32,
    resv: [u32; 3],
    sq_off: SqOffsets,
    cq_off: CqOffsets,
}

#[derive(Default)]
struct Hook {
    steps: u64,
    syscall_instructions: u64,
    instruction_hash: u64,
}

fn put32(uc: &mut Unicorn<Hook>, addr: u64, value: u32) {
    uc.mem_write(addr, &value.to_le_bytes()).unwrap();
}
fn get32(uc: &Unicorn<Hook>, addr: u64) -> u32 {
    u32::from_le_bytes(uc.mem_read_as_vec(addr, 4).unwrap().try_into().unwrap())
}
fn get64(uc: &Unicorn<Hook>, addr: u64) -> u64 {
    u64::from_le_bytes(uc.mem_read_as_vec(addr, 8).unwrap().try_into().unwrap())
}

fn params() -> Params {
    // Real UAPI structure; this probe supplies offsets, as setup would.
    // Kernel-chosen offsets are not a Linux ABI constant.
    Params {
        sq_entries: 2,
        cq_entries: 2,
        flags: 2,
        features: 1,
        sq_off: SqOffsets {
            head: 0,
            tail: 4,
            ring_mask: 8,
            ring_entries: 12,
            flags: 16,
            dropped: 20,
            array: 64,
            ..Default::default()
        },
        cq_off: CqOffsets {
            head: 128,
            tail: 132,
            ring_mask: 136,
            ring_entries: 140,
            overflow: 144,
            cqes: 192,
            flags: 148,
            ..Default::default()
        },
        ..Default::default()
    }
}

fn service(uc: &mut Unicorn<Hook>, p: &Params, owner: ThreadId, completed: &mut Vec<u64>) -> usize {
    assert_eq!(
        owner,
        thread::current().id(),
        "kernel work escaped the calling thread"
    );
    let mut sq_head = get32(uc, RING + u64::from(p.sq_off.head));
    let sq_tail = get32(uc, RING + u64::from(p.sq_off.tail));
    assert!(sq_tail.wrapping_sub(sq_head) <= p.sq_entries);
    let mut count = 0;
    while sq_head != sq_tail {
        let cq_head = get32(uc, RING + u64::from(p.cq_off.head));
        let cq_tail = get32(uc, RING + u64::from(p.cq_off.tail));
        if cq_tail.wrapping_sub(cq_head) == p.cq_entries {
            break;
        }
        let sq_index = sq_head & (p.sq_entries - 1);
        let index = get32(
            uc,
            RING + u64::from(p.sq_off.array) + u64::from(sq_index) * 4,
        );
        assert!(index < p.sq_entries);
        let sqe = SQES + u64::from(index) * 64;
        let raw = uc.mem_read_as_vec(sqe, 64).unwrap();
        assert_eq!(raw[0], 0, "only UAPI IORING_OP_NOP supported");
        assert_eq!(raw[1], 0, "SQE flags outside the experiment profile");
        let user_data = get64(uc, sqe + 32);
        assert_eq!(user_data, BASE + completed.len() as u64);
        let cqe = RING + u64::from(p.cq_off.cqes) + u64::from(cq_tail & (p.cq_entries - 1)) * 16;
        let mut bytes = [0u8; 16];
        bytes[..8].copy_from_slice(&user_data.to_le_bytes());
        uc.mem_write(cqe, &bytes).unwrap();
        // Entries are initialized before publication; no guest executes here.
        put32(uc, RING + u64::from(p.cq_off.tail), cq_tail.wrapping_add(1));
        sq_head = sq_head.wrapping_add(1);
        put32(uc, RING + u64::from(p.sq_off.head), sq_head);
        completed.push(user_data);
        count += 1;
    }
    count
}

#[derive(Debug, PartialEq, Eq)]
struct ResultRow {
    enabled: bool,
    counter_start: u32,
    status: u32,
    consumed: u32,
    produced: usize,
    steps: u64,
    slices: u64,
    worker_publications: u64,
    instruction_hash: u64,
    sq_head: u32,
    sq_tail: u32,
    cq_head: u32,
    cq_tail: u32,
}

fn run(enabled: bool, start: u32) -> ResultRow {
    let owner = thread::current().id();
    let p = params();
    let mut uc = Unicorn::new_with_data(
        Arch::X86,
        Mode::MODE_64,
        Hook {
            instruction_hash: 0xcbf29ce484222325,
            ..Default::default()
        },
    )
    .unwrap();
    for (addr, perm) in [
        (CODE, Prot::ALL),
        (RING, Prot::READ | Prot::WRITE),
        (SQES, Prot::READ | Prot::WRITE),
        (CONTROL, Prot::READ | Prot::WRITE),
        (STACK, Prot::READ | Prot::WRITE),
    ] {
        uc.mem_map(addr, 4096, perm).unwrap();
    }
    uc.mem_write(CODE, GUEST).unwrap();
    for off in [p.sq_off.head, p.sq_off.tail, p.cq_off.head, p.cq_off.tail] {
        put32(&mut uc, RING + u64::from(off), start);
    }
    put32(
        &mut uc,
        RING + u64::from(p.sq_off.ring_mask),
        p.sq_entries - 1,
    );
    put32(
        &mut uc,
        RING + u64::from(p.sq_off.ring_entries),
        p.sq_entries,
    );
    put32(
        &mut uc,
        RING + u64::from(p.cq_off.ring_mask),
        p.cq_entries - 1,
    );
    put32(
        &mut uc,
        RING + u64::from(p.cq_off.ring_entries),
        p.cq_entries,
    );
    let addresses = [
        RING + u64::from(p.sq_off.head),
        RING + u64::from(p.sq_off.tail),
        RING + u64::from(p.sq_off.ring_mask),
        RING + u64::from(p.sq_off.array),
        SQES,
        RING + u64::from(p.cq_off.head),
        RING + u64::from(p.cq_off.tail),
        RING + u64::from(p.cq_off.ring_mask),
        RING + u64::from(p.cq_off.cqes),
        RING + u64::from(p.sq_off.flags),
    ];
    for (i, addr) in addresses.iter().enumerate() {
        uc.mem_write(CONTROL + i as u64 * 8, &addr.to_le_bytes())
            .unwrap();
    }
    put32(&mut uc, CONTROL + 80, TOTAL);
    put32(&mut uc, CONTROL + 92, 10_000_000);
    uc.mem_write(STACK + 4080, &END.to_le_bytes()).unwrap();
    uc.reg_write(RegisterX86::RSP, STACK + 4080).unwrap();
    uc.reg_write(RegisterX86::RDI, CONTROL).unwrap();
    uc.reg_write(RegisterX86::RIP, CODE).unwrap();
    uc.add_code_hook(1, 0, |uc, address, size| {
        let raw = uc.mem_read_as_vec(address, size as usize).unwrap();
        let instr = Decoder::with_ip(64, &raw, address, DecoderOptions::NONE).decode();
        assert!(!instr.is_invalid());
        let syscall = matches!(
            instr.mnemonic(),
            Mnemonic::Syscall | Mnemonic::Sysenter | Mnemonic::Int
        );
        let h = uc.get_data_mut();
        h.steps += 1;
        h.syscall_instructions += u64::from(syscall);
        assert!(!syscall, "guest must not enter a submission syscall");
        for byte in address.to_le_bytes().into_iter().chain(raw) {
            h.instruction_hash = (h.instruction_hash ^ u64::from(byte)).wrapping_mul(0x100000001b3);
        }
    })
    .unwrap();
    let mut completed = Vec::new();
    let mut slices = 0;
    let mut publications = 0;
    let cap = if enabled { 20_000 } else { 50_000 };
    while uc.reg_read(RegisterX86::RIP).unwrap() != END && uc.get_data().steps < cap {
        assert_eq!(owner, thread::current().id());
        let pc = uc.reg_read(RegisterX86::RIP).unwrap();
        let before = uc.get_data().steps;
        let budget = 31.min(cap - before);
        uc.emu_start(pc, END, 0, budget as usize).unwrap();
        assert!(uc.get_data().steps - before <= budget);
        slices += 1;
        if enabled {
            publications += service(&mut uc, &p, owner, &mut completed) as u64;
        }
    }
    assert_eq!(uc.get_data().syscall_instructions, 0);
    let row = ResultRow {
        enabled,
        counter_start: start,
        status: get32(&uc, CONTROL + 84),
        consumed: get32(&uc, CONTROL + 88),
        produced: completed.len(),
        steps: uc.get_data().steps,
        slices,
        worker_publications: publications,
        instruction_hash: uc.get_data().instruction_hash,
        sq_head: get32(&uc, RING + u64::from(p.sq_off.head)),
        sq_tail: get32(&uc, RING + u64::from(p.sq_off.tail)),
        cq_head: get32(&uc, RING + u64::from(p.cq_off.head)),
        cq_tail: get32(&uc, RING + u64::from(p.cq_off.tail)),
    };
    if enabled {
        assert_eq!(row.status, 1);
        assert_eq!(row.consumed, TOTAL);
        assert_eq!(row.produced, TOTAL as usize);
        assert_eq!(row.sq_head, start.wrapping_add(TOTAL));
        assert_eq!(row.cq_head, row.sq_head);
        assert_eq!(row.sq_tail, row.sq_head);
        assert_eq!(row.cq_tail, row.cq_head);
    } else {
        assert_eq!(row.status, 0, "guest cannot claim success without a worker");
        assert_eq!(row.consumed, 0);
        assert_eq!(row.produced, 0);
        assert_eq!(row.steps, cap);
        assert_eq!(row.sq_tail.wrapping_sub(row.sq_head), 2);
    }
    row
}

fn main() {
    assert_eq!(std::mem::size_of::<Params>(), 120);
    assert_eq!(std::mem::size_of::<SqOffsets>(), 40);
    assert_eq!(std::mem::size_of::<CqOffsets>(), 40);
    println!(
        "profile native_unicorn={} bindings=2.1.5 guest_bytes={} quantum=31 sq=2 cq=2 same_host_thread=true no_syscalls=true",
        env!("PROBE_UNICORN_VERSION"),
        GUEST.len()
    );
    for (enabled, start) in [(true, 0), (true, u32::MAX - 3), (false, 0)] {
        let first = run(enabled, start);
        assert_eq!(
            first,
            run(enabled, start),
            "fresh engines must regenerate the execution"
        );
        println!("{first:?}");
    }
    println!(
        "PASS mapped NOP mechanism; fresh-engine repeats and disabled-worker negative control"
    );
}
