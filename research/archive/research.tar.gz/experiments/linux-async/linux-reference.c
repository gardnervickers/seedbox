// Executes exactly the guest.asm bytes against kernel-returned mapped-ring offsets.
// Setup/mmap/cleanup syscalls are outside the guest; no io_uring_enter is called.
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/io_uring.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/utsname.h>
#include <unistd.h>

_Static_assert(sizeof(struct io_uring_sqe) == 64, "SQE64 profile");
_Static_assert(offsetof(struct io_uring_sqe, user_data) == 32, "SQE userdata");
_Static_assert(sizeof(struct io_uring_cqe) == 16, "CQE16 profile");
_Static_assert(offsetof(struct io_uring_cqe, res) == 8, "CQE result");
_Static_assert(offsetof(struct io_uring_cqe, flags) == 12, "CQE flags");
_Static_assert(sizeof(struct io_uring_params) == 120, "setup params");
_Static_assert(IORING_OP_NOP == 0 && IORING_SQ_NEED_WAKEUP == 1, "op and flag");

struct control {
    uint64_t sq_head, sq_tail, sq_mask, sq_array, sqes;
    uint64_t cq_head, cq_tail, cq_mask, cqes, sq_flags;
    uint32_t total, status, observed, poll_limit;
};
_Static_assert(offsetof(struct control, total) == 80, "guest control ABI");
_Static_assert(sizeof(struct control) == 96, "guest control size");

static void *map_ring(int fd, size_t length, off_t offset) {
    void *p = mmap(NULL, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, offset);
    if (p == MAP_FAILED) { perror("ring mmap"); exit(1); }
    return p;
}
static uint64_t at(void *p, uint32_t offset) { return (uintptr_t)p + offset; }
static uint32_t load(uint64_t p) { return __atomic_load_n((uint32_t *)(uintptr_t)p, __ATOMIC_ACQUIRE); }

int main(int argc, char **argv) {
    if (argc != 3 || (strcmp(argv[1], "sqpoll") && strcmp(argv[1], "no-worker"))) {
        fprintf(stderr, "usage: %s sqpoll|no-worker guest.bin\n", argv[0]); return 1;
    }
    int enabled = !strcmp(argv[1], "sqpoll");
    struct utsname host; if (uname(&host)) { perror("uname"); return 1; }
    printf("reference kernel=%s arch=%s mode=%s no_io_uring_enter=true\n", host.release, host.machine, argv[1]);
    if (strcmp(host.machine, "x86_64")) { fprintf(stderr, "BLOCKED: x86-64 only\n"); return 77; }
    struct io_uring_params p = { .flags = enabled ? IORING_SETUP_SQPOLL : 0, .sq_thread_idle = enabled ? 60000 : 0 };
    int ring = syscall(SYS_io_uring_setup, 2, &p);
    if (ring < 0) {
        int error = errno;
        fprintf(stderr, "BLOCKED io_uring_setup errno=%d (%s)\n", error, strerror(error));
        return (error == ENOSYS || error == EPERM || error == EACCES) ? 77 : 1;
    }
    size_t sq_len = p.sq_off.array + p.sq_entries * sizeof(uint32_t);
    size_t cq_len = p.cq_off.cqes + p.cq_entries * sizeof(struct io_uring_cqe);
    int single = !!(p.features & IORING_FEAT_SINGLE_MMAP);
    if (single && cq_len > sq_len) sq_len = cq_len;
    void *sq = map_ring(ring, sq_len, IORING_OFF_SQ_RING);
    void *cq = single ? sq : map_ring(ring, cq_len, IORING_OFF_CQ_RING);
    size_t sqe_len = p.sq_entries * sizeof(struct io_uring_sqe);
    void *sqes = map_ring(ring, sqe_len, IORING_OFF_SQES);
    int blob = open(argv[2], O_RDONLY);
    struct stat st;
    if (blob < 0 || fstat(blob, &st) || st.st_size <= 0) { perror("guest binary"); return 1; }
    void *code = mmap(NULL, (size_t)st.st_size, PROT_READ | PROT_EXEC, MAP_PRIVATE, blob, 0);
    if (code == MAP_FAILED) { perror("guest mmap"); return 1; }
    struct control c = {
        .sq_head=at(sq,p.sq_off.head), .sq_tail=at(sq,p.sq_off.tail),
        .sq_mask=at(sq,p.sq_off.ring_mask), .sq_array=at(sq,p.sq_off.array), .sqes=(uintptr_t)sqes,
        .cq_head=at(cq,p.cq_off.head), .cq_tail=at(cq,p.cq_off.tail),
        .cq_mask=at(cq,p.cq_off.ring_mask), .cqes=at(cq,p.cq_off.cqes), .sq_flags=at(sq,p.sq_off.flags),
        .total=8, .poll_limit=10000000,
    };
    printf("layout sq_entries=%u cq_entries=%u features=0x%x sqe=64 cqe=16 guest_bytes=%jd\n", p.sq_entries,p.cq_entries,p.features,(intmax_t)st.st_size);
    int (*guest)(struct control *) = (int (*)(struct control *))code;
    int status = guest(&c);
    printf("result status=%d consumed=%u sq_head=%u sq_tail=%u cq_head=%u cq_tail=%u flags=0x%x\n",status,c.observed,load(c.sq_head),load(c.sq_tail),load(c.cq_head),load(c.cq_tail),load(c.sq_flags));
    int result;
    if (status == 4) { fprintf(stderr,"BLOCKED: SQPOLL worker requires wakeup; guest deliberately does not wake it\n"); result=77; }
    else if (enabled) result = status==1 && c.observed==8 && load(c.sq_head)==8 && load(c.sq_tail)==8 && load(c.cq_head)==8 && load(c.cq_tail)==8 ? 0 : 1;
    else result = status==3 && c.observed==0 && load(c.sq_head)==0 && load(c.sq_tail)==2 && load(c.cq_head)==0 && load(c.cq_tail)==0 ? 0 : 1;
    printf("%s native mapped NOP %s\n",result==0?"PASS":result==77?"BLOCKED":"FAIL",enabled?"reference":"negative control");
    munmap(code,(size_t)st.st_size); close(blob); munmap(sqes,sqe_len);
    if (!single) munmap(cq,cq_len);
    munmap(sq,sq_len); close(ring);
    return result;
}
