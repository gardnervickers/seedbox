BITS 64
global _start
section .text
_start:
    mov eax, 2
    lea rdi, [console]
    mov esi, 2
    xor edx, edx
    syscall
    test rax, rax
    js pause_forever
    mov rbp, rax
    mov eax, 228
    xor edi, edi
    lea rsi, [timebuf]
    syscall
    test rax, rax
    js fail
    lea rsi, [clock_label]
    mov edx, clock_len
    call write_line
    mov rax, [timebuf]
    call write_hex
    mov eax, 318
    lea rdi, [random_buf]
    mov esi, 32
    xor edx, edx
    syscall
    cmp rax, 32
    jne fail
    lea rsi, [random_label]
    mov edx, random_len
    call write_line
    mov rax, [random_buf]
    call write_hex
    lea rsi, [ready]
    mov edx, ready_len
    call write_line
    mov ebx, 0x10
    jmp finish
fail:
    lea rsi, [failed]
    mov edx, failed_len
    call write_line
    mov ebx, 0x11
finish:
    mov eax, 172
    mov edi, 3
    syscall
    test rax, rax
    js pause_forever
    mov eax, ebx
    mov dx, 0xf4
    out dx, eax
pause_forever:
    mov eax, 34
    syscall
    jmp pause_forever
write_line:
    mov eax, 1
    mov rdi, rbp
    syscall
    ret
write_hex:
    mov r8, rax
    lea rsi, [hexbuf]
    xor r9d, r9d
.loop:
    rol r8, 4
    mov r10, r8
    and r10d, 15
    mov dl, [digits + r10]
    mov [rsi + r9], dl
    inc r9d
    cmp r9d, 16
    jne .loop
    mov edx, 17
    jmp write_line
section .rodata
console: db '/dev/console', 0
digits: db '0123456789abcdef'
clock_label: db 'USERSPACE_CLOCK_SEC='
clock_len equ $-clock_label
random_label: db 'USERSPACE_RANDOM_WORD0='
random_len equ $-random_label
ready: db 'USERSPACE_READY', 10
ready_len equ $-ready
failed: db 'USERSPACE_FAIL', 10
failed_len equ $-failed
section .data
hexbuf: times 16 db 0
    db 10
timebuf: times 16 db 0
random_buf: times 32 db 0
