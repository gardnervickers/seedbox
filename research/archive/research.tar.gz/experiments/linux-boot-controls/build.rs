use std::{env, path::PathBuf, process::Command};
fn main() {
    println!("cargo:rerun-if-changed=guest/init.asm");
    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    assert!(
        Command::new("nasm")
            .args(["-f", "elf64", "guest/init.asm", "-o"])
            .arg(out.join("init.o"))
            .status()
            .unwrap()
            .success()
    );
    assert!(
        Command::new("ld.lld")
            .args(["-static", "-m", "elf_x86_64", "-e", "_start", "-o"])
            .arg(out.join("init"))
            .arg(out.join("init.o"))
            .status()
            .unwrap()
            .success()
    );
}
