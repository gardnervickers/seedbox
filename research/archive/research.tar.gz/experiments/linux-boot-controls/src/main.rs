use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    error::Error,
    fs,
    path::{Path, PathBuf},
    process::Command,
    time::Instant,
};
type Result<T> = std::result::Result<T, Box<dyn Error>>;
const INIT: &[u8] = include_bytes!(concat!(env!("OUT_DIR"), "/init"));
const CMDLINE: &str = "console=ttyS0 rdinit=/init nokaslr randomize_kstack_offset=off panic=-1 random.trust_cpu=on lpj=1000000 tsc_early_khz=1000000 tsc=reliable clocksource=tsc nosoftlockup";
fn hash(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}
fn entry(out: &mut Vec<u8>, inode: u32, name: &str, mode: u32, dev: (u32, u32), bytes: &[u8]) {
    out.extend_from_slice(b"070701");
    for v in [
        inode,
        mode,
        0,
        0,
        1,
        0,
        bytes.len() as u32,
        0,
        0,
        dev.0,
        dev.1,
        name.len() as u32 + 1,
        0,
    ] {
        out.extend_from_slice(format!("{v:08x}").as_bytes());
    }
    out.extend_from_slice(name.as_bytes());
    out.push(0);
    while !out.len().is_multiple_of(4) {
        out.push(0);
    }
    out.extend_from_slice(bytes);
    while !out.len().is_multiple_of(4) {
        out.push(0);
    }
}
fn initrd() -> Vec<u8> {
    let mut out = Vec::new();
    entry(&mut out, 1, "dev", 0o40755, (0, 0), &[]);
    entry(&mut out, 2, "dev/console", 0o20600, (5, 1), &[]);
    entry(&mut out, 3, "init", 0o100755, (0, 0), INIT);
    entry(&mut out, 4, "TRAILER!!!", 0, (0, 0), &[]);
    out
}
fn stage<'a>(lines: &'a [String], name: &str) -> Result<&'a str> {
    let key = format!("SEEDBOX_BOOT stage={name} ");
    let mut selected = lines.iter().filter(|s| s.starts_with(&key));
    let first = selected.next().ok_or_else(|| format!("missing {name}"))?;
    if selected.next().is_some() {
        return Err(format!("duplicate {name}").into());
    }
    Ok(first)
}
fn validate(lines: &[String]) -> Result<()> {
    let stages = [
        "prior",
        "early-random",
        "early-end",
        "time-input",
        "time-random",
        "time-end",
    ];
    if lines.len() != stages.len() {
        return Err("missing/extra early checkpoints".into());
    }
    for (line, name) in lines.iter().zip(stages) {
        if stage(lines, name)? != line {
            return Err("checkpoint order changed".into());
        }
    }
    for name in ["early-random", "time-random"] {
        let line = stage(lines, name)?;
        let bytes = line
            .split("kernel_random=")
            .nth(1)
            .ok_or("kernel sample missing")?;
        if bytes.len() != 64 || hex::decode(bytes)?.len() != 32 {
            return Err("invalid kernel sample".into());
        }
    }
    for name in ["prior", "early-end", "time-end"] {
        let line = stage(lines, name)?;
        let digest = line.split("pool=").nth(1).ok_or("pool digest missing")?;
        if digest.len() != 64 || hex::decode(digest)?.len() != 32 {
            return Err("invalid pool digest".into());
        }
    }
    let end = stage(lines, "time-end")?;
    for field in ["cpu_words=", "cycle_reads="] {
        let n = end
            .split(field)
            .nth(1)
            .ok_or("input counter missing")?
            .split_whitespace()
            .next()
            .ok_or("input counter empty")?
            .parse::<u64>()?;
        if n == 0 {
            return Err("input path not exercised".into());
        }
    }
    Ok(())
}
fn qemu() -> Result<PathBuf> {
    std::env::split_paths(&std::env::var_os("PATH").ok_or("PATH missing")?)
        .map(|p| p.join("qemu-system-x86_64"))
        .find(|p| p.is_file())
        .ok_or_else(|| "QEMU missing".into())
}
struct Variant<'a> {
    name: &'a str,
    seed: u64,
    rtc: &'a str,
    world: Option<u64>,
    instrumented: bool,
    clock_shift: Option<u8>,
}
fn run(
    qemu: &Path,
    kernel: &Path,
    initrd: &Path,
    out: &Path,
    variant: Variant<'_>,
) -> Result<Value> {
    let Variant {
        name,
        seed,
        rtc,
        world,
        instrumented,
        clock_shift,
    } = variant;
    let dir = out.join(name);
    fs::create_dir_all(&dir)?;
    let append = world.map_or_else(
        || CMDLINE.to_string(),
        |v| format!("{CMDLINE} seedbox_rng_seed={v}"),
    );
    let mut args: Vec<String> = [
        "-machine",
        "pc,vmport=off",
        "-accel",
        "tcg,thread=single",
        "-cpu",
        "qemu64,+rdrand,+rdseed",
        "-smp",
        "1",
        "-m",
        "128M",
        "-display",
        "none",
        "-monitor",
        "none",
        "-serial",
        "stdio",
        "-nodefaults",
        "-icount",
        "shift=4,align=off,sleep=off",
        "-rtc",
    ]
    .iter()
    .map(|s| s.to_string())
    .chain([
        format!("base={rtc},clock=vm"),
        "-seed".into(),
        seed.to_string(),
        "-device".into(),
        "isa-debug-exit,iobase=0xf4,iosize=0x04".into(),
        "-kernel".into(),
        kernel.display().to_string(),
        "-initrd".into(),
        initrd.display().to_string(),
        "-append".into(),
        append,
    ])
    .collect();
    if let Some(shift) = clock_shift {
        let at = args
            .iter()
            .position(|v| v == "-icount")
            .ok_or("clock argument missing")?;
        args[at + 1] = format!("shift={shift},align=off,sleep=off");
    }
    fs::write(dir.join("args.json"), serde_json::to_vec_pretty(&args)?)?;
    let started = Instant::now();
    let result = Command::new("timeout")
        .arg("30")
        .arg(qemu)
        .args(&args)
        .output()?;
    let elapsed = started.elapsed().as_secs_f64();
    fs::write(dir.join("serial.txt"), &result.stdout)?;
    fs::write(dir.join("stderr.txt"), &result.stderr)?;
    let text = String::from_utf8(result.stdout)?.replace('\r', "");
    if result.status.code() != Some(33)
        || !text.contains("USERSPACE_READY\n")
        || text.contains("USERSPACE_FAIL")
    {
        return Err(format!(
            "{name}: functional boot failed {}, inspect {}",
            result.status,
            dir.display()
        )
        .into());
    }
    let lines: Vec<String> = text
        .lines()
        .filter_map(|s| s.find("SEEDBOX_BOOT ").map(|at| s[at..].to_string()))
        .collect();
    if instrumented {
        validate(&lines)?;
        if text
            .find("SEEDBOX_BOOT stage=time-end")
            .ok_or("end missing")?
            > text
                .find("USERSPACE_CLOCK_SEC=")
                .ok_or("userspace observation missing")?
        {
            return Err("early checkpoint not before userspace".into());
        }
    } else if !lines.is_empty() {
        return Err("baseline unexpectedly instrumented".into());
    }
    let userspace: Vec<&str> = text
        .lines()
        .filter(|s| s.starts_with("USERSPACE_"))
        .collect();
    let report = json!({"name":name,"qemu_seed":seed,"rtc":rtc,"world_seed":world,"icount_shift_override":clock_shift,
      "kernel_sha256":hash(&fs::read(kernel)?),"initrd_sha256":hash(&fs::read(initrd)?),
      "host_seconds":elapsed,"command":args,"exit":33,"canonical":{"early_checkpoints":lines},"userspace":userspace});
    fs::write(dir.join("report.json"), serde_json::to_vec_pretty(&report)?)?;
    eprintln!("{name}: boot PASS {elapsed:.3}s");
    Ok(report)
}
fn early(report: &Value) -> Result<Vec<String>> {
    Ok(report["canonical"]["early_checkpoints"]
        .as_array()
        .ok_or("checkpoints missing")?
        .iter()
        .map(|v| v.as_str().ok_or("not text").map(str::to_owned))
        .collect::<std::result::Result<_, _>>()?)
}
fn equal(a: &Value, b: &Value) -> bool {
    a["canonical"] == b["canonical"]
}
fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() != 4 {
        return Err("usage: probe BASELINE_KERNEL PATCHED_KERNEL OUTPUT_DIR".into());
    }
    let baseline = Path::new(&args[1]);
    let kernel = Path::new(&args[2]);
    let out = Path::new(&args[3]);
    fs::create_dir_all(out)?;
    let initrd_file = out.join("initramfs.cpio");
    fs::write(&initrd_file, initrd())?;
    let q = qemu()?;
    let rtc = "2020-01-01T00:00:00";
    let perturbed_rtc = "2030-01-01T00:00:00";
    let mut reports = Vec::new();
    reports.push(run(
        &q,
        baseline,
        &initrd_file,
        out,
        Variant {
            name: "baseline",
            seed: 42,
            rtc,
            world: None,
            instrumented: false,
            clock_shift: None,
        },
    )?);
    for (name, seed, date, world) in [
        ("raw42a", 42, rtc, None),
        ("raw42b", 42, rtc, None),
        ("raw43", 43, rtc, None),
        ("raw_clock", 42, perturbed_rtc, None),
        ("control42a", 42, rtc, Some(42)),
        ("control42b", 42, rtc, Some(42)),
        ("control42c", 42, rtc, Some(42)),
        ("control_rng", 43, rtc, Some(42)),
        ("control_clock", 42, perturbed_rtc, Some(42)),
        ("control_world43", 42, rtc, Some(43)),
    ] {
        reports.push(run(
            &q,
            kernel,
            &initrd_file,
            out,
            Variant {
                name,
                seed,
                rtc: date,
                world,
                instrumented: true,
                clock_shift: None,
            },
        )?);
    }
    for (name, world) in [("raw_cycles", None), ("control_cycles", Some(42))] {
        reports.push(run(
            &q,
            kernel,
            &initrd_file,
            out,
            Variant {
                name,
                seed: 42,
                rtc,
                world,
                instrumented: true,
                clock_shift: Some(5),
            },
        )?);
    }
    let find = |name: &str| {
        reports
            .iter()
            .find(|v| v["name"] == name)
            .ok_or_else(|| format!("{name} missing"))
    };
    let raw_a = find("raw42a")?;
    let raw_b = find("raw42b")?;
    let raw_rng = find("raw43")?;
    let raw_clock = find("raw_clock")?;
    let aa = early(raw_a)?;
    let bb = early(raw_rng)?;
    let cc = early(raw_clock)?;
    if stage(&aa, "early-random")? == stage(&bb, "early-random")? {
        return Err("CPU entropy perturbation missed kernel output oracle".into());
    }
    if stage(&aa, "time-input")? == stage(&cc, "time-input")?
        || stage(&aa, "time-random")? == stage(&cc, "time-random")?
    {
        return Err("clock perturbation missed actual kernel input/output oracle".into());
    }
    let raw_cycles = early(find("raw_cycles")?)?;
    let cycle_value = |text: &str| -> Result<String> {
        Ok(text
            .split("entropy=")
            .nth(1)
            .ok_or("cycle input missing")?
            .split_whitespace()
            .next()
            .ok_or("cycle input empty")?
            .to_owned())
    };
    if cycle_value(stage(&aa, "time-input")?)? == cycle_value(stage(&raw_cycles, "time-input")?)?
        || stage(&aa, "time-random")? == stage(&raw_cycles, "time-random")?
    {
        return Err("kernel TSC perturbation missed actual input/output oracle".into());
    }
    let positive = find("control42a")?;
    let comparisons:Vec<Value>=["control42b","control42c","control_rng","control_clock","control_cycles"].iter().map(|n| {
        let right=find(n).unwrap();
        json!({"left":"control42a","right":n,"early_equal":equal(positive,right),"userspace_equal":positive["userspace"]==right["userspace"]})
    }).collect();
    let controlled = comparisons.iter().all(|c| c["early_equal"] == true);
    let world_sensitive = !equal(positive, find("control_world43")?);
    let summary = json!({"profile":"selected_kernel_rng_initialization_only_not_full_boot",
      "nixpkgs_revision":"8c6b39505383e6d5dcb431f00cb3597b71f8045c","linux_version":"6.12.112",
      "qemu_path":q,"qemu_sha256":hash(&fs::read(&q)?),"qemu_version":String::from_utf8(Command::new(&q).arg("--version").output()?.stdout)?,
      "patch_sha256":hash(&fs::read("patches/early-rng-scope.patch")?),"init_elf_sha256":hash(INIT),
      "raw_fixed_repeat_equal":equal(raw_a,raw_b),"raw_cpu_entropy_negative_sensitive":true,"raw_clock_negative_sensitive":true,"raw_kernel_tsc_negative_sensitive":true,
      "controlled_scope_repeat_and_perturbations_equal":controlled,"controlled_world_seed_sensitive":world_sensitive,
      "comparisons":comparisons,"runs":reports});
    fs::write(
        out.join("results.json"),
        serde_json::to_vec_pretty(&summary)?,
    )?;
    if !controlled || !world_sensitive {
        return Err("declared control scope gate FAILED; raw evidence preserved".into());
    }
    println!("PASS: selected early kernel RNG scope; no whole-boot/D001/backend adoption claim");
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn checkpoint_gate_rejects_missing_duplicate_and_reordered_stages() {
        assert!(validate(&[]).is_err());
        let sample = vec![
            "SEEDBOX_BOOT stage=prior x=1".into(),
            "SEEDBOX_BOOT stage=prior x=2".into(),
        ];
        assert!(stage(&sample, "prior").is_err());
        let digest = "00".repeat(32);
        let mut complete = vec![
            format!("SEEDBOX_BOOT stage=prior pool={digest}"),
            format!("SEEDBOX_BOOT stage=early-random kernel_random={digest}"),
            format!("SEEDBOX_BOOT stage=early-end pool={digest}"),
            "SEEDBOX_BOOT stage=time-input entropy=1 real_ns=2".into(),
            format!("SEEDBOX_BOOT stage=time-random kernel_random={digest}"),
            format!("SEEDBOX_BOOT stage=time-end cpu_words=1 cycle_reads=1 pool={digest}"),
        ];
        assert!(validate(&complete).is_ok());
        complete.swap(1, 2);
        assert!(validate(&complete).is_err());
    }
    #[test]
    fn deterministic_newc_contains_elf_and_console() {
        assert_eq!(initrd(), initrd());
        let data = initrd();
        assert!(data.windows(4).any(|x| x == b"\x7fELF"));
        assert!(data.windows(11).any(|x| x == b"dev/console"));
        assert_eq!(data.len() % 4, 0);
    }
}
